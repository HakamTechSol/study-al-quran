import 'package:flutter/material.dart';
import 'package:studyalquran/utils/app_text_styles.dart';
import 'package:studyalquran/utils/color_constants.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class ReportsAttendanceScreen extends StatefulWidget {
  const ReportsAttendanceScreen({super.key});

  @override
  State<ReportsAttendanceScreen> createState() =>
      _ReportsAttendanceScreenState();
}

class _ReportsAttendanceScreenState extends State<ReportsAttendanceScreen> {
  int selectedTab = 0; // 0 = Attendance Log, 1 = Session Reports

  // Filters
  String selectedStatusFilter = 'All';
  String selectedDateFilter = 'All Time';
  String searchQuery = '';

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Stream<List<AttendanceRecord>> getAttendanceStream() {
    return _firestore
        .collection('attendance')
        .orderBy('date')
        .orderBy('time')
        .snapshots()
        .asyncMap((snapshot) async {
          List<AttendanceRecord> attendanceRecords = [];

          for (var doc in snapshot.docs) {
            Map<String, dynamic> data = doc.data();

            // Get student name
            String studentName = 'Unknown Student';
            if (data['studentId'] != null && data['studentId'].isNotEmpty) {
              try {
                var studentDoc = await _firestore
                    .collection('students')
                    .doc(data['studentId'])
                    .get();
                if (studentDoc.exists) {
                  studentName = studentDoc.data()?['name'] ?? 'Unknown Student';
                }
              } catch (e) {
                print('Error fetching student: $e');
              }
            }

            // Get teacher name
            String teacherName = 'Unknown Teacher';
            if (data['teacherId'] != null && data['teacherId'].isNotEmpty) {
              try {
                var teacherDoc = await _firestore
                    .collection('teachers')
                    .doc(data['teacherId'])
                    .get();
                if (teacherDoc.exists) {
                  teacherName = teacherDoc.data()?['name'] ?? 'Unknown Teacher';
                }
              } catch (e) {
                print('Error fetching teacher: $e');
              }
            }

            attendanceRecords.add(
              AttendanceRecord.fromFirestore(
                data,
                doc.id,
                studentName,
                teacherName,
              ),
            );
          }

          return attendanceRecords;
        });
  }

  // 🔥 STREAM: Real-time session reports data
  Stream<List<SessionReport>> getSessionReportsStream() {
    return _firestore
        .collection('session_reports')
        .orderBy('date', descending: true)
        .orderBy('time', descending: true)
        .snapshots()
        .asyncMap((snapshot) async {
          List<SessionReport> sessionReports = [];

          for (var doc in snapshot.docs) {
            Map<String, dynamic> data = doc.data();

            // Get student name
            String studentName = 'Unknown Student';
            if (data['studentId'] != null && data['studentId'].isNotEmpty) {
              try {
                var studentDoc = await _firestore
                    .collection('students')
                    .doc(data['studentId'])
                    .get();
                if (studentDoc.exists) {
                  studentName = studentDoc.data()?['name'] ?? 'Unknown Student';
                }
              } catch (e) {
                print('Error fetching student: $e');
              }
            }

            // Get teacher name
            String teacherName = 'Unknown Teacher';
            if (data['teacherId'] != null && data['teacherId'].isNotEmpty) {
              try {
                var teacherDoc = await _firestore
                    .collection('teachers')
                    .doc(data['teacherId'])
                    .get();
                if (teacherDoc.exists) {
                  teacherName = teacherDoc.data()?['name'] ?? 'Unknown Teacher';
                }
              } catch (e) {
                print('Error fetching teacher: $e');
              }
            }

            sessionReports.add(
              SessionReport.fromFirestore(
                data,
                doc.id,
                studentName,
                teacherName,
              ),
            );
          }

          return sessionReports;
        });
  }

  // 🔥 UPDATE ATTENDANCE STATUS
  Future<void> _updateAttendanceStatus(
    String attendanceId,
    String status,
    String notes,
  ) async {
    try {
      await _firestore.collection('attendance').doc(attendanceId).update({
        'status': status,
        'notes': notes,
        'markedBy': 'Admin',
        'updatedAt': FieldValue.serverTimestamp(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Attendance updated successfully',
            style: AppTextStyles.bodySmall,
          ),
          backgroundColor: AppColors.success,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e', style: AppTextStyles.bodySmall),
          backgroundColor: AppColors.error,
        ),
      );
    }
  }

  // 🔥 UPDATE SESSION REPORT
  Future<void> _updateSessionReport(String reportId, String reportText) async {
    try {
      await _firestore.collection('session_reports').doc(reportId).update({
        'reportText': reportText,
        'updatedAt': FieldValue.serverTimestamp(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Report updated successfully',
            style: AppTextStyles.bodySmall,
          ),
          backgroundColor: AppColors.success,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e', style: AppTextStyles.bodySmall),
          backgroundColor: AppColors.error,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(),
            const SizedBox(height: 16),
            _buildTabs(),
            const SizedBox(height: 16),
            Expanded(
              child: selectedTab == 0
                  ? _buildAttendanceLog()
                  : _buildSessionReports(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Reports & Attendance',
              style: AppTextStyles.heading3.copyWith(
                color: AppColors.text,
                fontSize: 22,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'Track attendance and view session reports',
              style: AppTextStyles.bodyMedium.copyWith(
                color: AppColors.subtitle,
                fontSize: 12,
              ),
            ),
          ],
        ),
        Row(
          children: [
            // Export Button
            OutlinedButton.icon(
              onPressed: () => _showExportDialog(),
              icon: Icon(Icons.download, size: 16),
              label: Text('Export', style: AppTextStyles.bodySmall),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.primary,
                side: BorderSide(color: AppColors.primary),
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 10,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
            const SizedBox(width: 12),
            // Date Display
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: AppColors.card,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.calendar_today,
                    color: AppColors.primary,
                    size: 16,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    'Today: ${DateFormat('dd/MM/yyyy').format(DateTime.now())}',
                    style: AppTextStyles.bodySmall.copyWith(
                      color: AppColors.text,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildTabs() {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Expanded(
            child: _buildTabButton(
              0,
              'Attendance Log',
              Icons.fact_check_outlined,
            ),
          ),
          Expanded(
            child: _buildTabButton(
              1,
              'Session Reports',
              Icons.description_outlined,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabButton(int index, String label, IconData icon) {
    final isSelected = selectedTab == index;
    return InkWell(
      onTap: () => setState(() => selectedTab = index),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primary : AppColors.transparent,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: isSelected ? AppColors.white : AppColors.subtitle,
              size: 18,
            ),
            const SizedBox(width: 6),
            Text(
              label,
              style: AppTextStyles.labelText.copyWith(
                color: isSelected ? AppColors.white : AppColors.text,
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAttendanceLog() {
    return Column(
      children: [
        _buildCompactAttendanceFilters(),
        const SizedBox(height: 12),
        // 🔥 ATTENDANCE STATS WITH STREAM
        SizedBox(
          height: 100,
          child: StreamBuilder<List<AttendanceRecord>>(
            stream: getAttendanceStream(),
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return Text('Error: ${snapshot.error}');
              }

              final attendanceRecords = snapshot.data ?? [];

              final totalSessions = attendanceRecords.length;
              final attendedSessions = attendanceRecords
                  .where((a) => a.status == 'Attended')
                  .length;
              final absentWithApology = attendanceRecords
                  .where((a) => a.status == 'Absent with apology')
                  .length;
              final absentWithoutApology = attendanceRecords
                  .where((a) => a.status == 'Absent without apology')
                  .length;

              return _buildCompactAttendanceStats(
                totalSessions,
                attendedSessions,
                absentWithApology,
                absentWithoutApology,
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        Expanded(child: _buildCompactAttendanceTable()),
      ],
    );
  }

  Widget _buildCompactAttendanceFilters() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border.withOpacity(0.5)),
      ),
      child: Row(
        children: [
          // Search
          Expanded(
            flex: 2,
            child: TextField(
              onChanged: (value) => setState(() => searchQuery = value),
              decoration: InputDecoration(
                hintText: 'Search by student or teacher name...',
                hintStyle: AppTextStyles.bodySmall.copyWith(fontSize: 12),
                prefixIcon: Icon(
                  Icons.search,
                  color: AppColors.subtitle,
                  size: 18,
                ),
                filled: true,
                fillColor: AppColors.background,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: AppColors.border),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: AppColors.border),
                ),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 10,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),

          // Status Filter
          Expanded(
            child: _buildCompactFilterDropdown(
              'Status',
              selectedStatusFilter,
              [
                'All',
                'Attended',
                'Absent with apology',
                'Absent without apology',
              ],
              (value) => setState(() => selectedStatusFilter = value!),
            ),
          ),
          const SizedBox(width: 12),

          // Date Filter
          Expanded(
            child: _buildCompactFilterDropdown(
              'Date Range',
              selectedDateFilter,
              ['All Time', 'Today', 'This Week', 'This Month'],
              (value) => setState(() => selectedDateFilter = value!),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCompactFilterDropdown(
    String label,
    String value,
    List<String> items,
    Function(String?) onChanged,
  ) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppColors.border),
      ),
      child: DropdownButtonFormField<String>(
        initialValue: value,
        items: items
            .map(
              (item) => DropdownMenuItem(
                value: item,
                child: Text(item, 
                  style: AppTextStyles.bodySmall.copyWith(fontSize: 12)),
              ),
            )
            .toList(),
        onChanged: onChanged,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: AppTextStyles.captionText.copyWith(fontSize: 10),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 8,
          ),
        ),
        dropdownColor: AppColors.card,
      ),
    );
  }

  Widget _buildCompactAttendanceStats(
    int totalSessions,
    int attendedSessions,
    int absentWithApology,
    int absentWithoutApology,
  ) {
    return Row(
      children: [
        _buildCompactStatCard('Total', '$totalSessions', Icons.event_available, AppColors.primary),
        const SizedBox(width: 8),
        _buildCompactStatCard('Attended', '$attendedSessions', Icons.check_circle, Color(0xFF10B981)),
        const SizedBox(width: 8),
        _buildCompactStatCard('With Apology', '$absentWithApology', Icons.event_busy, Color(0xFFF59E0B)),
        const SizedBox(width: 8),
        _buildCompactStatCard('Without Apology', '$absentWithoutApology', Icons.cancel, Color(0xFFEF4444)),
      ],
    );
  }

  Widget _buildCompactStatCard(String title, String value, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppColors.border.withOpacity(0.5)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Icon(icon, color: color, size: 16),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    value,
                    style: AppTextStyles.heading2.copyWith(
                      color: AppColors.text,
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    title,
                    style: AppTextStyles.captionText.copyWith(
                      color: AppColors.subtitle,
                      fontSize: 10,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCompactAttendanceTable() {
    return StreamBuilder<List<AttendanceRecord>>(
      stream: getAttendanceStream(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(
            child: CircularProgressIndicator(color: AppColors.primary),
          );
        }

        if (snapshot.hasError) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.error_outline, size: 48, color: AppColors.error),
                const SizedBox(height: 12),
                Text(
                  'Error: ${snapshot.error}',
                  style: AppTextStyles.bodySmall,
                ),
              ],
            ),
          );
        }

        final attendanceRecords = snapshot.data ?? [];
        final filteredRecords = _filterAttendanceRecords(attendanceRecords);

        return Container(
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border.withOpacity(0.5)),
          ),
          child: Column(
            children: [
              // Table Header - FIXED HEIGHT
              Container(
                height: 50,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  border: Border(bottom: BorderSide(color: AppColors.border)),
                ),
                child: Row(
                  children: [
                    Expanded(flex: 2, child: _buildCompactTableHeader('Student')),
                    Expanded(flex: 2, child: _buildCompactTableHeader('Teacher')),
                    Expanded(flex: 1, child: _buildCompactTableHeader('Subject')),
                    Expanded(flex: 2, child: _buildCompactTableHeader('Date & Time')),
                    Expanded(flex: 1, child: _buildCompactTableHeader('Status')),
                    Expanded(flex: 1, child: _buildCompactTableHeader('Actions')),
                  ],
                ),
              ),

              // Table Body - SCROLLABLE with remaining height
              Expanded(
                child: filteredRecords.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.event_busy,
                              size: 48,
                              color: AppColors.subtitle,
                            ),
                            const SizedBox(height: 12),
                            Text(
                              'No attendance records found',
                              style: AppTextStyles.bodyMedium.copyWith(
                                color: AppColors.subtitle,
                              ),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        itemCount: filteredRecords.length,
                        itemBuilder: (context, index) {
                          final attendance = filteredRecords[index];
                          return Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                            decoration: BoxDecoration(
                              border: Border(
                                bottom: BorderSide(color: AppColors.border.withOpacity(0.3)),
                              ),
                            ),
                            child: _buildCompactAttendanceRow(attendance),
                          );
                        },
                      ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildCompactTableHeader(String title) {
    return Text(
      title,
      style: AppTextStyles.labelText.copyWith(
        color: AppColors.text,
        fontSize: 11,
        fontWeight: FontWeight.w600,
      ),
    );
  }

  Widget _buildCompactAttendanceRow(AttendanceRecord attendance) {
    Color statusColor;
    IconData statusIcon;

    switch (attendance.status) {
      case 'Attended':
        statusColor = const Color(0xFF10B981);
        statusIcon = Icons.check_circle;
        break;
      case 'Absent with apology':
        statusColor = const Color(0xFFF59E0B);
        statusIcon = Icons.event_busy;
        break;
      case 'Absent without apology':
        statusColor = const Color(0xFFEF4444);
        statusIcon = Icons.cancel;
        break;
      default:
        statusColor = AppColors.subtitle;
        statusIcon = Icons.help_outline;
    }

    return Row(
      children: [
        Expanded(
          flex: 2,
          child: Text(
            attendance.studentName,
            style: AppTextStyles.bodyMedium.copyWith(
              color: AppColors.text,
              fontSize: 11,
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ),
        Expanded(
          flex: 2,
          child: Text(
            attendance.teacherName,
            style: AppTextStyles.bodyMedium.copyWith(
              color: AppColors.text,
              fontSize: 11,
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ),
        Expanded(
          flex: 1,
          child: Text(
            attendance.subject,
            style: AppTextStyles.bodyMedium.copyWith(
              color: AppColors.subtitle,
              fontSize: 10,
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ),
        Expanded(
          flex: 2,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                attendance.date,
                style: AppTextStyles.bodySmall.copyWith(
                  color: AppColors.text,
                  fontSize: 10,
                ),
              ),
              Text(
                attendance.time,
                style: AppTextStyles.captionText.copyWith(
                  color: AppColors.subtitle,
                  fontSize: 9,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          flex: 1,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(statusIcon, size: 12, color: statusColor),
                const SizedBox(width: 4),
                Flexible(
                  child: Text(
                    _getStatusAbbreviation(attendance.status),
                    style: AppTextStyles.captionText.copyWith(
                      color: statusColor,
                      fontSize: 9,
                      fontWeight: FontWeight.w600,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
        ),
        Expanded(
          flex: 1,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              IconButton(
                icon: Icon(Icons.visibility_outlined, size: 16),
                onPressed: () => _showAttendanceDetails(attendance),
                color: AppColors.primary,
                tooltip: 'View Details',
                padding: EdgeInsets.zero,
                constraints: BoxConstraints(),
              ),
              IconButton(
                icon: Icon(Icons.edit_outlined, size: 16),
                onPressed: () => _showEditAttendanceDialog(attendance),
                color: AppColors.subtitle,
                tooltip: 'Edit Status',
                padding: EdgeInsets.zero,
                constraints: BoxConstraints(),
              ),
            ],
          ),
        ),
      ],
    );
  }

  String _getStatusAbbreviation(String status) {
    switch (status) {
      case 'Attended':
        return 'Attended';
      case 'Absent with apology':
        return 'With Apology';
      case 'Absent without apology':
        return 'No Apology';
      default:
        return status;
    }
  }

  Widget _buildSessionReports() {
    return Column(
      children: [
        _buildCompactReportsFilters(),
        const SizedBox(height: 12),
        Expanded(child: _buildReportsList()),
      ],
    );
  }

  Widget _buildCompactReportsFilters() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border.withOpacity(0.5)),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: TextField(
              onChanged: (value) => setState(() => searchQuery = value),
              decoration: InputDecoration(
                hintText: 'Search reports...',
                hintStyle: AppTextStyles.bodySmall.copyWith(fontSize: 12),
                prefixIcon: Icon(
                  Icons.search,
                  color: AppColors.subtitle,
                  size: 18,
                ),
                filled: true,
                fillColor: AppColors.background,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: AppColors.border),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: AppColors.border),
                ),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 10,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildCompactFilterDropdown(
              'Date Range',
              selectedDateFilter,
              ['All Time', 'Today', 'This Week', 'This Month'],
              (value) => setState(() => selectedDateFilter = value!),
            ),
          ),
        ],
      ),
    );
  }

  // Rest of the methods remain the same as your original code...
  // (_buildReportsList, _filterSessionReports, _buildReportCard, dialog methods, etc.)

  List<AttendanceRecord> _filterAttendanceRecords(
    List<AttendanceRecord> records,
  ) {
    if (searchQuery.isEmpty && selectedStatusFilter == 'All') {
      return records;
    }

    return records.where((record) {
      final matchesSearch =
          searchQuery.isEmpty ||
          record.studentName.toLowerCase().contains(
            searchQuery.toLowerCase(),
          ) ||
          record.teacherName.toLowerCase().contains(searchQuery.toLowerCase());

      final matchesFilter =
          selectedStatusFilter == 'All' ||
          record.status == selectedStatusFilter;

      return matchesSearch && matchesFilter;
    }).toList();
  }

  Widget _buildReportsList() {
    return StreamBuilder<List<SessionReport>>(
      stream: getSessionReportsStream(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(
            child: CircularProgressIndicator(color: AppColors.primary),
          );
        }

        if (snapshot.hasError) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.error_outline, size: 48, color: AppColors.error),
                const SizedBox(height: 12),
                Text(
                  'Error: ${snapshot.error}',
                  style: AppTextStyles.bodySmall,
                ),
              ],
            ),
          );
        }

        final sessionReports = snapshot.data ?? [];
        final filteredReports = _filterSessionReports(sessionReports);

        return ListView.builder(
          itemCount: filteredReports.length,
          itemBuilder: (context, index) {
            final report = filteredReports[index];
            return _buildReportCard(report);
          },
        );
      },
    );
  }

  List<SessionReport> _filterSessionReports(List<SessionReport> reports) {
    if (searchQuery.isEmpty) {
      return reports;
    }

    return reports.where((report) {
      return report.studentName.toLowerCase().contains(
            searchQuery.toLowerCase(),
          ) ||
          report.teacherName.toLowerCase().contains(
            searchQuery.toLowerCase(),
          ) ||
          report.subject.toLowerCase().contains(searchQuery.toLowerCase()) ||
          report.reportText.toLowerCase().contains(searchQuery.toLowerCase());
    }).toList();
  }

  Widget _buildReportCard(SessionReport report) {
    final progress = report.packageTotal > 0
        ? report.sessionsCompleted / report.packageTotal
        : 0;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border.withOpacity(0.5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header Row
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppColors.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  Icons.description,
                  color: AppColors.primary,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      report.studentName,
                      style: AppTextStyles.heading6.copyWith(
                        color: AppColors.text,
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(
                          Icons.person_outline,
                          size: 12,
                          color: AppColors.subtitle,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          report.teacherName,
                          style: AppTextStyles.captionText.copyWith(
                            color: AppColors.subtitle,
                            fontSize: 10,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Icon(
                          Icons.book_outlined,
                          size: 12,
                          color: AppColors.subtitle,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          report.subject,
                          style: AppTextStyles.captionText.copyWith(
                            color: AppColors.subtitle,
                            fontSize: 10,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    report.date,
                    style: AppTextStyles.bodySmall.copyWith(
                      color: AppColors.text,
                      fontSize: 11,
                    ),
                  ),
                  Text(
                    report.time,
                    style: AppTextStyles.captionText.copyWith(
                      color: AppColors.subtitle,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ],
          ),

          const SizedBox(height: 16),

          // Report Text
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.background,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.border),
            ),
            child: Text(
              report.reportText,
              style: AppTextStyles.bodyMedium.copyWith(
                color: AppColors.text,
                fontSize: 12,
                height: 1.4,
              ),
            ),
          ),

          const SizedBox(height: 16),

          // Progress Section
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Package Progress',
                          style: AppTextStyles.labelText.copyWith(
                            color: AppColors.text,
                            fontSize: 11,
                          ),
                        ),
                        Text(
                          '${report.sessionsCompleted}/${report.packageTotal} sessions',
                          style: AppTextStyles.labelText.copyWith(
                            color: AppColors.primary,
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: LinearProgressIndicator(
                        value: progress.toDouble(),
                        backgroundColor: AppColors.border,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          AppColors.primary,
                        ),
                        minHeight: 6,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 16),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: AppColors.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppColors.primary.withOpacity(0.3)),
                ),
                child: Column(
                  children: [
                    Text(
                      '${report.sessionsRemaining}',
                      style: AppTextStyles.heading4.copyWith(
                        color: AppColors.primary,
                        fontSize: 16,
                      ),
                    ),
                    Text(
                      'Remaining',
                      style: AppTextStyles.captionText.copyWith(
                        color: AppColors.primary,
                        fontSize: 9,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 12),

          // Action Buttons
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.event, size: 12, color: AppColors.subtitle),
                  const SizedBox(width: 4),
                  Text(
                    'Next Session: ${report.nextSession}',
                    style: AppTextStyles.captionText.copyWith(
                      color: AppColors.subtitle,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  TextButton.icon(
                    onPressed: () => _showEditReportDialog(report),
                    icon: Icon(Icons.edit_outlined, size: 14),
                    label: Text('Edit Report', style: AppTextStyles.bodySmall.copyWith(fontSize: 11)),
                    style: TextButton.styleFrom(
                      foregroundColor: AppColors.primary,
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                    ),
                  ),
                  const SizedBox(width: 6),
                  OutlinedButton.icon(
                    onPressed: () => _showReportDetails(report),
                    icon: Icon(Icons.visibility_outlined, size: 14),
                    label: Text('View Full', style: AppTextStyles.bodySmall.copyWith(fontSize: 11)),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.primary,
                      side: BorderSide(color: AppColors.primary),
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(6),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  // Dialog Methods (remain the same as your original code)
  void _showAttendanceDetails(AttendanceRecord attendance) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Attendance Details', style: AppTextStyles.heading5),
        content: SizedBox(
          width: 500,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildDetailRow('Student:', attendance.studentName),
              _buildDetailRow('Teacher:', attendance.teacherName),
              _buildDetailRow('Subject:', attendance.subject),
              _buildDetailRow('Date:', attendance.date),
              _buildDetailRow('Time:', attendance.time),
              _buildDetailRow('Status:', attendance.status),
              _buildDetailRow('Marked By:', attendance.markedBy),
              const SizedBox(height: 16),
              Text(
                'Notes:',
                style: AppTextStyles.labelText.copyWith(
                  color: AppColors.text,
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.background,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppColors.border),
                ),
                child: Text(
                  attendance.notes.isEmpty
                      ? 'No notes available'
                      : attendance.notes,
                  style: AppTextStyles.bodyMedium.copyWith(
                    color: AppColors.text,
                    fontSize: 13,
                  ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Close'),
          ),
          ElevatedButton(
            onPressed: () => _showEditAttendanceDialog(attendance),
            child: Text('Edit Status'),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 80,
            child: Text(
              label,
              style: AppTextStyles.labelText.copyWith(
                color: AppColors.subtitle,
                fontSize: 12,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              value,
              style: AppTextStyles.bodyMedium.copyWith(
                color: AppColors.text,
                fontSize: 13,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showEditAttendanceDialog(AttendanceRecord attendance) {
    String selectedStatus = attendance.status;
    TextEditingController notesController = TextEditingController(
      text: attendance.notes,
    );

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Edit Attendance Status', style: AppTextStyles.heading5),
        content: SizedBox(
          width: 400,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildDetailRow('Student:', attendance.studentName),
              _buildDetailRow('Teacher:', attendance.teacherName),
              _buildDetailRow('Date:', '${attendance.date} ${attendance.time}'),
              const SizedBox(height: 16),

              // Status Selection
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Status',
                    style: AppTextStyles.labelText.copyWith(
                      color: AppColors.text,
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    decoration: BoxDecoration(
                      color: AppColors.background,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: DropdownButtonFormField<String>(
                      initialValue: selectedStatus,
                      items: [
                        DropdownMenuItem(
                          value: 'Attended',
                          child: Row(
                            children: [
                              Icon(
                                Icons.check_circle,
                                color: Color(0xFF10B981),
                                size: 18,
                              ),
                              const SizedBox(width: 8),
                              Text('Attended'),
                            ],
                          ),
                        ),
                        DropdownMenuItem(
                          value: 'Absent with apology',
                          child: Row(
                            children: [
                              Icon(
                                Icons.event_busy,
                                color: Color(0xFFF59E0B),
                                size: 18,
                              ),
                              const SizedBox(width: 8),
                              Text('Absent with apology'),
                            ],
                          ),
                        ),
                        DropdownMenuItem(
                          value: 'Absent without apology',
                          child: Row(
                            children: [
                              Icon(
                                Icons.cancel,
                                color: Color(0xFFEF4444),
                                size: 18,
                              ),
                              const SizedBox(width: 8),
                              Text('Absent without apology'),
                            ],
                          ),
                        ),
                      ],
                      onChanged: (value) => selectedStatus = value!,
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 12,
                        ),
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 16),

              // Notes
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Notes',
                    style: AppTextStyles.labelText.copyWith(
                      color: AppColors.text,
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: notesController,
                    maxLines: 3,
                    decoration: InputDecoration(
                      hintText: 'Add notes...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: AppColors.border),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: AppColors.border),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              _updateAttendanceStatus(
                attendance.id,
                selectedStatus,
                notesController.text,
              );
              Navigator.of(context).pop();
            },
            child: Text('Save Changes'),
          ),
        ],
      ),
    );
  }

  void _showEditReportDialog(SessionReport report) {
    TextEditingController reportController = TextEditingController(
      text: report.reportText,
    );

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Edit Session Report', style: AppTextStyles.heading5),
        content: SizedBox(
          width: 600,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildDetailRow('Student:', report.studentName),
              _buildDetailRow('Teacher:', report.teacherName),
              _buildDetailRow('Date:', '${report.date} ${report.time}'),
              _buildDetailRow('Subject:', report.subject),
              const SizedBox(height: 16),

              Text(
                'Session Report',
                style: AppTextStyles.labelText.copyWith(
                  color: AppColors.text,
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                height: 200,
                child: TextField(
                  controller: reportController,
                  maxLines: null,
                  expands: true,
                  textAlignVertical: TextAlignVertical.top,
                  decoration: InputDecoration(
                    hintText: 'Enter session report...',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: AppColors.border),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: AppColors.border),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              _updateSessionReport(report.id, reportController.text);
              Navigator.of(context).pop();
            },
            child: Text('Save Report'),
          ),
        ],
      ),
    );
  }

  void _showReportDetails(SessionReport report) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Session Report Details', style: AppTextStyles.heading5),
        content: SizedBox(
          width: 600,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildDetailRow('Student:', report.studentName),
                _buildDetailRow('Teacher:', report.teacherName),
                _buildDetailRow('Date:', report.date),
                _buildDetailRow('Time:', report.time),
                _buildDetailRow('Subject:', report.subject),
                _buildDetailRow(
                  'Sessions Completed:',
                  '${report.sessionsCompleted}/${report.packageTotal}',
                ),
                _buildDetailRow(
                  'Sessions Remaining:',
                  '${report.sessionsRemaining}',
                ),
                _buildDetailRow('Next Session:', report.nextSession),
                const SizedBox(height: 16),

                Text(
                  'Teacher Report:',
                  style: AppTextStyles.labelText.copyWith(
                    color: AppColors.text,
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.background,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Text(
                    report.reportText,
                    style: AppTextStyles.bodyMedium.copyWith(
                      color: AppColors.text,
                      fontSize: 13,
                      height: 1.5,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Close'),
          ),
          ElevatedButton(
            onPressed: () => _showEditReportDialog(report),
            child: Text('Edit Report'),
          ),
        ],
      ),
    );
  }

  void _showExportDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Export Data', style: AppTextStyles.heading5),
        content: SizedBox(
          width: 400,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Choose export format and date range',
                style: AppTextStyles.bodyMedium.copyWith(
                  color: AppColors.subtitle,
                ),
              ),
              const SizedBox(height: 20),

              // Export Type
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Export Type',
                    style: AppTextStyles.labelText.copyWith(
                      color: AppColors.text,
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    decoration: BoxDecoration(
                      color: AppColors.background,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: DropdownButtonFormField<String>(
                      initialValue: 'CSV',
                      items: ['CSV', 'Excel', 'PDF']
                          .map(
                            (format) => DropdownMenuItem(
                              value: format,
                              child: Text(format),
                            ),
                          )
                          .toList(),
                      onChanged: (value) {},
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 12,
                        ),
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 16),

              // Date Range
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Date Range',
                    style: AppTextStyles.labelText.copyWith(
                      color: AppColors.text,
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    decoration: BoxDecoration(
                      color: AppColors.background,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: DropdownButtonFormField<String>(
                      initialValue: 'This Month',
                      items:
                          [
                                'Today',
                                'This Week',
                                'This Month',
                                'Last Month',
                                'Custom',
                              ]
                              .map(
                                (range) => DropdownMenuItem(
                                  value: range,
                                  child: Text(range),
                                ),
                              )
                              .toList(),
                      onChanged: (value) {},
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 12,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Export started successfully'),
                  backgroundColor: AppColors.primary,
                  behavior: SnackBarBehavior.floating,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              );
            },
            child: Text('Export Data'),
          ),
        ],
      ),
    );
  }
}

// 🔥 ATTENDANCE RECORD MODEL
class AttendanceRecord {
  final String id;
  final String studentId;
  final String studentName;
  final String teacherId;
  final String teacherName;
  final String date;
  final String time;
  final String subject;
  final String status;
  final String markedBy;
  final String notes;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  AttendanceRecord({
    required this.id,
    required this.studentId,
    required this.studentName,
    required this.teacherId,
    required this.teacherName,
    required this.date,
    required this.time,
    required this.subject,
    required this.status,
    required this.markedBy,
    required this.notes,
    this.createdAt,
    this.updatedAt,
  });

  factory AttendanceRecord.fromFirestore(
    Map<String, dynamic> data,
    String id,
    String studentName,
    String teacherName,
  ) {
    return AttendanceRecord(
      id: id,
      studentId: data['studentId']?.toString() ?? '',
      studentName: studentName,
      teacherId: data['teacherId']?.toString() ?? '',
      teacherName: teacherName,
      date: data['date']?.toString() ?? '',
      time: data['time']?.toString() ?? '',
      subject: data['subject']?.toString() ?? '',
      status: data['status']?.toString() ?? 'Attended',
      markedBy: data['markedBy']?.toString() ?? 'System',
      notes: data['notes']?.toString() ?? '',
      createdAt: data['createdAt']?.toDate(),
      updatedAt: data['updatedAt']?.toDate(),
    );
  }
}

// 🔥 SESSION REPORT MODEL
class SessionReport {
  final String id;
  final String studentId;
  final String studentName;
  final String teacherId;
  final String teacherName;
  final String date;
  final String time;
  final String subject;
  final String reportText;
  final int sessionsCompleted;
  final int sessionsRemaining;
  final int packageTotal;
  final String nextSession;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  SessionReport({
    required this.id,
    required this.studentId,
    required this.studentName,
    required this.teacherId,
    required this.teacherName,
    required this.date,
    required this.time,
    required this.subject,
    required this.reportText,
    required this.sessionsCompleted,
    required this.sessionsRemaining,
    required this.packageTotal,
    required this.nextSession,
    this.createdAt,
    this.updatedAt,
  });

  factory SessionReport.fromFirestore(
    Map<String, dynamic> data,
    String id,
    String studentName,
    String teacherName,
  ) {
    return SessionReport(
      id: id,
      studentId: data['studentId']?.toString() ?? '',
      studentName: studentName,
      teacherId: data['teacherId']?.toString() ?? '',
      teacherName: teacherName,
      date: data['date']?.toString() ?? '',
      time: data['time']?.toString() ?? '',
      subject: data['subject']?.toString() ?? '',
      reportText: data['reportText']?.toString() ?? '',
      sessionsCompleted: (data['sessionsCompleted'] as num?)?.toInt() ?? 0,
      sessionsRemaining: (data['sessionsRemaining'] as num?)?.toInt() ?? 0,
      packageTotal: (data['packageTotal'] as num?)?.toInt() ?? 0,
      nextSession: data['nextSession']?.toString() ?? '',
      createdAt: data['createdAt']?.toDate(),
      updatedAt: data['updatedAt']?.toDate(),
    );
  }
}