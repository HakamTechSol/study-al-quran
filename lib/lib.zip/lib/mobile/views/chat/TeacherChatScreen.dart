// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:intl/intl.dart';
// import 'package:studyalquran/utils/app_text_styles.dart';

// class TeacherChatDetailScreen extends StatefulWidget {
//   final String otherUserId;
//   final String otherUserName;
//   final String currentUserId;
//   final String currentUserRole;

//   const TeacherChatDetailScreen({
//     super.key,
//     required this.otherUserId,
//     required this.otherUserName,
//     required this.currentUserId,
//     required this.currentUserRole,
//   });

//   @override
//   State<TeacherChatDetailScreen> createState() => _TeacherChatDetailScreenState();
// }

// class _TeacherChatDetailScreenState extends State<TeacherChatDetailScreen> {
//   final TextEditingController _messageController = TextEditingController();
//   final ScrollController _scrollController = ScrollController();
//   final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
//   bool _isSending = false;
//   late String chatId;

//   // VIP Teacher Theme - Light Cream/Yellow Luxury
//   final Color _vipBg = const Color(0xFFFFFDF7);
//   final Color _vipGold = const Color(0xFFFFD700);
//   final Color _vipCream = const Color(0xFFFFF8DC);
//   final Color _vipAccent = const Color(0xFFFFE57F);
//   final Color _vipDark = const Color(0xFF8B7355);
//   final Color _vipLight = const Color(0xFFFFFAF0);
//   final Color _vipMessageBg = const Color(0xFFFFF9C4);
//   final Color _vipCardBg = const Color(0xFFFFF8E1);

//   @override
//   void initState() {
//     super.initState();
//     chatId = _getChatId(widget.currentUserId, widget.otherUserId);
//     _markMessagesAsRead();
//     _scrollToBottom();
//   }

//   @override
//   void dispose() {
//     _messageController.dispose();
//     _scrollController.dispose();
//     super.dispose();
//   }

//   String _getChatId(String userId1, String userId2) {
//     final ids = [userId1, userId2]..sort();
//     return '${ids[0]}_${ids[1]}';
//   }

//   Future<void> _markMessagesAsRead() async {
//     try {
//       await _firestore.collection('chats').doc(chatId).set({
//         'unreadCount_teacher': 0,
//         'lastReadTime_teacher': FieldValue.serverTimestamp(),
//       }, SetOptions(merge: true));
//     } catch (e) {
//       debugPrint('Error marking messages as read: $e');
//     }
//   }

//   void _scrollToBottom() {
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       if (_scrollController.hasClients) {
//         _scrollController.animateTo(
//           _scrollController.position.maxScrollExtent,
//           duration: const Duration(milliseconds: 300),
//           curve: Curves.easeOut,
//         );
//       }
//     });
//   }

//   Future<void> _sendMessage({
//     String? customText,
//     String messageType = 'text',
//   }) async {
//     final text = customText ?? _messageController.text.trim();
//     if (text.isEmpty) return;

//     setState(() => _isSending = true);

//     try {
//       final messageId = DateTime.now().millisecondsSinceEpoch.toString();
      
//       await _firestore
//           .collection('chats')
//           .doc(chatId)
//           .collection('messages')
//           .doc(messageId)
//           .set({
//         'messageId': messageId,
//         'text': text,
//         'senderId': widget.currentUserId,
//         'senderRole': widget.currentUserRole,
//         'messageType': messageType,
//         'timestamp': FieldValue.serverTimestamp(),
//         'read': false,
//       });

//       String displayMessage = text;
//       if (messageType == 'report') {
//         displayMessage = '📋 Session Report';
//       } else if (messageType == 'zoom_link') {
//         displayMessage = '🔔 Session Starting';
//       } else if (text.length > 50) {
//         displayMessage = '${text.substring(0, 50)}...';
//       }

//       await _firestore.collection('chats').doc(chatId).set({
//         'chatId': chatId,
//         'teacherId': widget.currentUserId,
//         'studentId': widget.otherUserId,
//         'lastMessage': displayMessage,
//         'lastMessageTime': FieldValue.serverTimestamp(),
//         'lastMessageSenderId': widget.currentUserId,
//         'unreadCount_student': FieldValue.increment(1),
//         'unreadCount_teacher': 0,
//       }, SetOptions(merge: true));

//       _messageController.clear();
//       _scrollToBottom();
//     } catch (e) {
//       _showSnackBar('Failed to send message', isError: true);
//       debugPrint('Error sending message: $e');
//     } finally {
//       setState(() => _isSending = false);
//     }
//   }

//   void _showSnackBar(String message, {bool isError = false}) {
//     if (!mounted) return;
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         content: Text(message),
//         backgroundColor: isError ? Colors.red.shade700 : _vipGold,
//         behavior: SnackBarBehavior.floating,
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//       ),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: _vipBg,
//       appBar: _buildVIPAppBar(),
//       body: Column(
//         children: [
//           Expanded(child: _buildMessagesList()),
//           _buildVIPInputArea(),
//         ],
//       ),
//     );
//   }

//   PreferredSizeWidget _buildVIPAppBar() {
//     return AppBar(
//       backgroundColor: _vipGold,
//       elevation: 8,
//       shadowColor: _vipGold.withOpacity(0.5),
//       leading: IconButton(
//         icon: Icon(Icons.arrow_back, color: _vipDark),
//         onPressed: () => Navigator.pop(context),
//       ),
//       title: Row(
//         children: [
//           Container(
//             width: 44,
//             height: 44,
//             decoration: BoxDecoration(
//               gradient: LinearGradient(
//                 colors: [_vipGold, _vipAccent],
//               ),
//               shape: BoxShape.circle,
//               border: Border.all(color: Colors.white, width: 2),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.black.withOpacity(0.2),
//                   blurRadius: 8,
//                   offset: const Offset(0, 2),
//                 ),
//               ],
//             ),
//             child: Center(
//               child: Text(
//                 _getInitials(widget.otherUserName),
//                 style: AppTextStyles.bodyMedium.copyWith(
//                   color: Colors.white,
//                   fontWeight: FontWeight.bold,
//                   fontSize: 16,
//                 ),
//               ),
//             ),
//           ),
//           const SizedBox(width: 12),
//           Expanded(
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Text(
//                   widget.otherUserName,
//                   style: AppTextStyles.appBarTitle.copyWith(
//                     fontSize: 16,
//                     color: _vipDark,
//                     fontWeight: FontWeight.bold,
//                   ),
//                 ),
//                 Row(
//                   children: [
//                     Icon(Icons.workspace_premium, size: 12, color: _vipDark),
//                     const SizedBox(width: 4),
//                     Text(
//                       'VIP Student',
//                       style: AppTextStyles.captionText.copyWith(
//                         color: _vipDark.withOpacity(0.7),
//                         fontSize: 11,
//                       ),
//                     ),
//                   ],
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//       actions: [
//         IconButton(
//           icon: Icon(Icons.info_outline, color: _vipDark),
//           onPressed: _showStudentInfo,
//         ),
//         PopupMenuButton(
//           icon: Icon(Icons.more_vert, color: _vipDark),
//           color: _vipCardBg,
//           shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//           itemBuilder: (context) => [
//             PopupMenuItem(
//               child: Row(
//                 children: [
//                   Icon(Icons.person, size: 20, color: _vipDark),
//                   const SizedBox(width: 10),
//                   Text('View Profile', style: AppTextStyles.bodySmall),
//                 ],
//               ),
//               onTap: () => _viewStudentProfile(),
//             ),
//             PopupMenuItem(
//               child: Row(
//                 children: [
//                   Icon(Icons.delete_outline, size: 20, color: Colors.red.shade600),
//                   const SizedBox(width: 10),
//                   Text('Clear Chat', style: AppTextStyles.bodySmall),
//                 ],
//               ),
//               onTap: () => Future.delayed(Duration.zero, _clearChat),
//             ),
//           ],
//         ),
//       ],
//     );
//   }

//   Widget _buildMessagesList() {
//     return Container(
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           colors: [_vipLight, _vipBg],
//           begin: Alignment.topCenter,
//           end: Alignment.bottomCenter,
//         ),
//       ),
//       child: StreamBuilder<QuerySnapshot>(
//         stream: _firestore
//             .collection('chats')
//             .doc(chatId)
//             .collection('messages')
//             .orderBy('timestamp', descending: false)
//             .snapshots(),
//         builder: (context, snapshot) {
//           if (snapshot.connectionState == ConnectionState.waiting) {
//             return Center(
//               child: CircularProgressIndicator(
//                 valueColor: AlwaysStoppedAnimation(_vipGold),
//               ),
//             );
//           }

//           if (snapshot.hasError) {
//             return Center(
//               child: Text(
//                 'Error loading messages',
//                 style: AppTextStyles.bodyMedium.copyWith(color: Colors.red),
//               ),
//             );
//           }

//           if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
//             return _buildEmptyChat();
//           }

//           WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());

//           return ListView.builder(
//             controller: _scrollController,
//             padding: const EdgeInsets.all(16),
//             itemCount: snapshot.data!.docs.length,
//             itemBuilder: (context, index) {
//               final messageDoc = snapshot.data!.docs[index];
//               final messageData = messageDoc.data() as Map<String, dynamic>;
//               return _buildMessageBubble(messageData);
//             },
//           );
//         },
//       ),
//     );
//   }

//   Widget _buildEmptyChat() {
//     return Center(
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Container(
//             padding: const EdgeInsets.all(24),
//             decoration: BoxDecoration(
//               color: _vipCream,
//               shape: BoxShape.circle,
//             ),
//             child: Icon(
//               Icons.chat_bubble_outline,
//               size: 64,
//               color: _vipGold,
//             ),
//           ),
//           const SizedBox(height: 24),
//           Text(
//             'Start the conversation',
//             style: AppTextStyles.heading4.copyWith(
//               color: _vipDark,
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//           const SizedBox(height: 8),
//           Text(
//             'Send a message to ${widget.otherUserName}',
//             style: AppTextStyles.bodySmall.copyWith(
//               color: _vipDark.withOpacity(0.6),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildMessageBubble(Map<String, dynamic> messageData) {
//     final text = messageData['text'] ?? '';
//     final senderId = messageData['senderId'] ?? '';
//     final messageType = messageData['messageType'] ?? 'text';
//     final timestamp = messageData['timestamp'] as Timestamp?;
    
//     final isMe = senderId == widget.currentUserId;

//     // System Message (Zoom Link)
//     if (messageType == 'zoom_link') {
//       return Container(
//         margin: const EdgeInsets.symmetric(vertical: 8),
//         padding: const EdgeInsets.all(16),
//         decoration: BoxDecoration(
//           gradient: LinearGradient(
//             colors: [Colors.blue.shade50, Colors.blue.shade100],
//           ),
//           borderRadius: BorderRadius.circular(16),
//           border: Border.all(color: Colors.blue.shade300, width: 2),
//           boxShadow: [
//             BoxShadow(
//               color: Colors.blue.withOpacity(0.2),
//               blurRadius: 8,
//               offset: const Offset(0, 4),
//             ),
//           ],
//         ),
//         child: Row(
//           children: [
//             Container(
//               padding: const EdgeInsets.all(12),
//               decoration: BoxDecoration(
//                 color: Colors.blue.shade600,
//                 borderRadius: BorderRadius.circular(12),
//               ),
//               child: Icon(Icons.videocam, color: Colors.white, size: 24),
//             ),
//             const SizedBox(width: 12),
//             Expanded(
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(
//                     text,
//                     style: AppTextStyles.bodySmall.copyWith(
//                       color: Colors.blue.shade900,
//                       fontSize: 14,
//                       height: 1.5,
//                     ),
//                   ),
//                   if (timestamp != null) ...[
//                     const SizedBox(height: 6),
//                     Text(
//                       _formatTime(timestamp.toDate()),
//                       style: AppTextStyles.captionText.copyWith(
//                         color: Colors.blue.shade700,
//                         fontSize: 10,
//                       ),
//                     ),
//                   ],
//                 ],
//               ),
//             ),
//           ],
//         ),
//       );
//     }

//     // Report Message
//     if (messageType == 'report') {
//       return Container(
//         margin: const EdgeInsets.symmetric(vertical: 8),
//         padding: const EdgeInsets.all(16),
//         decoration: BoxDecoration(
//           gradient: LinearGradient(
//             colors: [Colors.green.shade50, Colors.green.shade100],
//           ),
//           borderRadius: BorderRadius.circular(16),
//           border: Border.all(color: Colors.green.shade300, width: 2),
//           boxShadow: [
//             BoxShadow(
//               color: Colors.green.withOpacity(0.2),
//               blurRadius: 8,
//               offset: const Offset(0, 4),
//             ),
//           ],
//         ),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Row(
//               children: [
//                 Container(
//                   padding: const EdgeInsets.all(10),
//                   decoration: BoxDecoration(
//                     color: Colors.green.shade600,
//                     borderRadius: BorderRadius.circular(12),
//                   ),
//                   child: Icon(Icons.assignment_turned_in, color: Colors.white, size: 22),
//                 ),
//                 const SizedBox(width: 12),
//                 Text(
//                   'Session Report',
//                   style: AppTextStyles.heading4.copyWith(
//                     color: Colors.green.shade900,
//                     fontSize: 15,
//                     fontWeight: FontWeight.bold,
//                   ),
//                 ),
//               ],
//             ),
//             const SizedBox(height: 12),
//             Text(
//               text,
//               style: AppTextStyles.bodySmall.copyWith(
//                 color: Colors.green.shade900,
//                 fontSize: 14,
//                 height: 1.5,
//               ),
//             ),
//             if (timestamp != null) ...[
//               const SizedBox(height: 8),
//               Text(
//                 _formatTime(timestamp.toDate()),
//                 style: AppTextStyles.captionText.copyWith(
//                   color: Colors.green.shade700,
//                   fontSize: 10,
//                 ),
//               ),
//             ],
//           ],
//         ),
//       );
//     }

//     // Regular Text Message
//     return Align(
//       alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
//       child: Container(
//         margin: const EdgeInsets.symmetric(vertical: 4),
//         padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
//         constraints: BoxConstraints(
//           maxWidth: MediaQuery.of(context).size.width * 0.75,
//         ),
//         decoration: BoxDecoration(
//           gradient: isMe
//               ? LinearGradient(colors: [_vipGold, _vipAccent])
//               : null,
//           color: isMe ? null : Colors.white,
//           borderRadius: BorderRadius.only(
//             topLeft: const Radius.circular(20),
//             topRight: const Radius.circular(20),
//             bottomLeft: Radius.circular(isMe ? 20 : 4),
//             bottomRight: Radius.circular(isMe ? 4 : 20),
//           ),
//           border: Border.all(
//             color: isMe ? _vipGold : _vipCream,
//             width: isMe ? 2 : 1,
//           ),
//           boxShadow: [
//             BoxShadow(
//               color: isMe 
//                   ? _vipGold.withOpacity(0.3)
//                   : Colors.black.withOpacity(0.05),
//               blurRadius: 8,
//               offset: const Offset(0, 2),
//             ),
//           ],
//         ),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text(
//               text,
//               style: AppTextStyles.bodyMedium.copyWith(
//                 color: isMe ? Colors.white : _vipDark,
//                 fontSize: 14,
//                 height: 1.4,
//               ),
//             ),
//             if (timestamp != null) ...[
//               const SizedBox(height: 6),
//               Text(
//                 _formatTime(timestamp.toDate()),
//                 style: AppTextStyles.captionText.copyWith(
//                   color: isMe ? Colors.white.withOpacity(0.8) : _vipDark.withOpacity(0.6),
//                   fontSize: 10,
//                 ),
//               ),
//             ],
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildVIPInputArea() {
//     return Container(
//       padding: const EdgeInsets.all(12),
//       decoration: BoxDecoration(
//         color: _vipCardBg,
//         boxShadow: [
//           BoxShadow(
//             color: Colors.black.withOpacity(0.1),
//             blurRadius: 12,
//             offset: const Offset(0, -4),
//           ),
//         ],
//       ),
//       child: SafeArea(
//         child: Column(
//           children: [
//             // Quick Actions
//             Row(
//               children: [
//                 _buildQuickActionButton(
//                   Icons.assignment,
//                   'Report',
//                   Colors.green,
//                   _sendReport,
//                 ),
//                 const SizedBox(width: 8),
//                 _buildQuickActionButton(
//                   Icons.videocam,
//                   'Zoom',
//                   Colors.blue,
//                   _sendZoomLink,
//                 ),
//               ],
//             ),
//             const SizedBox(height: 12),
//             // Input Row
//             Row(
//               children: [
//                 Expanded(
//                   child: Container(
//                     padding: const EdgeInsets.symmetric(horizontal: 16),
//                     decoration: BoxDecoration(
//                       color: _vipLight,
//                       borderRadius: BorderRadius.circular(24),
//                       border: Border.all(color: _vipCream, width: 2),
//                     ),
//                     child: TextField(
//                       controller: _messageController,
//                       style: AppTextStyles.inputValue.copyWith(
//                         fontSize: 14,
//                         color: _vipDark,
//                       ),
//                       maxLines: null,
//                       textInputAction: TextInputAction.newline,
//                       decoration: InputDecoration(
//                         hintText: 'Type your message...',
//                         hintStyle: AppTextStyles.inputHint.copyWith(
//                           fontSize: 13,
//                           color: _vipDark.withOpacity(0.5),
//                         ),
//                         border: InputBorder.none,
//                         contentPadding: const EdgeInsets.symmetric(vertical: 12),
//                       ),
//                     ),
//                   ),
//                 ),
//                 const SizedBox(width: 8),
//                 Container(
//                   decoration: BoxDecoration(
//                     gradient: LinearGradient(colors: [_vipGold, _vipAccent]),
//                     shape: BoxShape.circle,
//                     boxShadow: [
//                       BoxShadow(
//                         color: _vipGold.withOpacity(0.5),
//                         blurRadius: 12,
//                         offset: const Offset(0, 4),
//                       ),
//                     ],
//                   ),
//                   child: IconButton(
//                     icon: _isSending
//                         ? SizedBox(
//                             width: 20,
//                             height: 20,
//                             child: CircularProgressIndicator(
//                               color: Colors.white,
//                               strokeWidth: 2,
//                             ),
//                           )
//                         : Icon(Icons.send, color: Colors.white, size: 22),
//                     onPressed: _isSending ? null : () => _sendMessage(),
//                   ),
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildQuickActionButton(
//     IconData icon,
//     String label,
//     Color color,
//     VoidCallback onPressed,
//   ) {
//     return Expanded(
//       child: InkWell(
//         onTap: onPressed,
//         borderRadius: BorderRadius.circular(12),
//         child: Container(
//           padding: const EdgeInsets.symmetric(vertical: 10),
//           decoration: BoxDecoration(
//             color: color.withOpacity(0.1),
//             borderRadius: BorderRadius.circular(12),
//             border: Border.all(color: color.withOpacity(0.3)),
//           ),
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               Icon(icon, color: color, size: 18),
//               const SizedBox(width: 6),
//               Text(
//                 label,
//                 style: AppTextStyles.bodySmall.copyWith(
//                   color: color,
//                   fontWeight: FontWeight.w600,
//                   fontSize: 12,
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   void _sendReport() {
//     showDialog(
//       context: context,
//       builder: (context) => ReportDialog(onSend: (report) {
//         _sendMessage(customText: report, messageType: 'report');
//       }),
//     );
//   }

//   void _sendZoomLink() {
//     showDialog(
//       context: context,
//       builder: (context) => ZoomLinkDialog(onSend: (zoomMessage) {
//         _sendMessage(customText: zoomMessage, messageType: 'zoom_link');
//       }),
//     );
//   }

//   void _showStudentInfo() {
//     showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         backgroundColor: _vipCardBg,
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
//         title: Row(
//           children: [
//             Icon(Icons.person, color: _vipGold),
//             const SizedBox(width: 8),
//             Text('Student Info', style: AppTextStyles.heading4),
//           ],
//         ),
//         content: Column(
//           mainAxisSize: MainAxisSize.min,
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text('Name: ${widget.otherUserName}', 
//               style: AppTextStyles.bodyMedium),
//             const SizedBox(height: 8),
//             Text('Status: VIP Student', style: AppTextStyles.bodyMedium),
//             const SizedBox(height: 8),
//             Text('Chat ID: $chatId', style: AppTextStyles.captionText),
//           ],
//         ),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(context),
//             child: Text('Close', style: AppTextStyles.buttonSecondary),
//           ),
//         ],
//       ),
//     );
//   }

//   void _viewStudentProfile() {
//     _showSnackBar('Student profile feature coming soon');
//   }

//   Future<void> _clearChat() async {
//     final confirm = await showDialog<bool>(
//       context: context,
//       builder: (context) => AlertDialog(
//         backgroundColor: _vipCardBg,
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
//         title: Text('Clear Chat', 
//           style: AppTextStyles.heading4.copyWith(color: _vipDark)),
//         content: Text(
//           'Are you sure you want to delete all messages? This action cannot be undone.',
//           style: AppTextStyles.bodyMedium.copyWith(color: _vipDark),
//         ),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(context, false),
//             child: Text('Cancel', style: TextStyle(color: _vipDark)),
//           ),
//           ElevatedButton(
//             onPressed: () => Navigator.pop(context, true),
//             style: ElevatedButton.styleFrom(
//               backgroundColor: Colors.red.shade600,
//               shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//             ),
//             child: Text('Delete', style: TextStyle(color: Colors.white)),
//           ),
//         ],
//       ),
//     );

//     if (confirm == true) {
//       try {
//         final messages = await _firestore
//             .collection('chats')
//             .doc(chatId)
//             .collection('messages')
//             .get();

//         final batch = _firestore.batch();
//         for (var doc in messages.docs) {
//           batch.delete(doc.reference);
//         }
//         await batch.commit();

//         // Update chat document
//         await _firestore.collection('chats').doc(chatId).set({
//           'lastMessage': '',
//           'lastMessageTime': FieldValue.serverTimestamp(),
//         }, SetOptions(merge: true));

//         _showSnackBar('Chat cleared successfully');
//       } catch (e) {
//         _showSnackBar('Failed to clear chat', isError: true);
//         debugPrint('Error clearing chat: $e');
//       }
//     }
//   }

//   String _getInitials(String name) {
//     final parts = name.split(' ');
//     if (parts.length >= 2) {
//       return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
//     }
//     return name.isNotEmpty ? name.substring(0, 1).toUpperCase() : 'S';
//   }

//   String _formatTime(DateTime timestamp) {
//     final now = DateTime.now();
//     final diff = now.difference(timestamp);

//     if (diff.inMinutes < 1) {
//       return 'Just now';
//     } else if (diff.inHours < 1) {
//       return '${diff.inMinutes}m ago';
//     } else if (diff.inDays < 1) {
//       return DateFormat('HH:mm').format(timestamp);
//     } else if (diff.inDays == 1) {
//       return 'Yesterday ${DateFormat('HH:mm').format(timestamp)}';
//     } else {
//       return DateFormat('dd/MM HH:mm').format(timestamp);
//     }
//   }
// }

// // Report Dialog
// class ReportDialog extends StatefulWidget {
//   final Function(String) onSend;

//   const ReportDialog({super.key, required this.onSend});

//   @override
//   State<ReportDialog> createState() => _ReportDialogState();
// }

// class _ReportDialogState extends State<ReportDialog> {
//   final _unitController = TextEditingController();
//   final _homeworkController = TextEditingController();
//   final _sessionsLeftController = TextEditingController();

//   @override
//   void dispose() {
//     _unitController.dispose();
//     _homeworkController.dispose();
//     _sessionsLeftController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return AlertDialog(
//       backgroundColor: const Color(0xFFFFF8E1),
//       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
//       title: Row(
//         children: [
//           Container(
//             padding: const EdgeInsets.all(10),
//             decoration: BoxDecoration(
//               color: Colors.green.shade100,
//               borderRadius: BorderRadius.circular(12),
//             ),
//             child: Icon(Icons.assignment, color: Colors.green.shade700, size: 28),
//           ),
//           const SizedBox(width: 12),
//           Text('Session Report',
//               style: AppTextStyles.heading3.copyWith(
//                 fontSize: 18,
//                 color: Colors.brown.shade900,
//               )),
//         ],
//       ),
//       content: SingleChildScrollView(
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             _buildTextField(
//               controller: _unitController,
//               label: 'Unit Completed',
//               hint: 'e.g., Unit 3',
//               icon: Icons.book,
//             ),
//             const SizedBox(height: 16),
//             _buildTextField(
//               controller: _homeworkController,
//               label: 'Homework',
//               hint: 'e.g., Pages 45-50',
//               icon: Icons.assignment_turned_in,
//             ),
//             const SizedBox(height: 16),
//             _buildTextField(
//               controller: _sessionsLeftController,
//               label: 'Sessions Left',
//               hint: 'e.g., 4',
//               icon: Icons.schedule,
//               keyboardType: TextInputType.number,
//             ),
//           ],
//         ),
//       ),
//       actions: [
//         TextButton(
//           onPressed: () => Navigator.pop(context),
//           child: Text('Cancel', 
//             style: AppTextStyles.buttonSecondary.copyWith(
//               color: Colors.brown.shade600,
//             )),
//         ),
//         ElevatedButton(
//           onPressed: () {
//             if (_unitController.text.isEmpty ||
//                 _homeworkController.text.isEmpty ||
//                 _sessionsLeftController.text.isEmpty) {
//               ScaffoldMessenger.of(context).showSnackBar(
//                 SnackBar(
//                   content: Text('Please fill all fields'),
//                   backgroundColor: Colors.red.shade700,
//                 ),
//               );
//               return;
//             }

//             final report = '''📋 Session Report:

// ✅ ${_unitController.text} - Complete
// ✅ Practice exercises done
// 📚 Homework: ${_homeworkController.text}
// ⏳ Sessions remaining: ${_sessionsLeftController.text}

// Keep up the excellent work!''';

//             widget.onSend(report);
//             Navigator.pop(context);
//           },
//           style: ElevatedButton.styleFrom(
//             backgroundColor: Colors.green.shade600,
//             shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//           ),
//           child: Text('Send Report', style: AppTextStyles.buttonPrimary),
//         ),
//       ],
//     );
//   }

//   Widget _buildTextField({
//     required TextEditingController controller,
//     required String label,
//     required String hint,
//     required IconData icon,
//     TextInputType? keyboardType,
//   }) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Text(label, 
//           style: AppTextStyles.labelText.copyWith(
//             fontSize: 13,
//             color: Colors.brown.shade900,
//           )),
//         const SizedBox(height: 8),
//         TextField(
//           controller: controller,
//           keyboardType: keyboardType,
//           style: AppTextStyles.inputValue.copyWith(
//             fontSize: 14,
//             color: Colors.brown.shade900,
//           ),
//           decoration: InputDecoration(
//             hintText: hint,
//             hintStyle: AppTextStyles.inputHint.copyWith(
//               fontSize: 13,
//               color: Colors.brown.shade400,
//             ),
//             prefixIcon: Icon(icon, size: 20, color: Colors.brown.shade600),
//             filled: true,
//             fillColor: Colors.white,
//             border: OutlineInputBorder(
//               borderRadius: BorderRadius.circular(12),
//               borderSide: BorderSide(color: Colors.amber.shade300),
//             ),
//             focusedBorder: OutlineInputBorder(
//               borderRadius: BorderRadius.circular(12),
//               borderSide: BorderSide(color: Colors.green.shade600, width: 2),
//             ),
//             contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
//           ),
//         ),
//       ],
//     );
//   }
// }

// // Zoom Link Dialog
// class ZoomLinkDialog extends StatefulWidget {
//   final Function(String) onSend;

//   const ZoomLinkDialog({super.key, required this.onSend});

//   @override
//   State<ZoomLinkDialog> createState() => _ZoomLinkDialogState();
// }

// class _ZoomLinkDialogState extends State<ZoomLinkDialog> {
//   final _linkController = TextEditingController();
//   final _meetingIdController = TextEditingController();
//   final _passwordController = TextEditingController();

//   @override
//   void dispose() {
//     _linkController.dispose();
//     _meetingIdController.dispose();
//     _passwordController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return AlertDialog(
//       backgroundColor: const Color(0xFFFFF8E1),
//       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
//       title: Row(
//         children: [
//           Container(
//             padding: const EdgeInsets.all(10),
//             decoration: BoxDecoration(
//               color: Colors.blue.shade100,
//               borderRadius: BorderRadius.circular(12),
//             ),
//             child: Icon(Icons.videocam, color: Colors.blue.shade700, size: 28),
//           ),
//           const SizedBox(width: 12),
//           Text('Send Zoom Link',
//               style: AppTextStyles.heading3.copyWith(
//                 fontSize: 18,
//                 color: Colors.brown.shade900,
//               )),
//         ],
//       ),
//       content: SingleChildScrollView(
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             _buildTextField(
//               controller: _linkController,
//               label: 'Zoom Link',
//               hint: 'https://zoom.us/j/...',
//               icon: Icons.link,
//             ),
//             const SizedBox(height: 16),
//             _buildTextField(
//               controller: _meetingIdController,
//               label: 'Meeting ID',
//               hint: 'e.g., 123 456 789',
//               icon: Icons.confirmation_number,
//             ),
//             const SizedBox(height: 16),
//             _buildTextField(
//               controller: _passwordController,
//               label: 'Password (Optional)',
//               hint: 'Enter meeting password',
//               icon: Icons.lock,
//             ),
//           ],
//         ),
//       ),
//       actions: [
//         TextButton(
//           onPressed: () => Navigator.pop(context),
//           child: Text('Cancel',
//             style: AppTextStyles.buttonSecondary.copyWith(
//               color: Colors.brown.shade600,
//             )),
//         ),
//         ElevatedButton(
//           onPressed: () {
//             if (_linkController.text.isEmpty || _meetingIdController.text.isEmpty) {
//               ScaffoldMessenger.of(context).showSnackBar(
//                 SnackBar(
//                   content: Text('Please fill required fields'),
//                   backgroundColor: Colors.red.shade700,
//                 ),
//               );
//               return;
//             }

//             String message = '''🔔 Your session is starting!

// 🔗 Zoom Link: ${_linkController.text}
// 🆔 Meeting ID: ${_meetingIdController.text}''';

//             if (_passwordController.text.isNotEmpty) {
//               message += '\n🔒 Password: ${_passwordController.text}';
//             }

//             message += '\n\nJoin the session now!';

//             widget.onSend(message);
//             Navigator.pop(context);
//           },
//           style: ElevatedButton.styleFrom(
//             backgroundColor: Colors.blue.shade600,
//             shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//           ),
//           child: Text('Send Link', style: AppTextStyles.buttonPrimary),
//         ),
//       ],
//     );
//   }

//   Widget _buildTextField({
//     required TextEditingController controller,
//     required String label,
//     required String hint,
//     required IconData icon,
//   }) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Text(label,
//           style: AppTextStyles.labelText.copyWith(
//             fontSize: 13,
//             color: Colors.brown.shade900,
//           )),
//         const SizedBox(height: 8),
//         TextField(
//           controller: controller,
//           style: AppTextStyles.inputValue.copyWith(
//             fontSize: 14,
//             color: Colors.brown.shade900,
//           ),
//           decoration: InputDecoration(
//             hintText: hint,
//             hintStyle: AppTextStyles.inputHint.copyWith(
//               fontSize: 13,
//               color: Colors.brown.shade400,
//             ),
//             prefixIcon: Icon(icon, size: 20, color: Colors.brown.shade600),
//             filled: true,
//             fillColor: Colors.white,
//             border: OutlineInputBorder(
//               borderRadius: BorderRadius.circular(12),
//               borderSide: BorderSide(color: Colors.amber.shade300),
//             ),
//             focusedBorder: OutlineInputBorder(
//               borderRadius: BorderRadius.circular(12),
//               borderSide: BorderSide(color: Colors.blue.shade600, width: 2),
//             ),
//             contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
//           ),
//         ),
//       ],
//     );
//   }
// }

// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:intl/intl.dart';
// import 'package:studyalquran/utils/app_text_styles.dart';
// import 'package:studyalquran/utils/color_constants.dart';

// class TeacherChatDetailScreen extends StatefulWidget {
//   final String otherUserId;
//   final String otherUserName;
//   final String currentUserId;
//   final String currentUserRole;

//   const TeacherChatDetailScreen({
//     super.key,
//     required this.otherUserId,
//     required this.otherUserName,
//     required this.currentUserId,
//     required this.currentUserRole,
//   });

//   @override
//   State<TeacherChatDetailScreen> createState() => _TeacherChatDetailScreenState();
// }

// class _TeacherChatDetailScreenState extends State<TeacherChatDetailScreen> {
//   final TextEditingController _messageController = TextEditingController();
//   final TextEditingController _searchController = TextEditingController();
//   final ScrollController _scrollController = ScrollController();
//   final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
//   bool _isSending = false;
//   bool _isSearching = false;
//   String _searchQuery = '';
//   late String chatId;
//   Map<String, dynamic>? _studentData;

//   @override
//   void initState() {
//     super.initState();
//     chatId = _getChatId(widget.currentUserId, widget.otherUserId);
//     _markMessagesAsRead();
//     _loadStudentData();
//     _scrollToBottom();
//   }

//   @override
//   void dispose() {
//     _messageController.dispose();
//     _searchController.dispose();
//     _scrollController.dispose();
//     super.dispose();
//   }

//   String _getChatId(String userId1, String userId2) {
//     final ids = [userId1, userId2]..sort();
//     return '${ids[0]}_${ids[1]}';
//   }

//   Future<void> _loadStudentData() async {
//     try {
//       final doc = await _firestore
//           .collection('students')
//           .where('studentId', isEqualTo: widget.otherUserId)
//           .limit(1)
//           .get();
      
//       if (doc.docs.isNotEmpty) {
//         setState(() {
//           _studentData = doc.docs.first.data();
//         });
//       }
//     } catch (e) {
//       debugPrint('Error loading student data: $e');
//     }
//   }

//   Future<void> _markMessagesAsRead() async {
//     try {
//       final messagesSnapshot = await _firestore
//           .collection('chats')
//           .doc(chatId)
//           .collection('messages')
//           .where('senderId', isNotEqualTo: widget.currentUserId)
//           .where('read', isEqualTo: false)
//           .get();

//       final batch = _firestore.batch();
//       for (var doc in messagesSnapshot.docs) {
//         batch.update(doc.reference, {'read': true});
//       }
//       await batch.commit();

//       await _firestore.collection('chats').doc(chatId).set({
//         'unreadCount_teacher': 0,
//         'lastReadTime_teacher': FieldValue.serverTimestamp(),
//       }, SetOptions(merge: true));
//     } catch (e) {
//       debugPrint('Error marking messages as read: $e');
//     }
//   }

//   void _scrollToBottom() {
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       if (_scrollController.hasClients) {
//         _scrollController.animateTo(
//           _scrollController.position.maxScrollExtent,
//           duration: const Duration(milliseconds: 300),
//           curve: Curves.easeOut,
//         );
//       }
//     });
//   }

//   Future<void> _sendMessage({
//     String? customText,
//     String messageType = 'text',
//   }) async {
//     final text = customText ?? _messageController.text.trim();
//     if (text.isEmpty) return;

//     setState(() => _isSending = true);

//     try {
//       final messageId = DateTime.now().millisecondsSinceEpoch.toString();
      
//       await _firestore
//           .collection('chats')
//           .doc(chatId)
//           .collection('messages')
//           .doc(messageId)
//           .set({
//         'messageId': messageId,
//         'text': text,
//         'senderId': widget.currentUserId,
//         'senderRole': widget.currentUserRole,
//         'messageType': messageType,
//         'timestamp': FieldValue.serverTimestamp(),
//         'read': false,
//         'deletedFor': [],
//       });

//       String displayMessage = text;
//       if (messageType == 'report') {
//         displayMessage = '📋 Session Report';
//       } else if (messageType == 'zoom_link') {
//         displayMessage = '🔔 Session Starting';
//       } else if (text.length > 50) {
//         displayMessage = '${text.substring(0, 50)}...';
//       }

//       await _firestore.collection('chats').doc(chatId).set({
//         'chatId': chatId,
//         'teacherId': widget.currentUserId,
//         'studentId': widget.otherUserId,
//         'lastMessage': displayMessage,
//         'lastMessageTime': FieldValue.serverTimestamp(),
//         'lastMessageSenderId': widget.currentUserId,
//         'unreadCount_student': FieldValue.increment(1),
//         'unreadCount_teacher': 0,
//       }, SetOptions(merge: true));

//       _messageController.clear();
//       _scrollToBottom();
//     } catch (e) {
//       _showSnackBar('Failed to send message', isError: true);
//       debugPrint('Error sending message: $e');
//     } finally {
//       setState(() => _isSending = false);
//     }
//   }

//   void _showSnackBar(String message, {bool isError = false}) {
//     if (!mounted) return;
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         content: Text(message),
//         backgroundColor: isError ? AppColors.error : AppColors.success,
//         behavior: SnackBarBehavior.floating,
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
//         margin: const EdgeInsets.all(16),
//       ),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: AppColors.background,
//       appBar: _buildAppBar(),
//       body: Column(
//         children: [
//           if (_isSearching) _buildSearchBar(),
//           Expanded(child: _buildMessagesList()),
//           _buildInputArea(),
//         ],
//       ),
//     );
//   }

//   PreferredSizeWidget _buildAppBar() {
//     return AppBar(
//       backgroundColor: AppColors.primary,
//       elevation: 0,
//       leading: IconButton(
//         icon: const Icon(Icons.arrow_back, color: Colors.white),
//         onPressed: () => Navigator.pop(context),
//       ),
//       title: InkWell(
//         onTap: _viewStudentProfile,
//         child: Row(
//           children: [
//             CircleAvatar(
//               radius: 20,
//               backgroundColor: Colors.white,
//               child: Text(
//                 _getInitials(widget.otherUserName),
//                 style: AppTextStyles.bodyMedium.copyWith(
//                   color: AppColors.primary,
//                   fontWeight: FontWeight.w600,
//                   fontSize: 16,
//                 ),
//               ),
//             ),
//             const SizedBox(width: 12),
//             Expanded(
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(
//                     widget.otherUserName,
//                     style: AppTextStyles.appBarTitle.copyWith(
//                       fontSize: 16,
//                       color: Colors.white,
//                       fontWeight: FontWeight.w600,
//                     ),
//                     maxLines: 1,
//                     overflow: TextOverflow.ellipsis,
//                   ),
//                   Text(
//                     'Tap to view profile',
//                     style: AppTextStyles.captionText.copyWith(
//                       color: Colors.white.withOpacity(0.8),
//                       fontSize: 12,
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//       actions: [
//         IconButton(
//           icon: Icon(
//             _isSearching ? Icons.close : Icons.search,
//             color: Colors.white,
//           ),
//           onPressed: () {
//             setState(() {
//               _isSearching = !_isSearching;
//               if (!_isSearching) {
//                 _searchQuery = '';
//                 _searchController.clear();
//               }
//             });
//           },
//         ),
//         PopupMenuButton(
//           icon: const Icon(Icons.more_vert, color: Colors.white),
//           color: AppColors.card,
//           shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//           itemBuilder: (context) => [
//             PopupMenuItem(
//               child: Row(
//                 children: [
//                   Icon(Icons.person, size: 20, color: AppColors.text),
//                   const SizedBox(width: 12),
//                   Text('View Profile', style: AppTextStyles.bodyMedium),
//                 ],
//               ),
//               onTap: () => Future.delayed(Duration.zero, _viewStudentProfile),
//             ),
//             PopupMenuItem(
//               child: Row(
//                 children: [
//                   Icon(Icons.delete_sweep, size: 20, color: AppColors.warning),
//                   const SizedBox(width: 12),
//                   Text('Clear Chat', style: AppTextStyles.bodyMedium),
//                 ],
//               ),
//               onTap: () => Future.delayed(Duration.zero, _clearChat),
//             ),
//           ],
//         ),
//       ],
//     );
//   }

//   Widget _buildSearchBar() {
//     return Container(
//       color: AppColors.primary,
//       padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
//       child: Container(
//         decoration: BoxDecoration(
//           color: Colors.white,
//           borderRadius: BorderRadius.circular(8),
//         ),
//         child: TextField(
//           controller: _searchController,
//           style: AppTextStyles.bodyMedium.copyWith(color: AppColors.text),
//           decoration: InputDecoration(
//             hintText: 'Search in conversation...',
//             hintStyle: AppTextStyles.inputHint,
//             prefixIcon: Icon(Icons.search, color: AppColors.subtitle),
//             suffixIcon: _searchQuery.isNotEmpty
//                 ? IconButton(
//                     icon: Icon(Icons.clear, color: AppColors.subtitle),
//                     onPressed: () {
//                       _searchController.clear();
//                       setState(() => _searchQuery = '');
//                     },
//                   )
//                 : null,
//             border: InputBorder.none,
//             contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
//           ),
//           onChanged: (value) {
//             setState(() => _searchQuery = value.toLowerCase());
//           },
//         ),
//       ),
//     );
//   }

//   Widget _buildMessagesList() {
//     return Container(
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           colors: [
//             AppColors.background,
//             AppColors.surface,
//           ],
//           begin: Alignment.topCenter,
//           end: Alignment.bottomCenter,
//         ),
//       ),
//       child: StreamBuilder<QuerySnapshot>(
//         stream: _firestore
//             .collection('chats')
//             .doc(chatId)
//             .collection('messages')
//             .orderBy('timestamp', descending: false)
//             .snapshots(),
//         builder: (context, snapshot) {
//           if (snapshot.connectionState == ConnectionState.waiting) {
//             return Center(
//               child: CircularProgressIndicator(
//                 valueColor: AlwaysStoppedAnimation(AppColors.primary),
//               ),
//             );
//           }

//           if (snapshot.hasError) {
//             return Center(
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Icon(Icons.error_outline, size: 48, color: AppColors.error),
//                   const SizedBox(height: 8),
//                   Text(
//                     'Error loading messages',
//                     style: AppTextStyles.bodyMedium.copyWith(color: AppColors.error),
//                   ),
//                 ],
//               ),
//             );
//           }

//           if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
//             return _buildEmptyChat();
//           }

//           var messages = snapshot.data!.docs;

//           // Filter deleted messages for current user
//           messages = messages.where((doc) {
//             final data = doc.data() as Map<String, dynamic>;
//             final deletedFor = List<String>.from(data['deletedFor'] ?? []);
//             return !deletedFor.contains(widget.currentUserId);
//           }).toList();

//           // Filter by search query
//           if (_searchQuery.isNotEmpty) {
//             messages = messages.where((doc) {
//               final data = doc.data() as Map<String, dynamic>;
//               final text = (data['text'] ?? '').toLowerCase();
//               return text.contains(_searchQuery);
//             }).toList();
//           }

//           if (messages.isEmpty && _searchQuery.isNotEmpty) {
//             return Center(
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Icon(Icons.search_off, size: 48, color: AppColors.subtitle),
//                   const SizedBox(height: 8),
//                   Text(
//                     'No messages found',
//                     style: AppTextStyles.bodyMedium.copyWith(color: AppColors.subtitle),
//                   ),
//                 ],
//               ),
//             );
//           }

//           WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());

//           return ListView.builder(
//             controller: _scrollController,
//             padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
//             itemCount: messages.length,
//             itemBuilder: (context, index) {
//               final messageDoc = messages[index];
//               final messageData = messageDoc.data() as Map<String, dynamic>;
//               final previousMessage = index > 0 
//                   ? messages[index - 1].data() as Map<String, dynamic>
//                   : null;
              
//               return _buildMessageBubble(
//                 messageData,
//                 messageDoc.id,
//                 previousMessage,
//               );
//             },
//           );
//         },
//       ),
//     );
//   }

//   Widget _buildEmptyChat() {
//     return Center(
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Icon(
//             Icons.chat_bubble_outline,
//             size: 80,
//             color: AppColors.subtitle.withOpacity(0.3),
//           ),
//           const SizedBox(height: 16),
//           Text(
//             'No messages yet',
//             style: AppTextStyles.heading3.copyWith(
//               color: AppColors.text,
//               fontWeight: FontWeight.w600,
//             ),
//           ),
//           const SizedBox(height: 8),
//           Text(
//             'Start the conversation with ${widget.otherUserName}',
//             style: AppTextStyles.bodySmall.copyWith(
//               color: AppColors.subtitle,
//             ),
//             textAlign: TextAlign.center,
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildMessageBubble(
//     Map<String, dynamic> messageData,
//     String messageId,
//     Map<String, dynamic>? previousMessage,
//   ) {
//     final text = messageData['text'] ?? '';
//     final senderId = messageData['senderId'] ?? '';
//     final messageType = messageData['messageType'] ?? 'text';
//     final timestamp = messageData['timestamp'] as Timestamp?;
//     final isRead = messageData['read'] ?? false;
    
//     final isMe = senderId == widget.currentUserId;
//     final showDateDivider = _shouldShowDateDivider(timestamp, previousMessage);

//     return Column(
//       children: [
//         if (showDateDivider && timestamp != null)
//           _buildDateDivider(timestamp.toDate()),
        
//         GestureDetector(
//           onLongPress: () => _showMessageOptions(messageId, messageData),
//           child: Padding(
//             padding: const EdgeInsets.symmetric(vertical: 2),
//             child: Row(
//               mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
//               crossAxisAlignment: CrossAxisAlignment.end,
//               children: [
//                 if (messageType == 'zoom_link')
//                   _buildSystemMessage(text, timestamp)
//                 else if (messageType == 'report')
//                   _buildReportMessage(text, timestamp, isMe)
//                 else
//                   _buildTextMessage(text, timestamp, isMe, isRead),
//               ],
//             ),
//           ),
//         ),
//       ],
//     );
//   }

//   bool _shouldShowDateDivider(
//     Timestamp? currentTimestamp,
//     Map<String, dynamic>? previousMessage,
//   ) {
//     if (currentTimestamp == null) return false;
//     if (previousMessage == null) return true;

//     final prevTimestamp = previousMessage['timestamp'] as Timestamp?;
//     if (prevTimestamp == null) return true;

//     final current = currentTimestamp.toDate();
//     final previous = prevTimestamp.toDate();

//     return current.year != previous.year ||
//            current.month != previous.month ||
//            current.day != previous.day;
//   }

//   Widget _buildDateDivider(DateTime date) {
//     String dateText;
//     final now = DateTime.now();
//     final diff = now.difference(date);

//     if (diff.inDays == 0) {
//       dateText = 'Today';
//     } else if (diff.inDays == 1) {
//       dateText = 'Yesterday';
//     } else if (diff.inDays < 7) {
//       dateText = DateFormat('EEEE').format(date);
//     } else {
//       dateText = DateFormat('dd/MM/yyyy').format(date);
//     }

//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 12),
//       child: Center(
//         child: Container(
//           padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//           decoration: BoxDecoration(
//             color: const Color(0xFFDCF8C6).withOpacity(0.6),
//             borderRadius: BorderRadius.circular(12),
//           ),
//           child: Text(
//             dateText,
//             style: AppTextStyles.captionText.copyWith(
//               fontSize: 12,
//               fontWeight: FontWeight.w500,
//               color: const Color(0xFF075E54),
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _buildSystemMessage(String text, Timestamp? timestamp) {
//     return Container(
//       margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
//       padding: const EdgeInsets.all(12),
//       constraints: BoxConstraints(
//         maxWidth: MediaQuery.of(context).size.width * 0.85,
//       ),
//       decoration: BoxDecoration(
//         color: const Color(0xFFE3F2FD),
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(color: Colors.blue.shade200),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Row(
//             children: [
//               Icon(Icons.videocam, color: Colors.blue.shade700, size: 20),
//               const SizedBox(width: 8),
//               Text(
//                 'Zoom Session',
//                 style: AppTextStyles.bodyMedium.copyWith(
//                   color: Colors.blue.shade900,
//                   fontWeight: FontWeight.w600,
//                 ),
//               ),
//             ],
//           ),
//           const SizedBox(height: 8),
//           Text(
//             text,
//             style: AppTextStyles.bodySmall.copyWith(
//               color: Colors.blue.shade900,
//               fontSize: 13,
//             ),
//           ),
//           if (timestamp != null) ...[
//             const SizedBox(height: 6),
//             Text(
//               _formatTime(timestamp.toDate()),
//               style: AppTextStyles.captionText.copyWith(
//                 color: Colors.blue.shade700,
//                 fontSize: 11,
//               ),
//             ),
//           ],
//         ],
//       ),
//     );
//   }

//   Widget _buildReportMessage(String text, Timestamp? timestamp, bool isMe) {
//     return Container(
//       margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
//       padding: const EdgeInsets.all(12),
//       constraints: BoxConstraints(
//         maxWidth: MediaQuery.of(context).size.width * 0.85,
//       ),
//       decoration: BoxDecoration(
//         color: const Color(0xFFE8F5E9),
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(color: Colors.green.shade200),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Row(
//             children: [
//               Icon(Icons.assignment_turned_in, color: Colors.green.shade700, size: 18),
//               const SizedBox(width: 8),
//               Text(
//                 'Session Report',
//                 style: AppTextStyles.bodyMedium.copyWith(
//                   color: Colors.green.shade900,
//                   fontWeight: FontWeight.w600,
//                   fontSize: 14,
//                 ),
//               ),
//             ],
//           ),
//           const SizedBox(height: 8),
//           Text(
//             text,
//             style: AppTextStyles.bodySmall.copyWith(
//               color: Colors.green.shade900,
//               fontSize: 13,
//               height: 1.4,
//             ),
//           ),
//           if (timestamp != null) ...[
//             const SizedBox(height: 6),
//             Text(
//               _formatTime(timestamp.toDate()),
//               style: AppTextStyles.captionText.copyWith(
//                 color: Colors.green.shade700,
//                 fontSize: 11,
//               ),
//             ),
//           ],
//         ],
//       ),
//     );
//   }

//   Widget _buildTextMessage(String text, Timestamp? timestamp, bool isMe, bool isRead) {
//     return Container(
//       margin: const EdgeInsets.symmetric(vertical: 2, horizontal: 8),
//       padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
//       constraints: BoxConstraints(
//         maxWidth: MediaQuery.of(context).size.width * 0.75,
//       ),
//       decoration: BoxDecoration(
//         gradient: isMe
//             ? LinearGradient(
//                 colors: [
//                   AppColors.primary.withOpacity(0.9),
//                   AppColors.primaryLight.withOpacity(0.8),
//                 ],
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//               )
//             : null,
//         color: isMe ? null : AppColors.card,
//         borderRadius: BorderRadius.only(
//           topLeft: const Radius.circular(16),
//           topRight: const Radius.circular(16),
//           bottomLeft: Radius.circular(isMe ? 16 : 4),
//           bottomRight: Radius.circular(isMe ? 4 : 16),
//         ),
//         boxShadow: [
//           BoxShadow(
//             color: isMe 
//                 ? AppColors.primary.withOpacity(0.2)
//                 : Colors.black.withOpacity(0.05),
//             blurRadius: 4,
//             offset: const Offset(0, 2),
//           ),
//         ],
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Text(
//             text,
//             style: AppTextStyles.bodyMedium.copyWith(
//               color: isMe ? Colors.white : AppColors.text,
//               fontSize: 14,
//               height: 1.4,
//             ),
//           ),
//           const SizedBox(height: 4),
//           Row(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               Text(
//                 timestamp != null ? _formatTime(timestamp.toDate()) : '',
//                 style: AppTextStyles.captionText.copyWith(
//                   color: isMe 
//                       ? Colors.white.withOpacity(0.8)
//                       : AppColors.subtitle,
//                   fontSize: 11,
//                 ),
//               ),
//               if (isMe) ...[
//                 const SizedBox(width: 6),
//                 Text(
//                   isRead ? 'Seen' : 'Delivered',
//                   style: AppTextStyles.captionText.copyWith(
//                     color: Colors.white.withOpacity(0.7),
//                     fontSize: 10,
//                     fontWeight: FontWeight.w500,
//                   ),
//                 ),
//               ],
//             ],
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildInputArea() {
//     return Container(
//       padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
//       color: AppColors.card,
//       child: SafeArea(
//         child: Row(
//           children: [
//             IconButton(
//               icon: Icon(Icons.add, color: AppColors.primary),
//               onPressed: _showAttachmentOptions,
//             ),
//             Expanded(
//               child: Container(
//                 padding: const EdgeInsets.symmetric(horizontal: 12),
//                 decoration: BoxDecoration(
//                   color: Colors.white,
//                   borderRadius: BorderRadius.circular(24),
//                 ),
//                 child: TextField(
//                   controller: _messageController,
//                   style: AppTextStyles.bodyMedium.copyWith(fontSize: 15),
//                   maxLines: null,
//                   textInputAction: TextInputAction.newline,
//                   decoration: InputDecoration(
//                     hintText: 'Message',
//                     hintStyle: AppTextStyles.inputHint,
//                     border: InputBorder.none,
//                     contentPadding: const EdgeInsets.symmetric(vertical: 10),
//                   ),
//                 ),
//               ),
//             ),
//             const SizedBox(width: 4),
//             Container(
//               decoration: BoxDecoration(
//                 color: AppColors.primary,
//                 shape: BoxShape.circle,
//               ),
//               child: IconButton(
//                 icon: _isSending
//                     ? SizedBox(
//                         width: 20,
//                         height: 20,
//                         child: CircularProgressIndicator(
//                           color: Colors.white,
//                           strokeWidth: 2,
//                         ),
//                       )
//                     : const Icon(Icons.send, color: Colors.white, size: 20),
//                 onPressed: _isSending ? null : () => _sendMessage(),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   void _showAttachmentOptions() {
//     showModalBottomSheet(
//       context: context,
//       backgroundColor: AppColors.card,
//       shape: const RoundedRectangleBorder(
//         borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
//       ),
//       builder: (context) => SafeArea(
//         child: Padding(
//           padding: const EdgeInsets.symmetric(vertical: 20),
//           child: Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               Container(
//                 width: 40,
//                 height: 4,
//                 decoration: BoxDecoration(
//                   color: AppColors.border,
//                   borderRadius: BorderRadius.circular(2),
//                 ),
//               ),
//               const SizedBox(height: 20),
//               Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 20),
//                 child: Row(
//                   children: [
//                     Text(
//                       'Quick Actions',
//                       style: AppTextStyles.heading3.copyWith(
//                         color: AppColors.text,
//                         fontSize: 18,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//               const SizedBox(height: 20),
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                 children: [
//                   _buildQuickAction(
//                     Icons.assignment,
//                     'Send Report',
//                     Colors.green,
//                     () {
//                       Navigator.pop(context);
//                       _sendReport();
//                     },
//                   ),
//                   _buildQuickAction(
//                     Icons.videocam,
//                     'Zoom Link',
//                     Colors.blue,
//                     () {
//                       Navigator.pop(context);
//                       _sendZoomLink();
//                     },
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 20),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _buildQuickAction(
//     IconData icon,
//     String label,
//     Color color,
//     VoidCallback onTap,
//   ) {
//     return InkWell(
//       onTap: onTap,
//       borderRadius: BorderRadius.circular(12),
//       child: Column(
//         children: [
//           Container(
//             padding: const EdgeInsets.all(16),
//             decoration: BoxDecoration(
//               color: color.withOpacity(0.1),
//               shape: BoxShape.circle,
//             ),
//             child: Icon(icon, color: color, size: 32),
//           ),
//           const SizedBox(height: 8),
//           Text(
//             label,
//             style: AppTextStyles.bodySmall.copyWith(
//               color: AppColors.text,
//               fontWeight: FontWeight.w500,
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   void _showMessageOptions(String messageId, Map<String, dynamic> messageData) {
//     final isMe = messageData['senderId'] == widget.currentUserId;
    
//     showModalBottomSheet(
//       context: context,
//       backgroundColor: AppColors.card,
//       shape: const RoundedRectangleBorder(
//         borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
//       ),
//       builder: (context) => SafeArea(
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             const SizedBox(height: 12),
//             Container(
//               width: 40,
//               height: 4,
//               decoration: BoxDecoration(
//                 color: AppColors.border,
//                 borderRadius: BorderRadius.circular(2),
//               ),
//             ),
//             ListTile(
//               leading: Icon(Icons.delete, color: AppColors.error),
//               title: Text('Delete for me', style: AppTextStyles.bodyMedium),
//               onTap: () {
//                 Navigator.pop(context);
//                 _deleteMessageForMe(messageId);
//               },
//             ),
//             if (isMe)
//               ListTile(
//                 leading: Icon(Icons.delete_forever, color: AppColors.error),
//                 title: Text('Delete for everyone', style: AppTextStyles.bodyMedium),
//                 onTap: () {
//                   Navigator.pop(context);
//                   _deleteMessageForEveryone(messageId);
//                 },
//               ),
//             const SizedBox(height: 8),
//           ],
//         ),
//       ),
//     );
//   }

//   Future<void> _deleteMessageForMe(String messageId) async {
//     try {
//       await _firestore
//           .collection('chats')
//           .doc(chatId)
//           .collection('messages')
//           .doc(messageId)
//           .update({
//         'deletedFor': FieldValue.arrayUnion([widget.currentUserId]),
//       });
//       _showSnackBar('Message deleted');
//     } catch (e) {
//       _showSnackBar('Failed to delete message', isError: true);
//       debugPrint('Error deleting message: $e');
//     }
//   }

//   Future<void> _deleteMessageForEveryone(String messageId) async {
//     final confirm = await showDialog<bool>(
//       context: context,
//       builder: (context) => AlertDialog(
//         backgroundColor: AppColors.card,
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//         title: Text('Delete message?', style: AppTextStyles.heading4),
//         content: Text(
//           'This message will be deleted for everyone in the chat.',
//           style: AppTextStyles.bodyMedium,
//         ),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(context, false),
//             child: Text('Cancel', style: AppTextStyles.bodyMedium.copyWith(
//               color: AppColors.subtitle,
//             )),
//           ),
//           ElevatedButton(
//             onPressed: () => Navigator.pop(context, true),
//             style: ElevatedButton.styleFrom(
//               backgroundColor: AppColors.error,
//               shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
//             ),
//             child: const Text('Delete'),
//           ),
//         ],
//       ),
//     );

//     if (confirm == true) {
//       try {
//         await _firestore
//             .collection('chats')
//             .doc(chatId)
//             .collection('messages')
//             .doc(messageId)
//             .delete();
//         _showSnackBar('Message deleted for everyone');
//       } catch (e) {
//         _showSnackBar('Failed to delete message', isError: true);
//         debugPrint('Error deleting message: $e');
//       }
//     }
//   }

//   void _sendReport() {
//     showDialog(
//       context: context,
//       builder: (context) => ReportDialog(onSend: (report) {
//         _sendMessage(customText: report, messageType: 'report');
//       }),
//     );
//   }

//   void _sendZoomLink() {
//     showDialog(
//       context: context,
//       builder: (context) => ZoomLinkDialog(onSend: (zoomMessage) {
//         _sendMessage(customText: zoomMessage, messageType: 'zoom_link');
//       }),
//     );
//   }

//   void _viewStudentProfile() {
//     showModalBottomSheet(
//       context: context,
//       backgroundColor: AppColors.card,
//       shape: const RoundedRectangleBorder(
//         borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
//       ),
//       builder: (context) => SafeArea(
//         child: Padding(
//           padding: const EdgeInsets.all(24),
//           child: Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               Container(
//                 width: 40,
//                 height: 4,
//                 decoration: BoxDecoration(
//                   color: AppColors.border,
//                   borderRadius: BorderRadius.circular(2),
//                 ),
//               ),
//               const SizedBox(height: 24),
//               CircleAvatar(
//                 radius: 40,
//                 backgroundColor: AppColors.primary,
//                 child: Text(
//                   _getInitials(widget.otherUserName),
//                   style: AppTextStyles.heading2.copyWith(
//                     color: Colors.white,
//                     fontWeight: FontWeight.bold,
//                   ),
//                 ),
//               ),
//               const SizedBox(height: 16),
//               Text(
//                 widget.otherUserName,
//                 style: AppTextStyles.heading3.copyWith(
//                   color: AppColors.text,
//                   fontWeight: FontWeight.w600,
//                 ),
//               ),
//               const SizedBox(height: 8),
//               if (_studentData != null) ...[
//                 if (_studentData!['email'] != null)
//                   _buildInfoRow(Icons.email, _studentData!['email']),
//                 if (_studentData!['class'] != null)
//                   _buildInfoRow(Icons.school, 'Class: ${_studentData!['class']}'),
//               ],
//               const SizedBox(height: 24),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _buildInfoRow(IconData icon, String text) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 4),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Icon(icon, size: 16, color: AppColors.subtitle),
//           const SizedBox(width: 8),
//           Text(
//             text,
//             style: AppTextStyles.bodySmall.copyWith(
//               color: AppColors.subtitle,
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Future<void> _clearChat() async {
//     final confirm = await showDialog<bool>(
//       context: context,
//       builder: (context) => AlertDialog(
//         backgroundColor: AppColors.card,
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//         title: Text('Clear Chat?', style: AppTextStyles.heading4),
//         content: Text(
//           'Messages will only be removed from your view. The student will still see them.',
//           style: AppTextStyles.bodyMedium,
//         ),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(context, false),
//             child: Text('Cancel', style: AppTextStyles.bodyMedium.copyWith(
//               color: AppColors.subtitle,
//             )),
//           ),
//           ElevatedButton(
//             onPressed: () => Navigator.pop(context, true),
//             style: ElevatedButton.styleFrom(
//               backgroundColor: AppColors.warning,
//               shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
//             ),
//             child: const Text('Clear'),
//           ),
//         ],
//       ),
//     );

//     if (confirm == true) {
//       try {
//         final messages = await _firestore
//             .collection('chats')
//             .doc(chatId)
//             .collection('messages')
//             .get();

//         final batch = _firestore.batch();
//         for (var doc in messages.docs) {
//           batch.update(doc.reference, {
//             'deletedFor': FieldValue.arrayUnion([widget.currentUserId]),
//           });
//         }
//         await batch.commit();

//         _showSnackBar('Chat cleared successfully');
//       } catch (e) {
//         _showSnackBar('Failed to clear chat', isError: true);
//         debugPrint('Error clearing chat: $e');
//       }
//     }
//   }

//   String _getInitials(String name) {
//     final parts = name.split(' ');
//     if (parts.length >= 2) {
//       return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
//     }
//     return name.isNotEmpty ? name.substring(0, 1).toUpperCase() : 'S';
//   }

//   String _formatTime(DateTime timestamp) {
//     final now = DateTime.now();
//     final diff = now.difference(timestamp);

//     if (diff.inMinutes < 1) {
//       return 'now';
//     } else if (diff.inHours < 1) {
//       return '${diff.inMinutes}m';
//     } else if (diff.inDays < 1) {
//       return DateFormat('HH:mm').format(timestamp);
//     } else {
//       return DateFormat('HH:mm').format(timestamp);
//     }
//   }
// }

// // Report Dialog
// class ReportDialog extends StatefulWidget {
//   final Function(String) onSend;

//   const ReportDialog({super.key, required this.onSend});

//   @override
//   State<ReportDialog> createState() => _ReportDialogState();
// }

// class _ReportDialogState extends State<ReportDialog> {
//   final _unitController = TextEditingController();
//   final _homeworkController = TextEditingController();
//   final _sessionsLeftController = TextEditingController();

//   @override
//   void dispose() {
//     _unitController.dispose();
//     _homeworkController.dispose();
//     _sessionsLeftController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return AlertDialog(
//       backgroundColor: AppColors.card,
//       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//       title: Row(
//         children: [
//           Container(
//             padding: const EdgeInsets.all(10),
//             decoration: BoxDecoration(
//               color: Colors.green.withOpacity(0.1),
//               borderRadius: BorderRadius.circular(10),
//             ),
//             child: Icon(Icons.assignment, color: Colors.green, size: 24),
//           ),
//           const SizedBox(width: 12),
//           Text('Session Report', style: AppTextStyles.heading4),
//         ],
//       ),
//       content: SingleChildScrollView(
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             _buildTextField(
//               controller: _unitController,
//               label: 'Unit Completed',
//               hint: 'e.g., Unit 3',
//               icon: Icons.book,
//             ),
//             const SizedBox(height: 16),
//             _buildTextField(
//               controller: _homeworkController,
//               label: 'Homework',
//               hint: 'e.g., Pages 45-50',
//               icon: Icons.assignment_turned_in,
//             ),
//             const SizedBox(height: 16),
//             _buildTextField(
//               controller: _sessionsLeftController,
//               label: 'Sessions Left',
//               hint: 'e.g., 4',
//               icon: Icons.schedule,
//               keyboardType: TextInputType.number,
//             ),
//           ],
//         ),
//       ),
//       actions: [
//         TextButton(
//           onPressed: () => Navigator.pop(context),
//           child: Text('Cancel', style: AppTextStyles.bodyMedium.copyWith(
//             color: AppColors.subtitle,
//           )),
//         ),
//         ElevatedButton(
//           onPressed: () {
//             if (_unitController.text.isEmpty ||
//                 _homeworkController.text.isEmpty ||
//                 _sessionsLeftController.text.isEmpty) {
//               ScaffoldMessenger.of(context).showSnackBar(
//                 SnackBar(
//                   content: const Text('Please fill all fields'),
//                   backgroundColor: AppColors.error,
//                 ),
//               );
//               return;
//             }

//             final report = '''📋 Session Report:

// ✅ ${_unitController.text} - Complete
// ✅ Practice exercises done
// 📚 Homework: ${_homeworkController.text}
// ⏳ Sessions remaining: ${_sessionsLeftController.text}

// Keep up the excellent work!''';

//             widget.onSend(report);
//             Navigator.pop(context);
//           },
//           style: ElevatedButton.styleFrom(
//             backgroundColor: Colors.green,
//             shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
//           ),
//           child: const Text('Send Report'),
//         ),
//       ],
//     );
//   }

//   Widget _buildTextField({
//     required TextEditingController controller,
//     required String label,
//     required String hint,
//     required IconData icon,
//     TextInputType? keyboardType,
//   }) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Text(label, style: AppTextStyles.labelText.copyWith(
//           fontSize: 13,
//           fontWeight: FontWeight.w500,
//         )),
//         const SizedBox(height: 8),
//         TextField(
//           controller: controller,
//           keyboardType: keyboardType,
//           style: AppTextStyles.bodyMedium,
//           decoration: InputDecoration(
//             hintText: hint,
//             hintStyle: AppTextStyles.inputHint,
//             prefixIcon: Icon(icon, size: 20, color: AppColors.subtitle),
//             filled: true,
//             fillColor: AppColors.surface,
//             border: OutlineInputBorder(
//               borderRadius: BorderRadius.circular(8),
//               borderSide: BorderSide(color: AppColors.border),
//             ),
//             focusedBorder: OutlineInputBorder(
//               borderRadius: BorderRadius.circular(8),
//               borderSide: BorderSide(color: AppColors.primary, width: 2),
//             ),
//             contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
//           ),
//         ),
//       ],
//     );
//   }
// }

// // Zoom Link Dialog
// class ZoomLinkDialog extends StatefulWidget {
//   final Function(String) onSend;

//   const ZoomLinkDialog({super.key, required this.onSend});

//   @override
//   State<ZoomLinkDialog> createState() => _ZoomLinkDialogState();
// }

// class _ZoomLinkDialogState extends State<ZoomLinkDialog> {
//   final _linkController = TextEditingController();
//   final _meetingIdController = TextEditingController();
//   final _passwordController = TextEditingController();

//   @override
//   void dispose() {
//     _linkController.dispose();
//     _meetingIdController.dispose();
//     _passwordController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return AlertDialog(
//       backgroundColor: AppColors.card,
//       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//       title: Row(
//         children: [
//           Container(
//             padding: const EdgeInsets.all(10),
//             decoration: BoxDecoration(
//               color: Colors.blue.withOpacity(0.1),
//               borderRadius: BorderRadius.circular(10),
//             ),
//             child: Icon(Icons.videocam, color: Colors.blue, size: 24),
//           ),
//           const SizedBox(width: 12),
//           Text('Send Zoom Link', style: AppTextStyles.heading4),
//         ],
//       ),
//       content: SingleChildScrollView(
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             _buildTextField(
//               controller: _linkController,
//               label: 'Zoom Link',
//               hint: 'https://zoom.us/j/...',
//               icon: Icons.link,
//             ),
//             const SizedBox(height: 16),
//             _buildTextField(
//               controller: _meetingIdController,
//               label: 'Meeting ID',
//               hint: 'e.g., 123 456 789',
//               icon: Icons.confirmation_number,
//             ),
//             const SizedBox(height: 16),
//             _buildTextField(
//               controller: _passwordController,
//               label: 'Password (Optional)',
//               hint: 'Enter meeting password',
//               icon: Icons.lock,
//             ),
//           ],
//         ),
//       ),
//       actions: [
//         TextButton(
//           onPressed: () => Navigator.pop(context),
//           child: Text('Cancel', style: AppTextStyles.bodyMedium.copyWith(
//             color: AppColors.subtitle,
//           )),
//         ),
//         ElevatedButton(
//           onPressed: () {
//             if (_linkController.text.isEmpty || _meetingIdController.text.isEmpty) {
//               ScaffoldMessenger.of(context).showSnackBar(
//                 SnackBar(
//                   content: const Text('Please fill required fields'),
//                   backgroundColor: AppColors.error,
//                 ),
//               );
//               return;
//             }

//             String message = '''🔔 Your session is starting!

// 🔗 Zoom Link: ${_linkController.text}
// 🆔 Meeting ID: ${_meetingIdController.text}''';

//             if (_passwordController.text.isNotEmpty) {
//               message += '\n🔒 Password: ${_passwordController.text}';
//             }

//             message += '\n\nJoin the session now!';

//             widget.onSend(message);
//             Navigator.pop(context);
//           },
//           style: ElevatedButton.styleFrom(
//             backgroundColor: Colors.blue,
//             shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
//           ),
//           child: const Text('Send Link'),
//         ),
//       ],
//     );
//   }

//   Widget _buildTextField({
//     required TextEditingController controller,
//     required String label,
//     required String hint,
//     required IconData icon,
//   }) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Text(label, style: AppTextStyles.labelText.copyWith(
//           fontSize: 13,
//           fontWeight: FontWeight.w500,
//         )),
//         const SizedBox(height: 8),
//         TextField(
//           controller: controller,
//           style: AppTextStyles.bodyMedium,
//           decoration: InputDecoration(
//             hintText: hint,
//             hintStyle: AppTextStyles.inputHint,
//             prefixIcon: Icon(icon, size: 20, color: AppColors.subtitle),
//             filled: true,
//             fillColor: AppColors.surface,
//             border: OutlineInputBorder(
//               borderRadius: BorderRadius.circular(8),
//               borderSide: BorderSide(color: AppColors.border),
//             ),
//             focusedBorder: OutlineInputBorder(
//               borderRadius: BorderRadius.circular(8),
//               borderSide: BorderSide(color: AppColors.primary, width: 2),
//             ),
//             contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
//           ),
//         ),
//       ],
//     );
//   }
// }










































// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:intl/intl.dart';
// import 'package:studyalquran/utils/app_text_styles.dart';
// import 'package:studyalquran/utils/color_constants.dart';

// class TeacherChatDetailScreen extends StatefulWidget {
//   final String otherUserId;
//   final String otherUserName;
//   final String currentUserId;
//   final String currentUserRole;

//   const TeacherChatDetailScreen({
//     super.key,
//     required this.otherUserId,
//     required this.otherUserName,
//     required this.currentUserId,
//     required this.currentUserRole,
//   });

//   @override
//   State<TeacherChatDetailScreen> createState() => _TeacherChatDetailScreenState();
// }

// class _TeacherChatDetailScreenState extends State<TeacherChatDetailScreen> with WidgetsBindingObserver {
//   final TextEditingController _messageController = TextEditingController();
//   final TextEditingController _searchController = TextEditingController();
//   final ScrollController _scrollController = ScrollController();
//   final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
//   bool _isSending = false;
//   bool _isDisposed = false;
//   bool _isSearching = false;
//   String _searchQuery = '';
//   bool _isOnline = false;
//   DateTime? _lastSeen;
//   late String chatId;
//   Map<String, dynamic>? _studentData;

//   @override
//   void initState() {
//     super.initState();
//     WidgetsBinding.instance.addObserver(this);
//     chatId = _getChatId(widget.currentUserId, widget.otherUserId);
//     _initializeChat();
//     _markMessagesAsRead();
//     _loadStudentData();
//     _updateOnlineStatus(true);
//     _listenToStudentStatus();
//     _scrollToBottom();
//   }

//   @override
//   void didChangeAppLifecycleState(AppLifecycleState state) {
//     if (state == AppLifecycleState.resumed) {
//       _updateOnlineStatus(true);
//     } else if (state == AppLifecycleState.paused || state == AppLifecycleState.inactive) {
//       _updateOnlineStatus(false);
//     }
//   }

//   Future<void> _initializeChat() async {
//     try {
//       final teacherDoc = await _firestore.collection('teachers').doc(widget.currentUserId).get();
//       final studentDoc = await _firestore.collection('students').doc(widget.otherUserId).get();
      
//       await _firestore.collection('chats').doc(chatId).set({
//         'chatId': chatId,
//         'teacherId': widget.currentUserId,
//         'studentId': widget.otherUserId,
//         'teacherName': teacherDoc.data()?['name'] ?? 'Teacher',
//         'studentName': studentDoc.data()?['name'] ?? 'Student',
//         'participants': [widget.currentUserId, widget.otherUserId],
//         'createdAt': FieldValue.serverTimestamp(),
//         'isActive': true,
//         'unreadCount_teacher': 0,
//         'unreadCount_student': 0,
//       }, SetOptions(merge: true));
//     } catch (e) {
//       debugPrint('Chat init error: $e');
//     }
//   }

//   Future<void> _loadStudentData() async {
//     try {
//       final doc = await _firestore.collection('students').doc(widget.otherUserId).get();
//       if (doc.exists && mounted) {
//         setState(() => _studentData = doc.data());
//       }
//     } catch (e) {
//       debugPrint('Error loading student data: $e');
//     }
//   }

//   void _listenToStudentStatus() {
//     _firestore.collection('students').doc(widget.otherUserId).snapshots().listen((snapshot) {
//       if (snapshot.exists && mounted) {
//         final data = snapshot.data();
//         setState(() {
//           _isOnline = data?['isOnline'] ?? false;
//           final lastSeenTimestamp = data?['lastSeen'] as Timestamp?;
//           _lastSeen = lastSeenTimestamp?.toDate();
//         });
//       }
//     });
//   }

//   Future<void> _updateOnlineStatus(bool isOnline) async {
//     if (_isDisposed) return;
//     try {
//       await _firestore.collection('teachers').doc(widget.currentUserId).set({
//         'isOnline': isOnline,
//         'lastSeen': FieldValue.serverTimestamp(),
//       }, SetOptions(merge: true));
//     } catch (e) {
//       debugPrint('Error updating online status: $e');
//     }
//   }

//   @override
//   void dispose() {
//     _isDisposed = true;
//     WidgetsBinding.instance.removeObserver(this);
//     _updateOnlineStatus(false);
//     _updateTypingStatus(false);
//     _messageController.dispose();
//     _searchController.dispose();
//     _scrollController.dispose();
//     super.dispose();
//   }

//   String _getChatId(String userId1, String userId2) {
//     final ids = [userId1, userId2]..sort();
//     return '${ids[0]}_${ids[1]}';
//   }

//   Future<void> _markMessagesAsRead() async {
//     try {
//       final unreadMessages = await _firestore
//           .collection('chats')
//           .doc(chatId)
//           .collection('messages')
//           .where('senderId', isNotEqualTo: widget.currentUserId)
//           .where('read', isEqualTo: false)
//           .get();

//       if (unreadMessages.docs.isNotEmpty) {
//         final batch = _firestore.batch();
//         for (var doc in unreadMessages.docs) {
//           batch.update(doc.reference, {'read': true});
//         }
//         await batch.commit();
//       }

//       await _firestore.collection('chats').doc(chatId).set({
//         'unreadCount_teacher': 0,
//         'lastReadTime_teacher': FieldValue.serverTimestamp(),
//       }, SetOptions(merge: true));
//     } catch (e) {
//       debugPrint('Error marking messages as read: $e');
//     }
//   }

//   Future<void> _updateTypingStatus(bool isTyping) async {
//     if (_isDisposed) return;
//     try {
//       await _firestore.collection('chats').doc(chatId).set({
//         'teacher_typing': isTyping,
//         'teacher_typingAt': isTyping ? FieldValue.serverTimestamp() : null,
//       }, SetOptions(merge: true));
//     } catch (e) {
//       debugPrint('Error updating typing status: $e');
//     }
//   }

//   void _scrollToBottom() {
//     if (_isDisposed || !mounted) return;
    
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       if (_scrollController.hasClients && !_isDisposed && mounted) {
//         Future.delayed(const Duration(milliseconds: 100), () {
//           if (_scrollController.hasClients && mounted) {
//             _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
//           }
//         });
//       }
//     });
//   }

//   Future<void> _sendMessage({
//     String? customText,
//     String messageType = 'text',
//   }) async {
//     final text = customText ?? _messageController.text.trim();
//     if (text.isEmpty) return;

//     setState(() => _isSending = true);
//     await _updateTypingStatus(false);

//     try {
//       final messageId = DateTime.now().millisecondsSinceEpoch.toString();
      
//       // Clear input immediately for smooth UX
//       if (customText == null) {
//         _messageController.clear();
//       }
      
//       await _firestore
//           .collection('chats')
//           .doc(chatId)
//           .collection('messages')
//           .doc(messageId)
//           .set({
//         'messageId': messageId,
//         'text': text,
//         'senderId': widget.currentUserId,
//         'senderRole': widget.currentUserRole,
//         'messageType': messageType,
//         'timestamp': FieldValue.serverTimestamp(),
//         'read': false,
//         'deletedFor': [],
//       });

//       String displayMessage = messageType == 'report' ? '📋 Session Report'
//           : messageType == 'zoom_link' ? '🔔 Session Starting'
//           : messageType == 'reminder' ? '⏰ Reminder'
//           : (text.length > 50 ? '${text.substring(0, 50)}...' : text);

//       await _firestore.collection('chats').doc(chatId).set({
//         'lastMessage': displayMessage,
//         'lastMessageTime': FieldValue.serverTimestamp(),
//         'lastMessageSenderId': widget.currentUserId,
//         'lastMessageType': messageType,
//         'unreadCount_student': FieldValue.increment(1),
//         'updatedAt': FieldValue.serverTimestamp(),
//       }, SetOptions(merge: true));

//       _scrollToBottom();
//     } catch (e) {
//       _showSnackBar('Failed to send message', isError: true);
//       debugPrint('Error: $e');
//     } finally {
//       if (mounted) setState(() => _isSending = false);
//     }
//   }

//   void _showSnackBar(String message, {bool isError = false}) {
//     if (!mounted) return;
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         content: Text(message),
//         backgroundColor: isError ? AppColors.error : AppColors.success,
//         behavior: SnackBarBehavior.floating,
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
//         margin: const EdgeInsets.all(16),
//       ),
//     );
//   }

//   String _getOnlineStatus() {
//     if (_isOnline) return 'Online';
//     if (_lastSeen != null) {
//       final diff = DateTime.now().difference(_lastSeen!);
//       if (diff.inMinutes < 1) return 'Just now';
//       if (diff.inHours < 1) return '${diff.inMinutes}m ago';
//       if (diff.inDays < 1) return '${diff.inHours}h ago';
//       if (diff.inDays == 1) return 'Yesterday';
//       return DateFormat('dd/MM/yy').format(_lastSeen!);
//     }
//     return 'Offline';
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: AppColors.background,
//       appBar: _buildAppBar(),
//       body: Column(
//         children: [
//           if (_isSearching) _buildSearchBar(),
//           Expanded(child: _buildMessagesList()),
//           _buildInputArea(),
//         ],
//       ),
//     );
//   }

//   PreferredSizeWidget _buildAppBar() {
//     return AppBar(
//       backgroundColor: AppColors.primary,
//       elevation: 2,
//       leading: IconButton(
//         icon: const Icon(Icons.arrow_back, color: Colors.white),
//         onPressed: () {
//           _updateOnlineStatus(false);
//           Navigator.pop(context);
//         },
//       ),
//       title: InkWell(
//         onTap: _viewStudentProfile,
//         child: Row(
//           children: [
//             Stack(
//               children: [
//                 CircleAvatar(
//                   radius: 20,
//                   backgroundColor: Colors.white,
//                   child: Text(
//                     _getInitials(widget.otherUserName),
//                     style: AppTextStyles.bodyMedium.copyWith(
//                       color: AppColors.primary,
//                       fontWeight: FontWeight.bold,
//                       fontSize: 16,
//                     ),
//                   ),
//                 ),
//                 if (_isOnline)
//                   Positioned(
//                     right: 0,
//                     bottom: 0,
//                     child: Container(
//                       width: 12,
//                       height: 12,
//                       decoration: BoxDecoration(
//                         color: AppColors.success,
//                         shape: BoxShape.circle,
//                         border: Border.all(color: Colors.white, width: 2),
//                       ),
//                     ),
//                   ),
//               ],
//             ),
//             const SizedBox(width: 12),
//             Expanded(
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(
//                     widget.otherUserName,
//                     style: AppTextStyles.appBarTitle.copyWith(
//                       fontSize: 16,
//                       color: Colors.white,
//                       fontWeight: FontWeight.w600,
//                     ),
//                     maxLines: 1,
//                     overflow: TextOverflow.ellipsis,
//                   ),
//                   StreamBuilder<DocumentSnapshot>(
//                     stream: _firestore.collection('chats').doc(chatId).snapshots(),
//                     builder: (context, snapshot) {
//                       final isTyping = snapshot.data?.get('student_typing') ?? false;
//                       return Text(
//                         isTyping ? 'Typing...' : _getOnlineStatus(),
//                         style: AppTextStyles.captionText.copyWith(
//                           color: isTyping ? AppColors.accent : Colors.white.withOpacity(0.8),
//                           fontSize: 12,
//                           fontStyle: isTyping ? FontStyle.italic : FontStyle.normal,
//                         ),
//                       );
//                     },
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//       actions: [
//         IconButton(
//           icon: Icon(_isSearching ? Icons.close : Icons.search, color: Colors.white),
//           onPressed: () {
//             setState(() {
//               _isSearching = !_isSearching;
//               if (!_isSearching) {
//                 _searchQuery = '';
//                 _searchController.clear();
//               }
//             });
//           },
//         ),
//         PopupMenuButton(
//           icon: const Icon(Icons.more_vert, color: Colors.white),
//           color: AppColors.card,
//           shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//           itemBuilder: (context) => [
//             PopupMenuItem(
//               child: Row(
//                 children: [
//                   Icon(Icons.person, size: 20, color: AppColors.text),
//                   const SizedBox(width: 12),
//                   Text('View Profile', style: AppTextStyles.bodyMedium),
//                 ],
//               ),
//               onTap: () => Future.delayed(Duration.zero, _viewStudentProfile),
//             ),
//             PopupMenuItem(
//               child: Row(
//                 children: [
//                   Icon(Icons.assignment, size: 20, color: AppColors.success),
//                   const SizedBox(width: 12),
//                   Text('Send Report', style: AppTextStyles.bodyMedium),
//                 ],
//               ),
//               onTap: () => Future.delayed(Duration.zero, _sendReport),
//             ),
//             PopupMenuItem(
//               child: Row(
//                 children: [
//                   Icon(Icons.videocam, size: 20, color: AppColors.info),
//                   const SizedBox(width: 12),
//                   Text('Send Zoom Link', style: AppTextStyles.bodyMedium),
//                 ],
//               ),
//               onTap: () => Future.delayed(Duration.zero, _sendZoomLink),
//             ),
//             PopupMenuItem(
//               child: Row(
//                 children: [
//                   Icon(Icons.delete_sweep, size: 20, color: AppColors.warning),
//                   const SizedBox(width: 12),
//                   Text('Clear Chat', style: AppTextStyles.bodyMedium),
//                 ],
//               ),
//               onTap: () => Future.delayed(Duration.zero, _clearChat),
//             ),
//           ],
//         ),
//       ],
//     );
//   }

//   Widget _buildSearchBar() {
//     return Container(
//       color: AppColors.primary,
//       padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
//       child: Container(
//         decoration: BoxDecoration(
//           color: Colors.white,
//           borderRadius: BorderRadius.circular(8),
//         ),
//         child: TextField(
//           controller: _searchController,
//           style: AppTextStyles.bodyMedium,
//           decoration: InputDecoration(
//             hintText: 'Search messages...',
//             hintStyle: AppTextStyles.inputHint,
//             prefixIcon: Icon(Icons.search, color: AppColors.subtitle),
//             suffixIcon: _searchQuery.isNotEmpty
//                 ? IconButton(
//                     icon: Icon(Icons.clear, color: AppColors.subtitle),
//                     onPressed: () {
//                       _searchController.clear();
//                       setState(() => _searchQuery = '');
//                     },
//                   )
//                 : null,
//             border: InputBorder.none,
//             contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
//           ),
//           onChanged: (value) => setState(() => _searchQuery = value.toLowerCase()),
//         ),
//       ),
//     );
//   }

//   Widget _buildMessagesList() {
//     return Container(
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           colors: [AppColors.background, AppColors.surface],
//           begin: Alignment.topCenter,
//           end: Alignment.bottomCenter,
//         ),
//       ),
//       child: StreamBuilder<QuerySnapshot>(
//         stream: _firestore
//             .collection('chats')
//             .doc(chatId)
//             .collection('messages')
//             .orderBy('timestamp', descending: false)
//             .snapshots(),
//         builder: (context, snapshot) {
//           if (snapshot.connectionState == ConnectionState.waiting) {
//             return Center(
//               child: CircularProgressIndicator(
//                 valueColor: AlwaysStoppedAnimation(AppColors.primary),
//               ),
//             );
//           }

//           if (snapshot.hasError) {
//             return Center(
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Icon(Icons.error_outline, size: 48, color: AppColors.error),
//                   const SizedBox(height: 8),
//                   Text('Error loading messages',
//                       style: AppTextStyles.bodyMedium.copyWith(color: AppColors.error)),
//                 ],
//               ),
//             );
//           }

//           if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
//             return _buildEmptyChat();
//           }

//           var messages = snapshot.data!.docs;

//           // Filter deleted messages
//           messages = messages.where((doc) {
//             final data = doc.data() as Map<String, dynamic>;
//             final deletedFor = List<String>.from(data['deletedFor'] ?? []);
//             return !deletedFor.contains(widget.currentUserId);
//           }).toList();

//           // Filter by search
//           if (_searchQuery.isNotEmpty) {
//             messages = messages.where((doc) {
//               final data = doc.data() as Map<String, dynamic>;
//               final text = (data['text'] ?? '').toLowerCase();
//               return text.contains(_searchQuery);
//             }).toList();
//           }

//           if (messages.isEmpty && _searchQuery.isNotEmpty) {
//             return Center(
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Icon(Icons.search_off, size: 48, color: AppColors.subtitle),
//                   const SizedBox(height: 8),
//                   Text('No messages found',
//                       style: AppTextStyles.bodyMedium.copyWith(color: AppColors.subtitle)),
//                 ],
//               ),
//             );
//           }

//           return ListView.builder(
//             controller: _scrollController,
//             padding: const EdgeInsets.all(8),
//             itemCount: messages.length,
//             itemBuilder: (context, index) {
//               final messageDoc = messages[index];
//               final messageData = messageDoc.data() as Map<String, dynamic>;
//               final previousMessage = index > 0 
//                   ? messages[index - 1].data() as Map<String, dynamic>
//                   : null;
              
//               return _buildMessageBubble(messageData, messageDoc.id, previousMessage);
//             },
//           );
//         },
//       ),
//     );
//   }

//   Widget _buildEmptyChat() {
//     return Center(
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Icon(Icons.chat_bubble_outline, size: 80,
//               color: AppColors.subtitle.withOpacity(0.3)),
//           const SizedBox(height: 16),
//           Text('No messages yet',
//               style: AppTextStyles.heading3.copyWith(
//                 color: AppColors.text,
//                 fontWeight: FontWeight.w600,
//               )),
//           const SizedBox(height: 8),
//           Text('Start chatting with ${widget.otherUserName}',
//               style: AppTextStyles.bodySmall.copyWith(color: AppColors.subtitle),
//               textAlign: TextAlign.center),
//         ],
//       ),
//     );
//   }

//   Widget _buildMessageBubble(
//     Map<String, dynamic> messageData,
//     String messageId,
//     Map<String, dynamic>? previousMessage,
//   ) {
//     final text = messageData['text'] ?? '';
//     final senderId = messageData['senderId'] ?? '';
//     final messageType = messageData['messageType'] ?? 'text';
//     final timestamp = messageData['timestamp'] as Timestamp?;
//     final isRead = messageData['read'] ?? false;
    
//     final isMe = senderId == widget.currentUserId;
//     final showDateDivider = _shouldShowDateDivider(timestamp, previousMessage);

//     return Column(
//       children: [
//         if (showDateDivider && timestamp != null)
//           _buildDateDivider(timestamp.toDate()),
        
//         GestureDetector(
//           onLongPress: () => _showMessageOptions(messageId, messageData),
//           child: Padding(
//             padding: const EdgeInsets.symmetric(vertical: 2),
//             child: Row(
//               mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
//               children: [
//                 if (messageType == 'zoom_link')
//                   _buildSystemMessage(text, timestamp)
//                 else if (messageType == 'report')
//                   _buildReportMessage(text, timestamp)
//                 else
//                   _buildTextMessage(text, timestamp, isMe, isRead),
//               ],
//             ),
//           ),
//         ),
//       ],
//     );
//   }

//   bool _shouldShowDateDivider(
//     Timestamp? currentTimestamp,
//     Map<String, dynamic>? previousMessage,
//   ) {
//     if (currentTimestamp == null) return false;
//     if (previousMessage == null) return true;

//     final prevTimestamp = previousMessage['timestamp'] as Timestamp?;
//     if (prevTimestamp == null) return true;

//     final current = currentTimestamp.toDate();
//     final previous = prevTimestamp.toDate();

//     return current.day != previous.day ||
//            current.month != previous.month ||
//            current.year != previous.year;
//   }

//   Widget _buildDateDivider(DateTime date) {
//     String dateText;
//     final now = DateTime.now();
//     final diff = now.difference(date);

//     if (diff.inDays == 0) {
//       dateText = 'Today';
//     } else if (diff.inDays == 1) {
//       dateText = 'Yesterday';
//     } else if (diff.inDays < 7) {
//       dateText = DateFormat('EEEE').format(date);
//     } else {
//       dateText = DateFormat('dd MMM yyyy').format(date);
//     }

//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 12),
//       child: Center(
//         child: Container(
//           padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//           decoration: BoxDecoration(
//             color: AppColors.subtitle.withOpacity(0.15),
//             borderRadius: BorderRadius.circular(12),
//           ),
//           child: Text(
//             dateText,
//             style: AppTextStyles.captionText.copyWith(
//               fontSize: 11,
//               fontWeight: FontWeight.w500,
//               color: AppColors.subtitle,
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _buildSystemMessage(String text, Timestamp? timestamp) {
//     return Container(
//       margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
//       padding: const EdgeInsets.all(12),
//       constraints: BoxConstraints(
//         maxWidth: MediaQuery.of(context).size.width * 0.85,
//       ),
//       decoration: BoxDecoration(
//         color: AppColors.info.withOpacity(0.1),
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(color: AppColors.info.withOpacity(0.3)),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Row(
//             children: [
//               Icon(Icons.videocam, color: AppColors.info, size: 18),
//               const SizedBox(width: 8),
//               Text('Zoom Session',
//                   style: AppTextStyles.bodyMedium.copyWith(
//                     color: AppColors.info,
//                     fontWeight: FontWeight.w600,
//                     fontSize: 13,
//                   )),
//             ],
//           ),
//           const SizedBox(height: 8),
//           Text(text,
//               style: AppTextStyles.bodySmall.copyWith(
//                 color: AppColors.text,
//                 fontSize: 13,
//               )),
//           if (timestamp != null) ...[
//             const SizedBox(height: 6),
//             Text(_formatTime(timestamp.toDate()),
//                 style: AppTextStyles.captionText.copyWith(
//                   color: AppColors.subtitle,
//                   fontSize: 10,
//                 )),
//           ],
//         ],
//       ),
//     );
//   }

//   Widget _buildReportMessage(String text, Timestamp? timestamp) {
//     return Container(
//       margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
//       padding: const EdgeInsets.all(12),
//       constraints: BoxConstraints(
//         maxWidth: MediaQuery.of(context).size.width * 0.85,
//       ),
//       decoration: BoxDecoration(
//         color: AppColors.success.withOpacity(0.1),
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(color: AppColors.success.withOpacity(0.3)),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Row(
//             children: [
//               Icon(Icons.assignment_turned_in, color: AppColors.success, size: 18),
//               const SizedBox(width: 8),
//               Text('Session Report',
//                   style: AppTextStyles.bodyMedium.copyWith(
//                     color: AppColors.success,
//                     fontWeight: FontWeight.w600,
//                     fontSize: 13,
//                   )),
//             ],
//           ),
//           const SizedBox(height: 8),
//           Text(text,
//               style: AppTextStyles.bodySmall.copyWith(
//                 color: AppColors.text,
//                 fontSize: 13,
//                 height: 1.4,
//               )),
//           if (timestamp != null) ...[
//             const SizedBox(height: 6),
//             Text(_formatTime(timestamp.toDate()),
//                 style: AppTextStyles.captionText.copyWith(
//                   color: AppColors.subtitle,
//                   fontSize: 10,
//                 )),
//           ],
//         ],
//       ),
//     );
//   }

//   Widget _buildTextMessage(String text, Timestamp? timestamp, bool isMe, bool isRead) {
//     return Container(
//       margin: const EdgeInsets.symmetric(vertical: 2, horizontal: 8),
//       padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
//       constraints: BoxConstraints(
//         maxWidth: MediaQuery.of(context).size.width * 0.75,
//       ),
//       decoration: BoxDecoration(
//         color: isMe ? AppColors.primary : AppColors.card,
//         borderRadius: BorderRadius.only(
//           topLeft: const Radius.circular(16),
//           topRight: const Radius.circular(16),
//           bottomLeft: Radius.circular(isMe ? 16 : 4),
//           bottomRight: Radius.circular(isMe ? 4 : 16),
//         ),
//         boxShadow: [
//           BoxShadow(
//             color: Colors.black.withOpacity(0.05),
//             blurRadius: 4,
//             offset: const Offset(0, 2),
//           ),
//         ],
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Text(text,
//               style: AppTextStyles.bodyMedium.copyWith(
//                 color: isMe ? Colors.white : AppColors.text,
//                 fontSize: 14,
//                 height: 1.4,
//               )),
//           const SizedBox(height: 4),
//           Row(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               Text(
//                 timestamp != null ? _formatTime(timestamp.toDate()) : '',
//                 style: AppTextStyles.captionText.copyWith(
//                   color: isMe ? Colors.white.withOpacity(0.7) : AppColors.subtitle,
//                   fontSize: 10,
//                 ),
//               ),
//               if (isMe) ...[
//                 const SizedBox(width: 4),
//                 Icon(
//                   isRead ? Icons.done_all : Icons.done,
//                   size: 14,
//                   color: isRead 
//                       ? Colors.blue.shade300 
//                       : Colors.white.withOpacity(0.7),
//                 ),
//               ],
//             ],
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildInputArea() {
//     return Container(
//       padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
//       color: AppColors.card,
//       child: SafeArea(
//         child: Row(
//           children: [
//             Expanded(
//               child: Container(
//                 padding: const EdgeInsets.symmetric(horizontal: 12),
//                 decoration: BoxDecoration(
//                   color: AppColors.surface,
//                   borderRadius: BorderRadius.circular(24),
//                   border: Border.all(color: AppColors.border),
//                 ),
//                 child: TextField(
//                   controller: _messageController,
//                   style: AppTextStyles.bodyMedium.copyWith(fontSize: 14),
//                   maxLines: null,
//                   textInputAction: TextInputAction.newline,
//                   onChanged: (text) {
//                     _updateTypingStatus(text.isNotEmpty);
//                   },
//                   decoration: InputDecoration(
//                     hintText: 'Type a message...',
//                     hintStyle: AppTextStyles.inputHint,
//                     border: InputBorder.none,
//                     contentPadding: const EdgeInsets.symmetric(vertical: 10),
//                   ),
//                 ),
//               ),
//             ),
//             const SizedBox(width: 8),
//             Container(
//               decoration: BoxDecoration(
//                 color: AppColors.primary,
//                 shape: BoxShape.circle,
//               ),
//               child: IconButton(
//                 icon: _isSending
//                     ? SizedBox(
//                         width: 20,
//                         height: 20,
//                         child: CircularProgressIndicator(
//                           color: Colors.white,
//                           strokeWidth: 2,
//                         ),
//                       )
//                     : const Icon(Icons.send, color: Colors.white, size: 20),
//                 onPressed: _isSending ? null : () => _sendMessage(),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   void _showMessageOptions(String messageId, Map<String, dynamic> messageData) {
//     final isMe = messageData['senderId'] == widget.currentUserId;
    
//     showModalBottomSheet(
//       context: context,
//       backgroundColor: AppColors.card,
//       shape: const RoundedRectangleBorder(
//         borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
//       ),
//       builder: (context) => SafeArea(
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             const SizedBox(height: 12),
//             Container(
//               width: 40,
//               height: 4,
//               decoration: BoxDecoration(
//                 color: AppColors.border,
//                 borderRadius: BorderRadius.circular(2),
//               ),
//             ),
//             ListTile(
//               leading: Icon(Icons.delete_outline, color: AppColors.warning),
//               title: Text('Delete for me', style: AppTextStyles.bodyMedium),
//               onTap: () {
//                 Navigator.pop(context);
//                 _deleteMessageForMe(messageId);
//               },
//             ),
//             if (isMe)
//               ListTile(
//                 leading: Icon(Icons.delete_forever, color: AppColors.error),
//                 title: Text('Delete for everyone', style: AppTextStyles.bodyMedium),
//                 onTap: () {
//                   Navigator.pop(context);
//                   _deleteMessageForEveryone(messageId);
//                 },
//               ),
//             const SizedBox(height: 8),
//           ],
//         ),
//       ),
//     );
//   }

//   Future<void> _deleteMessageForMe(String messageId) async {
//     try {
//       await _firestore
//           .collection('chats')
//           .doc(chatId)
//           .collection('messages')
//           .doc(messageId)
//           .update({
//         'deletedFor': FieldValue.arrayUnion([widget.currentUserId]),
//       });
//       _showSnackBar('Message deleted');
//     } catch (e) {
//       _showSnackBar('Failed to delete', isError: true);
//       debugPrint('Error: $e');
//     }
//   }

//   Future<void> _deleteMessageForEveryone(String messageId) async {
//     final confirm = await showDialog<bool>(
//       context: context,
//       builder: (context) => AlertDialog(
//         backgroundColor: AppColors.card,
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//         title: Text('Delete message?', style: AppTextStyles.heading4),
//         content: Text(
//           'This message will be deleted for everyone.',
//           style: AppTextStyles.bodyMedium,
//         ),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(context, false),
//             child: Text('Cancel',
//                 style: AppTextStyles.bodyMedium.copyWith(color: AppColors.subtitle)),
//           ),
//           ElevatedButton(
//             onPressed: () => Navigator.pop(context, true),
//             style: ElevatedButton.styleFrom(
//               backgroundColor: AppColors.error,
//               shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
//             ),
//             child: const Text('Delete'),
//           ),
//         ],
//       ),
//     );

//     if (confirm == true) {
//       try {
//         await _firestore
//             .collection('chats')
//             .doc(chatId)
//             .collection('messages')
//             .doc(messageId)
//             .delete();
//         _showSnackBar('Message deleted for everyone');
//       } catch (e) {
//         _showSnackBar('Failed to delete', isError: true);
//       }
//     }
//   }

//   void _sendReport() {
//     showDialog(
//       context: context,
//       builder: (context) => ReportDialog(
//         onSend: (report) => _sendMessage(customText: report, messageType: 'report'),
//       ),
//     );
//   }

//   void _sendZoomLink() {
//     showDialog(
//       context: context,
//       builder: (context) => ZoomLinkDialog(
//         onSend: (zoom) => _sendMessage(customText: zoom, messageType: 'zoom_link'),
//       ),
//     );
//   }

//   void _viewStudentProfile() {
//     showModalBottomSheet(
//       context: context,
//       backgroundColor: AppColors.card,
//       shape: const RoundedRectangleBorder(
//         borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
//       ),
//       builder: (context) => SafeArea(
//         child: Padding(
//           padding: const EdgeInsets.all(24),
//           child: Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               Container(
//                 width: 40,
//                 height: 4,
//                 decoration: BoxDecoration(
//                   color: AppColors.border,
//                   borderRadius: BorderRadius.circular(2),
//                 ),
//               ),
//               const SizedBox(height: 24),
//               CircleAvatar(
//                 radius: 40,
//                 backgroundColor: AppColors.primary,
//                 child: Text(
//                   _getInitials(widget.otherUserName),
//                   style: AppTextStyles.heading2.copyWith(
//                     color: Colors.white,
//                     fontWeight: FontWeight.bold,
//                   ),
//                 ),
//               ),
//               const SizedBox(height: 16),
//               Text(widget.otherUserName,
//                   style: AppTextStyles.heading3.copyWith(
//                     color: AppColors.text,
//                     fontWeight: FontWeight.w600,
//                   )),
//               const SizedBox(height: 8),
//               Text(_getOnlineStatus(),
//                   style: AppTextStyles.bodySmall.copyWith(
//                     color: AppColors.subtitle,
//                   )),
//               if (_studentData != null) ...[
//                 const SizedBox(height: 16),
//                 if (_studentData!['email'] != null)
//                   _buildInfoRow(Icons.email, _studentData!['email']),
//                 if (_studentData!['class'] != null)
//                   _buildInfoRow(Icons.school, 'Class: ${_studentData!['class']}'),
//               ],
//               const SizedBox(height: 24),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _buildInfoRow(IconData icon, String text) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 4),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Icon(icon, size: 16, color: AppColors.subtitle),
//           const SizedBox(width: 8),
//           Text(text,
//               style: AppTextStyles.bodySmall.copyWith(
//                 color: AppColors.subtitle,
//               )),
//         ],
//       ),
//     );
//   }

//   Future<void> _clearChat() async {
//     final confirm = await showDialog<bool>(
//       context: context,
//       builder: (context) => AlertDialog(
//         backgroundColor: AppColors.card,
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//         title: Text('Clear Chat?', style: AppTextStyles.heading4),
//         content: Text(
//           'Messages will be removed from your view only.',
//           style: AppTextStyles.bodyMedium,
//         ),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(context, false),
//             child: Text('Cancel',
//                 style: AppTextStyles.bodyMedium.copyWith(color: AppColors.subtitle)),
//           ),
//           ElevatedButton(
//             onPressed: () => Navigator.pop(context, true),
//             style: ElevatedButton.styleFrom(
//               backgroundColor: AppColors.warning,
//               shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
//             ),
//             child: const Text('Clear'),
//           ),
//         ],
//       ),
//     );

//     if (confirm == true) {
//       try {
//         final messages = await _firestore
//             .collection('chats')
//             .doc(chatId)
//             .collection('messages')
//             .get();

//         final batch = _firestore.batch();
//         for (var doc in messages.docs) {
//           batch.update(doc.reference, {
//             'deletedFor': FieldValue.arrayUnion([widget.currentUserId]),
//           });
//         }
//         await batch.commit();
//         _showSnackBar('Chat cleared');
//       } catch (e) {
//         _showSnackBar('Failed to clear chat', isError: true);
//       }
//     }
//   }

//   String _getInitials(String name) {
//     final parts = name.split(' ');
//     if (parts.length >= 2) {
//       return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
//     }
//     return name.isNotEmpty ? name[0].toUpperCase() : 'S';
//   }

//   String _formatTime(DateTime timestamp) {
//     final now = DateTime.now();
//     final diff = now.difference(timestamp);

//     if (diff.inMinutes < 1) return 'now';
//     if (diff.inHours < 1) return '${diff.inMinutes}m';
//     if (diff.inDays < 1) return DateFormat('HH:mm').format(timestamp);
//     return DateFormat('HH:mm').format(timestamp);
//   }
// }

// // Report Dialog
// class ReportDialog extends StatefulWidget {
//   final Function(String) onSend;
//   const ReportDialog({super.key, required this.onSend});

//   @override
//   State<ReportDialog> createState() => _ReportDialogState();
// }

// class _ReportDialogState extends State<ReportDialog> {
//   final _unitController = TextEditingController();
//   final _homeworkController = TextEditingController();
//   final _sessionsLeftController = TextEditingController();
//   final _notesController = TextEditingController();

//   @override
//   void dispose() {
//     _unitController.dispose();
//     _homeworkController.dispose();
//     _sessionsLeftController.dispose();
//     _notesController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Dialog(
//       backgroundColor: AppColors.card,
//       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//       child: Container(
//         constraints: BoxConstraints(
//           maxWidth: 400,
//           maxHeight: MediaQuery.of(context).size.height * 0.7,
//         ),
//         child: SingleChildScrollView(
//           child: Padding(
//             padding: const EdgeInsets.all(20),
//             child: Column(
//               mainAxisSize: MainAxisSize.min,
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 // Title Row
//                 Row(
//                   children: [
//                     Container(
//                       padding: const EdgeInsets.all(8),
//                       decoration: BoxDecoration(
//                         color: AppColors.success.withOpacity(0.1),
//                         borderRadius: BorderRadius.circular(8),
//                       ),
//                       child: Icon(Icons.assignment, color: AppColors.success, size: 20),
//                     ),
//                     const SizedBox(width: 10),
//                     Text('Session Report', 
//                       style: AppTextStyles.heading4.copyWith(fontSize: 16)),
//                   ],
//                 ),
//                 const SizedBox(height: 16),
                
//                 // Fields with compact size
//                 _buildTextField(_unitController, 'Unit', 'e.g., Unit 3', Icons.book),
//                 const SizedBox(height: 12),
//                 _buildTextField(_homeworkController, 'Homework', 'e.g., Pages 45-50', Icons.assignment_turned_in),
//                 const SizedBox(height: 12),
//                 _buildTextField(_sessionsLeftController, 'Sessions', 'e.g., 4', Icons.schedule, TextInputType.number),
//                 const SizedBox(height: 12),
//                 _buildTextField(_notesController, 'Notes (Optional)', 'Remarks...', Icons.note, TextInputType.text, 2),
                
//                 const SizedBox(height: 20),
                
//                 // Action Buttons
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.end,
//                   children: [
//                     TextButton(
//                       onPressed: () => Navigator.pop(context),
//                       child: Text('Cancel', style: TextStyle(color: AppColors.subtitle)),
//                     ),
//                     const SizedBox(width: 8),
//                     ElevatedButton(
//                       onPressed: _handleSend,
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: AppColors.success,
//                         padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
//                         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
//                       ),
//                       child: const Text('Send', style: TextStyle(fontSize: 14)),
//                     ),
//                   ],
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _buildTextField(TextEditingController controller, String label, String hint, IconData icon, [TextInputType? keyboardType, int maxLines = 1]) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Text(label, style: AppTextStyles.labelText.copyWith(fontSize: 12, fontWeight: FontWeight.w500)),
//         const SizedBox(height: 6),
//         TextField(
//           controller: controller,
//           keyboardType: keyboardType,
//           maxLines: maxLines,
//           style: AppTextStyles.bodyMedium.copyWith(fontSize: 13),
//           decoration: InputDecoration(
//             hintText: hint,
//             hintStyle: AppTextStyles.inputHint.copyWith(fontSize: 12),
//             prefixIcon: Icon(icon, size: 18, color: AppColors.subtitle),
//             filled: true,
//             fillColor: AppColors.surface,
//             contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
//             border: OutlineInputBorder(
//               borderRadius: BorderRadius.circular(8),
//               borderSide: BorderSide(color: AppColors.border),
//             ),
//             focusedBorder: OutlineInputBorder(
//               borderRadius: BorderRadius.circular(8),
//               borderSide: BorderSide(color: AppColors.primary, width: 1.5),
//             ),
//           ),
//         ),
//       ],
//     );
//   }

//   void _handleSend() {
//     if (_unitController.text.isEmpty || _homeworkController.text.isEmpty || _sessionsLeftController.text.isEmpty) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: const Text('Fill required fields'), backgroundColor: AppColors.error),
//       );
//       return;
//     }

//     String report = '''📋 Session Report:

// ✅ ${_unitController.text} - Complete
// ✅ Practice exercises done
// 📚 Homework: ${_homeworkController.text}
// ⏳ Sessions remaining: ${_sessionsLeftController.text}''';

//     if (_notesController.text.trim().isNotEmpty) {
//       report += '\n\n📝 Notes: ${_notesController.text}';
//     }

//     report += '\n\nKeep up the excellent work!';
//     widget.onSend(report);
//     Navigator.pop(context);
//   }
// }

// // Zoom Link Dialog
// class ZoomLinkDialog extends StatefulWidget {
//   final Function(String) onSend;
//   const ZoomLinkDialog({super.key, required this.onSend});

//   @override
//   State<ZoomLinkDialog> createState() => _ZoomLinkDialogState();
// }

// class _ZoomLinkDialogState extends State<ZoomLinkDialog> {
//   final _linkController = TextEditingController();
//   final _meetingIdController = TextEditingController();
//   final _passwordController = TextEditingController();

//   @override
//   void dispose() {
//     _linkController.dispose();
//     _meetingIdController.dispose();
//     _passwordController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Dialog(
//       backgroundColor: AppColors.card,
//       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//       child: Container(
//         constraints: BoxConstraints(
//           maxWidth: 400,
//           maxHeight: MediaQuery.of(context).size.height * 0.6,
//         ),
//         child: SingleChildScrollView(
//           child: Padding(
//             padding: const EdgeInsets.all(20),
//             child: Column(
//               mainAxisSize: MainAxisSize.min,
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 // Title Row
//                 Row(
//                   children: [
//                     Container(
//                       padding: const EdgeInsets.all(8),
//                       decoration: BoxDecoration(
//                         color: AppColors.info.withOpacity(0.1),
//                         borderRadius: BorderRadius.circular(8),
//                       ),
//                       child: Icon(Icons.videocam, color: AppColors.info, size: 20),
//                     ),
//                     const SizedBox(width: 10),
//                     Text('Send Zoom Link', 
//                       style: AppTextStyles.heading4.copyWith(fontSize: 16)),
//                   ],
//                 ),
//                 const SizedBox(height: 16),
                
//                 // Fields with compact size
//                 _buildTextField(_linkController, 'Zoom Link', 'https://zoom.us/j/...', Icons.link),
//                 const SizedBox(height: 12),
//                 _buildTextField(_meetingIdController, 'Meeting ID', '123 456 789', Icons.confirmation_number),
//                 const SizedBox(height: 12),
//                 _buildTextField(_passwordController, 'Password (Optional)', 'Meeting password', Icons.lock),
                
//                 const SizedBox(height: 20),
                
//                 // Action Buttons
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.end,
//                   children: [
//                     TextButton(
//                       onPressed: () => Navigator.pop(context),
//                       child: Text('Cancel', style: TextStyle(color: AppColors.subtitle)),
//                     ),
//                     const SizedBox(width: 8),
//                     ElevatedButton(
//                       onPressed: _handleSend,
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: AppColors.info,
//                         padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
//                         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
//                       ),
//                       child: const Text('Send', style: TextStyle(fontSize: 14)),
//                     ),
//                   ],
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _buildTextField(TextEditingController controller, String label, String hint, IconData icon) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Text(label, style: AppTextStyles.labelText.copyWith(fontSize: 12, fontWeight: FontWeight.w500)),
//         const SizedBox(height: 6),
//         TextField(
//           controller: controller,
//           style: AppTextStyles.bodyMedium.copyWith(fontSize: 13),
//           decoration: InputDecoration(
//             hintText: hint,
//             hintStyle: AppTextStyles.inputHint.copyWith(fontSize: 12),
//             prefixIcon: Icon(icon, size: 18, color: AppColors.subtitle),
//             filled: true,
//             fillColor: AppColors.surface,
//             contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
//             border: OutlineInputBorder(
//               borderRadius: BorderRadius.circular(8),
//               borderSide: BorderSide(color: AppColors.border),
//             ),
//             focusedBorder: OutlineInputBorder(
//               borderRadius: BorderRadius.circular(8),
//               borderSide: BorderSide(color: AppColors.primary, width: 1.5),
//             ),
//           ),
//         ),
//       ],
//     );
//   }

//   void _handleSend() {
//     if (_linkController.text.isEmpty || _meetingIdController.text.isEmpty) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: const Text('Fill required fields'), backgroundColor: AppColors.error),
//       );
//       return;
//     }

//     String message = '''🔔 Your session is starting!

// 🔗 Zoom Link: ${_linkController.text}
// 🆔 Meeting ID: ${_meetingIdController.text}''';

//     if (_passwordController.text.isNotEmpty) {
//       message += '\n🔒 Password: ${_passwordController.text}';
//     }

//     message += '\n\nJoin the session now!';
//     widget.onSend(message);
//     Navigator.pop(context);
//   }
// }

























import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:studyalquran/services/fcm_service.dart';
import 'package:studyalquran/utils/app_text_styles.dart';
import 'package:studyalquran/utils/color_constants.dart';
import 'package:url_launcher/url_launcher.dart';

class TeacherChatScreen extends StatefulWidget {
  final String otherUserId;
  final String otherUserName;
  final String currentUserId;
  final String currentUserRole;

  const TeacherChatScreen({
    super.key,
    required this.otherUserId,
    required this.otherUserName,
    required this.currentUserId,
    required this.currentUserRole,
  });

  @override
  State<TeacherChatScreen> createState() => _TeacherChatScreenState();
}

class _TeacherChatScreenState extends State<TeacherChatScreen> with WidgetsBindingObserver {
  final TextEditingController _messageController = TextEditingController();
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
  bool _isSending = false;
  bool _isDisposed = false;
  bool _isSearching = false;
  String _searchQuery = '';
  bool _isOnline = false;
  DateTime? _lastSeen;
  late String chatId;
  Map<String, dynamic>? _studentData;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    chatId = _getChatId(widget.currentUserId, widget.otherUserId);
    _initializeChat();
    _markMessagesAsRead();
    _loadStudentData();
    _updateOnlineStatus(true);
    _listenToStudentStatus();
    _scrollToBottom();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _updateOnlineStatus(true);
    } else if (state == AppLifecycleState.paused || state == AppLifecycleState.inactive) {
      _updateOnlineStatus(false);
    }
  }

  // Future<void> _initializeChat() async {
  //   try {
  //     final teacherDoc = await _firestore.collection('teachers').doc(widget.currentUserId).get();
  //     final studentDoc = await _firestore.collection('students').doc(widget.otherUserId).get();
      
  //     await _firestore.collection('chats').doc(chatId).set({
  //       'chatId': chatId,
  //       'teacherId': widget.currentUserId,
  //       'studentId': widget.otherUserId,
  //       'teacherName': teacherDoc.data()?['name'] ?? 'Teacher',
  //       'studentName': studentDoc.data()?['name'] ?? 'Student',
  //       'participants': [widget.currentUserId, widget.otherUserId],
  //       'createdAt': FieldValue.serverTimestamp(),
  //       'isActive': true,
  //       'unreadCount_teacher': 0,
  //       'unreadCount_student': 0,
  //     }, SetOptions(merge: true));
  //   } catch (e) {
  //     debugPrint('Chat init error: $e');
  //   }
  // }

  // Future<void> _loadStudentData() async {
  //   try {
  //     final doc = await _firestore.collection('students').doc(widget.otherUserId).get();
  //     if (doc.exists && mounted) {
  //       setState(() => _studentData = doc.data());
  //     }
  //   } catch (e) {
  //     debugPrint('Error loading student data: $e');
  //   }
  // }

  // void _listenToStudentStatus() {
  //   _firestore.collection('students').doc(widget.otherUserId).snapshots().listen((snapshot) {
  //     if (snapshot.exists && mounted) {
  //       final data = snapshot.data();
  //       setState(() {
  //         _isOnline = data?['isOnline'] ?? false;
  //         final lastSeenTimestamp = data?['lastSeen'] as Timestamp?;
  //         _lastSeen = lastSeenTimestamp?.toDate();
  //       });
  //     }
  //   });
  // }

  // Future<void> _updateOnlineStatus(bool isOnline) async {
  //   if (_isDisposed) return;
  //   try {
  //     await _firestore.collection('teachers').doc(widget.currentUserId).set({
  //       'isOnline': isOnline,
  //       'lastSeen': FieldValue.serverTimestamp(),
  //     }, SetOptions(merge: true));
  //   } catch (e) {
  //     debugPrint('Error updating online status: $e');
  //   }
  // }

  @override
  void dispose() {
    _isDisposed = true;
    WidgetsBinding.instance.removeObserver(this);
    _updateOnlineStatus(false);
    _updateTypingStatus(false);
    _messageController.dispose();
    _searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  String _getChatId(String userId1, String userId2) {
    final ids = [userId1, userId2]..sort();
    return '${ids[0]}_${ids[1]}';
  }

  Future<void> _markMessagesAsRead() async {
    try {
      final unreadMessages = await _firestore
          .collection('chats')
          .doc(chatId)
          .collection('messages')
          .where('senderId', isNotEqualTo: widget.currentUserId)
          .where('read', isEqualTo: false)
          .get();

      if (unreadMessages.docs.isNotEmpty) {
        final batch = _firestore.batch();
        for (var doc in unreadMessages.docs) {
          batch.update(doc.reference, {'read': true});
        }
        await batch.commit();
      }

      await _firestore.collection('chats').doc(chatId).set({
        'unreadCount_teacher': 0,
        'lastReadTime_teacher': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    } catch (e) {
      debugPrint('Error marking messages as read: $e');
    }
  }

  Future<void> _updateTypingStatus(bool isTyping) async {
    if (_isDisposed) return;
    try {
      await _firestore.collection('chats').doc(chatId).set({
        'teacher_typing': isTyping,
        'teacher_typingAt': isTyping ? FieldValue.serverTimestamp() : null,
      }, SetOptions(merge: true));
    } catch (e) {
      debugPrint('Error updating typing status: $e');
    }
  }
void _scrollToBottom() {
  if (_isDisposed || !mounted) return;
  
  // YE CONDITION ADD KARO - sirf jab naye messages aaye tab scroll karo
  WidgetsBinding.instance.addPostFrameCallback((_) {
    if (_scrollController.hasClients && !_isDisposed) {
      final maxScroll = _scrollController.position.maxScrollExtent;
      final currentScroll = _scrollController.position.pixels;
      
      // Agar user bottom ke paas hai to hi scroll karo
      if (maxScroll - currentScroll < 100) {
        _scrollController.animateTo(
          maxScroll,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    }
  });
}


// Future<void> _sendMessage({
//   String? customText,
//   String messageType = 'text',
// }) async {
//   final text = customText ?? _messageController.text.trim();
//   if (text.isEmpty) return;

//   setState(() => _isSending = true);
//   await _updateTypingStatus(false);

//   try {
//     final messageId = DateTime.now().millisecondsSinceEpoch.toString();
//     final timestamp = FieldValue.serverTimestamp();
    
//     await _firestore
//         .collection('chats')
//         .doc(chatId)
//         .collection('messages')
//         .doc(messageId)
//         .set({
//       'messageId': messageId,
//       'text': text,
//       'senderId': widget.currentUserId,
//       'senderRole': widget.currentUserRole,
//       'messageType': messageType,
//       'timestamp': timestamp,
//       'read': false,
//       'chatId': chatId,
//       'deletedFor': [],
//     });

//     String lastMessagePreview;
//     if (messageType == 'report') {
//       lastMessagePreview = '📋 Session Report';
//     } else if (messageType == 'zoom_link') {
//       lastMessagePreview = '🔔 Session Starting';
//     } else if (messageType == 'reminder') {
//       lastMessagePreview = '⏰ Reminder';
//     } else {
//       lastMessagePreview = text.length > 50 
//           ? '${text.substring(0, 50)}...' 
//           : text;
//     }

//     final unreadField = widget.currentUserRole == 'teacher' 
//         ? 'unreadCount_student' 
//         : 'unreadCount_teacher';

//     await _firestore.collection('chats').doc(chatId).set({
//       'lastMessage': lastMessagePreview,
//       'lastMessageTime': timestamp,
//       'lastMessageSenderId': widget.currentUserId,
//       'lastMessageType': messageType,
//       unreadField: FieldValue.increment(1),
//       'updatedAt': timestamp,
//     }, SetOptions(merge: true));

//     _messageController.clear();
    
//     // YE LINE ADD KARO - manual scroll after send
//     Future.delayed(const Duration(milliseconds: 500), () {
//       if (mounted && _scrollController.hasClients) {
//         _scrollController.animateTo(
//           _scrollController.position.maxScrollExtent,
//           duration: const Duration(milliseconds: 300),
//           curve: Curves.easeOut,
//         );
//       }
//     });
//   } catch (e) {
//     _showSnackBar('Failed to send message', isError: true);
//     debugPrint('Send message error: $e');
//   } finally {
//     if (mounted) {
//       setState(() => _isSending = false);
//     }
//   }
// }

// Future<void> _sendMessage({
//   String? customText,
//   String messageType = 'text',
// }) async {
//   final text = customText ?? _messageController.text.trim();
//   if (text.isEmpty) return;

//   setState(() => _isSending = true);
//   await _updateTypingStatus(false);

//   try {
//     final messageId = DateTime.now().millisecondsSinceEpoch.toString();
//     final timestamp = FieldValue.serverTimestamp();
    
//     // ✅ STEP 1: Save message to Firestore (PEHLE YE HONA CHAHIYE)
//     await _firestore
//         .collection('chats')
//         .doc(chatId)
//         .collection('messages')
//         .doc(messageId)
//         .set({
//       'messageId': messageId,
//       'text': text,
//       'senderId': widget.currentUserId,
//       'senderRole': widget.currentUserRole,
//       'messageType': messageType,
//       'timestamp': timestamp,
//       'read': false,
//       'chatId': chatId,
//       'deletedFor': [],
//     });

//     // ✅ STEP 2: Update chat metadata
//     String lastMessagePreview;
//     if (messageType == 'report') {
//       lastMessagePreview = '📋 Session Report';
//     } else if (messageType == 'zoom_link') {
//       lastMessagePreview = '🔔 Session Starting';
//     } else if (messageType == 'reminder') {
//       lastMessagePreview = '⏰ Reminder';
//     } else {
//       lastMessagePreview = text.length > 50 
//           ? '${text.substring(0, 50)}...' 
//           : text;
//     }

//     final unreadField = widget.currentUserRole == 'teacher' 
//         ? 'unreadCount_student' 
//         : 'unreadCount_teacher';

//     await _firestore.collection('chats').doc(chatId).set({
//       'lastMessage': lastMessagePreview,
//       'lastMessageTime': timestamp,
//       'lastMessageSenderId': widget.currentUserId,
//       'lastMessageType': messageType,
//       unreadField: FieldValue.increment(1),
//       'updatedAt': timestamp,
//     }, SetOptions(merge: true));

//     // ✅ STEP 3: Send FCM notification
//     String notificationTitle;
//     String notificationBody;
//     String? zoomLink;

//     if (messageType == 'report') {
//       notificationTitle = '📋 New Report';
//       notificationBody = 'You received a session report';
//     } else if (messageType == 'zoom_link') {
//       notificationTitle = '🔔 Session Starting';
//       notificationBody = 'Your teacher sent a Zoom link';
//       final regex = RegExp(r'https://zoom\.us/j/[^\s]+');
//       final match = regex.firstMatch(text);
//       if (match != null) {
//         zoomLink = match.group(0);
//       }
//     } else if (messageType == 'reminder') {
//       notificationTitle = '⏰ Reminder';
//       notificationBody = text.length > 50 ? '${text.substring(0, 50)}...' : text;
//     } else {
//       notificationTitle = widget.otherUserName;
//       notificationBody = text.length > 50 ? '${text.substring(0, 50)}...' : text;
//     }

//     // Send notification
//     await FCMService().sendNotification(
//       recipientId: widget.otherUserId,
//       recipientRole: widget.currentUserRole == 'teacher' ? 'student' : 'teacher',
//       title: notificationTitle,
//       body: notificationBody,
//       senderId: widget.currentUserId,
//       senderName: widget.otherUserName,
//       currentUserId: widget.otherUserId,
//       currentUserRole: widget.currentUserRole == 'teacher' ? 'student' : 'teacher',
//       zoomLink: zoomLink,
//       type: messageType,
//     );

    

//     _messageController.clear();
    
//     // Scroll to bottom
//     Future.delayed(const Duration(milliseconds: 500), () {
//       if (mounted && _scrollController.hasClients) {
//         _scrollController.animateTo(
//           _scrollController.position.maxScrollExtent,
//           duration: const Duration(milliseconds: 300),
//           curve: Curves.easeOut,
//         );
//       }
//     });
//   } catch (e) {
//     _showSnackBar('Failed to send message', isError: true);
//     debugPrint('Send message error: $e');
//   } finally {
//     if (mounted) {
//       setState(() => _isSending = false);
//     }
//   }
// }
Future<void> _sendMessage({
  String? customText,
  String messageType = 'text',
}) async {
  final text = customText ?? _messageController.text.trim();
  if (text.isEmpty) return;

  setState(() => _isSending = true);
  await _updateTypingStatus(false);

  try {
    final messageId = DateTime.now().millisecondsSinceEpoch.toString();
    final timestamp = FieldValue.serverTimestamp();
    
    // ✅ STEP 1: Save message to Firestore
    await _firestore
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .doc(messageId)
        .set({
      'messageId': messageId,
      'text': text,
      'senderId': widget.currentUserId,
      'senderRole': widget.currentUserRole,
      'messageType': messageType,
      'timestamp': timestamp,
      'read': false,
      'chatId': chatId,
      'deletedFor': [],
    });

    // ✅ STEP 2: Update chat metadata
    String lastMessagePreview;
    if (messageType == 'report') {
      lastMessagePreview = '📋 Session Report';
    } else if (messageType == 'zoom_link') {
      lastMessagePreview = '🔔 Session Starting';
    } else if (messageType == 'reminder') {
      lastMessagePreview = '⏰ Reminder';
    } else {
      lastMessagePreview = text.length > 50 
          ? '${text.substring(0, 50)}...' 
          : text;
    }

    final unreadField = widget.currentUserRole == 'teacher' 
        ? 'unreadCount_student' 
        : 'unreadCount_teacher';

    await _firestore.collection('chats').doc(chatId).set({
      'lastMessage': lastMessagePreview,
      'lastMessageTime': timestamp,
      'lastMessageSenderId': widget.currentUserId,
      'lastMessageType': messageType,
      unreadField: FieldValue.increment(1),
      'updatedAt': timestamp,
    }, SetOptions(merge: true));

    // ✅ STEP 3: Send FCM notification (FIXED - recipientRole hataya)
    String notificationTitle;
    String notificationBody;
    String? zoomLink;

    if (messageType == 'report') {
      notificationTitle = '📋 New Report';
      notificationBody = 'You received a session report';
    } else if (messageType == 'zoom_link') {
      notificationTitle = '🔔 Session Starting';
      notificationBody = 'Your teacher sent a Zoom link';
      
      // Extract Zoom link from message
      final regex = RegExp(r'https://zoom\.us/j/[^\s]+');
      final match = regex.firstMatch(text);
      if (match != null) {
        zoomLink = match.group(0);
      }
    } else if (messageType == 'reminder') {
      notificationTitle = '⏰ Reminder';
      notificationBody = text.length > 50 ? '${text.substring(0, 50)}...' : text;
    } else {
      notificationTitle = widget.currentUserRole == 'teacher' 
          ? 'Teacher ${widget.currentUserId}' // Ideally teacher ka naam
          : 'Student ${widget.currentUserId}';
      notificationBody = text.length > 50 ? '${text.substring(0, 50)}...' : text;
    }

    // ✅ CORRECT WAY - sirf recipientId pass karo
    await FCMService().sendNotification(
      recipientId: widget.otherUserId,  // ✅ recipientRole parameter ab nahi chahiye
      title: notificationTitle,
      body: notificationBody,
      senderId: widget.currentUserId,
      senderName: widget.otherUserName,  // ✅ Ye actually current user ka naam hona chahiye
      currentUserId: widget.otherUserId,
      currentUserRole: widget.currentUserRole == 'teacher' ? 'student' : 'teacher',
      zoomLink: zoomLink,
      type: messageType,
    );

    _messageController.clear();
    
    // Scroll to bottom
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted && _scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  } catch (e) {
    _showSnackBar('Failed to send message', isError: true);
    debugPrint('Send message error: $e');
  } finally {
    if (mounted) {
      setState(() => _isSending = false);
    }
  }
}


// ✅ FIXED: Ab 'users' collection use karega
Future<void> _initializeChat() async {
  try {
    // ✅ 'teachers' ki jagah 'users' collection se data lo
    final teacherDoc = await _firestore.collection('users').doc(widget.currentUserId).get();
    final studentDoc = await _firestore.collection('users').doc(widget.otherUserId).get();
    
    await _firestore.collection('chats').doc(chatId).set({
      'chatId': chatId,
      'teacherId': widget.currentUserId,
      'studentId': widget.otherUserId,
      'teacherName': teacherDoc.data()?['name'] ?? 'Teacher',
      'studentName': studentDoc.data()?['name'] ?? 'Student',
      'participants': [widget.currentUserId, widget.otherUserId],
      'createdAt': FieldValue.serverTimestamp(),
      'isActive': true,
      'unreadCount_teacher': 0,
      'unreadCount_student': 0,
    }, SetOptions(merge: true));
  } catch (e) {
    debugPrint('Chat init error: $e');
  }
}

// ✅ FIXED: Ab 'users' collection use karega
Future<void> _loadStudentData() async {
  try {
    // ✅ 'students' ki jagah 'users' collection
    final doc = await _firestore.collection('users').doc(widget.otherUserId).get();
    if (doc.exists && mounted) {
      setState(() => _studentData = doc.data());
    }
  } catch (e) {
    debugPrint('Error loading student data: $e');
  }
}

// ✅ FIXED: Ab 'users' collection use karega
void _listenToStudentStatus() {
  // ✅ 'students' ki jagah 'users' collection
  _firestore.collection('users').doc(widget.otherUserId).snapshots().listen((snapshot) {
    if (snapshot.exists && mounted) {
      final data = snapshot.data();
      setState(() {
        _isOnline = data?['isOnline'] ?? false;
        final lastSeenTimestamp = data?['lastSeen'] as Timestamp?;
        _lastSeen = lastSeenTimestamp?.toDate();
      });
    }
  });
}

// ✅ FIXED: Ab 'users' collection use karega
Future<void> _updateOnlineStatus(bool isOnline) async {
  if (_isDisposed) return;
  try {
    // ✅ 'teachers' ki jagah 'users' collection
    await _firestore.collection('users').doc(widget.currentUserId).set({
      'isOnline': isOnline,
      'lastSeen': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  } catch (e) {
    debugPrint('Error updating online status: $e');
  }
}


  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? AppColors.error : AppColors.success,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  String _getOnlineStatus() {
    if (_isOnline) return 'Online';
    if (_lastSeen != null) {
      final diff = DateTime.now().difference(_lastSeen!);
      if (diff.inMinutes < 1) return 'Just now';
      if (diff.inHours < 1) return '${diff.inMinutes}m ago';
      if (diff.inDays < 1) return '${diff.inHours}h ago';
      if (diff.inDays == 1) return 'Yesterday';
      return DateFormat('dd/MM/yy').format(_lastSeen!);
    }
    return 'Offline';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          if (_isSearching) _buildSearchBar(),
          Expanded(child: _buildMessagesList()),
          _buildInputArea(),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: AppColors.primary,
      elevation: 2,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back, color: Colors.white),
        onPressed: () {
          _updateOnlineStatus(false);
          Navigator.pop(context);
        },
      ),
      title: InkWell(
        onTap: _viewStudentProfile,
        child: Row(
          children: [
            Stack(
              children: [
                CircleAvatar(
                  radius: 20,
                  backgroundColor: Colors.white,
                  child: Text(
                    _getInitials(widget.otherUserName),
                    style: AppTextStyles.bodyMedium.copyWith(
                      color: AppColors.primary,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
                if (_isOnline)
                  Positioned(
                    right: 0,
                    bottom: 0,
                    child: Container(
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                        color: AppColors.success,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 2),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.otherUserName,
                    style: AppTextStyles.appBarTitle.copyWith(
                      fontSize: 16,
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  StreamBuilder<DocumentSnapshot>(
                    stream: _firestore.collection('chats').doc(chatId).snapshots(),
                    builder: (context, snapshot) {
                      final isTyping = snapshot.data?.get('student_typing') ?? false;
                      return Text(
                        isTyping ? 'Typing...' : _getOnlineStatus(),
                        style: AppTextStyles.captionText.copyWith(
                          color: isTyping ? AppColors.accent : Colors.white.withOpacity(0.8),
                          fontSize: 12,
                          fontStyle: isTyping ? FontStyle.italic : FontStyle.normal,
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      actions: [
        IconButton(
          icon: Icon(_isSearching ? Icons.close : Icons.search, color: Colors.white),
          onPressed: () {
            setState(() {
              _isSearching = !_isSearching;
              if (!_isSearching) {
                _searchQuery = '';
                _searchController.clear();
              }
            });
          },
        ),
        PopupMenuButton(
          icon: const Icon(Icons.more_vert, color: Colors.white),
          color: AppColors.card,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          itemBuilder: (context) => [
            PopupMenuItem(
              child: Row(
                children: [
                  Icon(Icons.person, size: 20, color: AppColors.text),
                  const SizedBox(width: 12),
                  Text('View Profile', style: AppTextStyles.bodyMedium),
                ],
              ),
              onTap: () => Future.delayed(Duration.zero, _viewStudentProfile),
            ),
            PopupMenuItem(
              child: Row(
                children: [
                  Icon(Icons.assignment, size: 20, color: AppColors.success),
                  const SizedBox(width: 12),
                  Text('Send Report', style: AppTextStyles.bodyMedium),
                ],
              ),
              onTap: () => Future.delayed(Duration.zero, _sendReport),
            ),
            PopupMenuItem(
              child: Row(
                children: [
                  Icon(Icons.videocam, size: 20, color: AppColors.info),
                  const SizedBox(width: 12),
                  Text('Send Zoom Link', style: AppTextStyles.bodyMedium),
                ],
              ),
              onTap: () => Future.delayed(Duration.zero, _sendZoomLink),
            ),
            PopupMenuItem(
              child: Row(
                children: [
                  Icon(Icons.delete_sweep, size: 20, color: AppColors.warning),
                  const SizedBox(width: 12),
                  Text('Clear Chat', style: AppTextStyles.bodyMedium),
                ],
              ),
              onTap: () => Future.delayed(Duration.zero, _clearChat),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSearchBar() {
    return Container(
      color: AppColors.primary,
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8),
        ),
        child: TextField(
          controller: _searchController,
          style: AppTextStyles.bodyMedium,
          decoration: InputDecoration(
            hintText: 'Search messages...',
            hintStyle: AppTextStyles.inputHint,
            prefixIcon: Icon(Icons.search, color: AppColors.subtitle),
            suffixIcon: _searchQuery.isNotEmpty
                ? IconButton(
                    icon: Icon(Icons.clear, color: AppColors.subtitle),
                    onPressed: () {
                      _searchController.clear();
                      setState(() => _searchQuery = '');
                    },
                  )
                : null,
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          ),
          onChanged: (value) => setState(() => _searchQuery = value.toLowerCase()),
        ),
      ),
    );
  }

  Widget _buildMessagesList() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [AppColors.background, AppColors.surface],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: StreamBuilder<QuerySnapshot>(
        stream: _firestore
            .collection('chats')
            .doc(chatId)
            .collection('messages')
            .orderBy('timestamp', descending: false)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation(AppColors.primary),
              ),
            );
          }

          if (snapshot.hasError) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.error_outline, size: 48, color: AppColors.error),
                  const SizedBox(height: 8),
                  Text('Error loading messages',
                      style: AppTextStyles.bodyMedium.copyWith(color: AppColors.error)),
                ],
              ),
            );
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return _buildEmptyChat();
          }

          var messages = snapshot.data!.docs;

          // Filter deleted messages
          messages = messages.where((doc) {
            final data = doc.data() as Map<String, dynamic>;
            final deletedFor = List<String>.from(data['deletedFor'] ?? []);
            return !deletedFor.contains(widget.currentUserId);
          }).toList();

          // Filter by search
          if (_searchQuery.isNotEmpty) {
            messages = messages.where((doc) {
              final data = doc.data() as Map<String, dynamic>;
              final text = (data['text'] ?? '').toLowerCase();
              return text.contains(_searchQuery);
            }).toList();
          }

          if (messages.isEmpty && _searchQuery.isNotEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.search_off, size: 48, color: AppColors.subtitle),
                  const SizedBox(height: 8),
                  Text('No messages found',
                      style: AppTextStyles.bodyMedium.copyWith(color: AppColors.subtitle)),
                ],
              ),
            );
          }

          // WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());

          return ListView.builder(
            controller: _scrollController,
            padding: const EdgeInsets.all(8),
            itemCount: messages.length,
            itemBuilder: (context, index) {
              final messageDoc = messages[index];
              final messageData = messageDoc.data() as Map<String, dynamic>;
              final previousMessage = index > 0 
                  ? messages[index - 1].data() as Map<String, dynamic>
                  : null;
              
              return _buildMessageBubble(messageData, messageDoc.id, previousMessage);
            },
          );
        },
      ),
    );
  }

  Widget _buildEmptyChat() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.chat_bubble_outline, size: 80,
              color: AppColors.subtitle.withOpacity(0.3)),
          const SizedBox(height: 16),
          Text('No messages yet',
              style: AppTextStyles.heading3.copyWith(
                color: AppColors.text,
                fontWeight: FontWeight.w600,
              )),
          const SizedBox(height: 8),
          Text('Start chatting with ${widget.otherUserName}',
              style: AppTextStyles.bodySmall.copyWith(color: AppColors.subtitle),
              textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(
    Map<String, dynamic> messageData,
    String messageId,
    Map<String, dynamic>? previousMessage,
  ) {
    final text = messageData['text'] ?? '';
    final senderId = messageData['senderId'] ?? '';
    final messageType = messageData['messageType'] ?? 'text';
    final timestamp = messageData['timestamp'] as Timestamp?;
    final isRead = messageData['read'] ?? false;
    
    final isMe = senderId == widget.currentUserId;
    final showDateDivider = _shouldShowDateDivider(timestamp, previousMessage);

    return Column(
      children: [
        if (showDateDivider && timestamp != null)
          _buildDateDivider(timestamp.toDate()),
        
        GestureDetector(
          onLongPress: () => _showMessageOptions(messageId, messageData),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 2),
            child: Row(
              mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
              children: [
                if (messageType == 'zoom_link')
                  _buildSystemMessage(text, timestamp)
                else if (messageType == 'report')
                  _buildReportMessage(text, timestamp)
                else
                  _buildTextMessage(text, timestamp, isMe, isRead, messageId),
              ],
            ),
          ),
        ),
      ],
    );
  }

  bool _shouldShowDateDivider(
    Timestamp? currentTimestamp,
    Map<String, dynamic>? previousMessage,
  ) {
    if (currentTimestamp == null) return false;
    if (previousMessage == null) return true;

    final prevTimestamp = previousMessage['timestamp'] as Timestamp?;
    if (prevTimestamp == null) return true;

    final current = currentTimestamp.toDate();
    final previous = prevTimestamp.toDate();

    return current.day != previous.day ||
           current.month != previous.month ||
           current.year != previous.year;
  }

  Widget _buildDateDivider(DateTime date) {
    String dateText;
    final now = DateTime.now();
    final diff = now.difference(date);

    if (diff.inDays == 0) {
      dateText = 'Today';
    } else if (diff.inDays == 1) {
      dateText = 'Yesterday';
    } else if (diff.inDays < 7) {
      dateText = DateFormat('EEEE').format(date);
    } else {
      dateText = DateFormat('dd MMM yyyy').format(date);
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: AppColors.subtitle.withOpacity(0.15),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(
            dateText,
            style: AppTextStyles.captionText.copyWith(
              fontSize: 11,
              fontWeight: FontWeight.w500,
              color: AppColors.subtitle,
            ),
          ),
        ),
      ),
    );
  }

  // Widget _buildSystemMessage(String text, Timestamp? timestamp) {
  //   return Container(
  //     margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
  //     padding: const EdgeInsets.all(12),
  //     constraints: BoxConstraints(
  //       maxWidth: MediaQuery.of(context).size.width * 0.85,
  //     ),
  //     decoration: BoxDecoration(
  //       color: AppColors.info.withOpacity(0.1),
  //       borderRadius: BorderRadius.circular(12),
  //       border: Border.all(color: AppColors.info.withOpacity(0.3)),
  //     ),
  //     child: Column(
  //       crossAxisAlignment: CrossAxisAlignment.start,
  //       children: [
  //         Row(
  //           children: [
  //             Icon(Icons.videocam, color: AppColors.info, size: 18),
  //             const SizedBox(width: 8),
  //             Text('Zoom Session',
  //                 style: AppTextStyles.bodyMedium.copyWith(
  //                   color: AppColors.info,
  //                   fontWeight: FontWeight.w600,
  //                   fontSize: 13,
  //                 )),
  //           ],
  //         ),
  //         const SizedBox(height: 8),
  //         Text(text,
  //             style: AppTextStyles.bodySmall.copyWith(
  //               color: AppColors.text,
  //               fontSize: 13,
  //             )),
  //         if (timestamp != null) ...[
  //           const SizedBox(height: 6),
  //           Text(_formatTime(timestamp.toDate()),
  //               style: AppTextStyles.captionText.copyWith(
  //                 color: AppColors.subtitle,
  //                 fontSize: 10,
  //               )),
  //         ],
  //       ],
  //     ),
  //   );
  // }


Widget _buildSystemMessage(String text, Timestamp? timestamp) {
    // Extract Zoom link
    final zoomLinkRegex = RegExp(r'https://zoom\.us/j/[^\s]+');
    final match = zoomLinkRegex.firstMatch(text);
    final zoomLink = match?.group(0);

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
      padding: const EdgeInsets.all(12),
      constraints: BoxConstraints(
        maxWidth: MediaQuery.of(context).size.width * 0.85,
      ),
      decoration: BoxDecoration(
        color: AppColors.info.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.info.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.videocam, color: AppColors.info, size: 18),
              const SizedBox(width: 8),
              Text('Zoom Session',
                  style: AppTextStyles.bodyMedium.copyWith(
                    color: AppColors.info,
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                  )),
            ],
          ),
          const SizedBox(height: 8),
          Text(text,
              style: AppTextStyles.bodySmall.copyWith(
                color: AppColors.text,
                fontSize: 13,
              )),
          if (zoomLink != null) ...[
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: () => _launchZoomUrl(zoomLink),
              icon: const Icon(Icons.videocam, size: 18),
              label: const Text('Join Meeting'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.info,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              ),
            ),
          ],
          if (timestamp != null) ...[
            const SizedBox(height: 6),
            Text(_formatTime(timestamp.toDate()),
                style: AppTextStyles.captionText.copyWith(
                  color: AppColors.subtitle,
                  fontSize: 10,
                )),
          ],
        ],
      ),
    );
  }

  Future<void> _launchZoomUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      _showSnackBar('Could not open Zoom link', isError: true);
    }
  }
  Widget _buildReportMessage(String text, Timestamp? timestamp) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
      padding: const EdgeInsets.all(12),
      constraints: BoxConstraints(
        maxWidth: MediaQuery.of(context).size.width * 0.85,
      ),
      decoration: BoxDecoration(
        color: AppColors.success.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.success.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.assignment_turned_in, color: AppColors.success, size: 18),
              const SizedBox(width: 8),
              Text('Session Report',
                  style: AppTextStyles.bodyMedium.copyWith(
                    color: AppColors.success,
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                  )),
            ],
          ),
          const SizedBox(height: 8),
          Text(text,
              style: AppTextStyles.bodySmall.copyWith(
                color: AppColors.text,
                fontSize: 13,
                height: 1.4,
              )),
          if (timestamp != null) ...[
            const SizedBox(height: 6),
            Text(_formatTime(timestamp.toDate()),
                style: AppTextStyles.captionText.copyWith(
                  color: AppColors.subtitle,
                  fontSize: 10,
                )),
          ],
        ],
      ),
    );
  }
Widget _buildTextMessage(String text, Timestamp? timestamp, bool isMe, bool isRead, String messageId) {
  return Container(
    margin: const EdgeInsets.symmetric(vertical: 2, horizontal: 8),
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
    constraints: BoxConstraints(
      maxWidth: MediaQuery.of(context).size.width * 0.75,
    ),
    decoration: BoxDecoration(
      color: isMe ? AppColors.primary : AppColors.card,
      borderRadius: BorderRadius.only(
        topLeft: const Radius.circular(16),
        topRight: const Radius.circular(16),
        bottomLeft: Radius.circular(isMe ? 16 : 4),
        bottomRight: Radius.circular(isMe ? 4 : 16),
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.05),
          blurRadius: 4,
          offset: const Offset(0, 2),
        ),
      ],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(text,
            style: AppTextStyles.bodyMedium.copyWith(
              color: isMe ? Colors.white : AppColors.text,
              fontSize: 14,
              height: 1.4,
            )),
        const SizedBox(height: 4),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              timestamp != null ? _formatTime(timestamp.toDate()) : '',
              style: AppTextStyles.captionText.copyWith(
                color: isMe ? Colors.white.withOpacity(0.7) : AppColors.subtitle,
                fontSize: 10,
              ),
            ),
            if (isMe) ...[
              const SizedBox(width: 4),
              // YE LINE CHANGE KARO - Single/Double tick ki jagah text
              Text(
                isRead ? 'Seen' : 'Delivered',
                style: AppTextStyles.captionText.copyWith(
                  color: isMe ? Colors.white.withOpacity(0.9) : AppColors.subtitle,
                  fontSize: 10,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ],
        ),
      ],
    ),
  );
}
  Widget _buildInputArea() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      color: AppColors.card,
      child: SafeArea(
        child: Row(
          children: [
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: AppColors.border),
                ),
                child: TextField(
                  controller: _messageController,
                  style: AppTextStyles.bodyMedium.copyWith(fontSize: 14),
                  maxLines: null,
                  textInputAction: TextInputAction.newline,
                  onChanged: (text) {
                    _updateTypingStatus(text.isNotEmpty);
                  },
                  decoration: InputDecoration(
                    hintText: 'Type a message...',
                    hintStyle: AppTextStyles.inputHint,
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 10),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Container(
              decoration: BoxDecoration(
                color: AppColors.primary,
                shape: BoxShape.circle,
              ),
              child: IconButton(
                icon: _isSending
                    ? SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2,
                        ),
                      )
                    : const Icon(Icons.send, color: Colors.white, size: 20),
                onPressed: _isSending ? null : () => _sendMessage(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showMessageOptions(String messageId, Map<String, dynamic> messageData) {
    final isMe = messageData['senderId'] == widget.currentUserId;
    
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 12),
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: AppColors.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            ListTile(
              leading: Icon(Icons.delete_outline, color: AppColors.warning),
              title: Text('Delete for me', style: AppTextStyles.bodyMedium),
              onTap: () {
                Navigator.pop(context);
                _deleteMessageForMe(messageId);
              },
            ),
            if (isMe)
              ListTile(
                leading: Icon(Icons.delete_forever, color: AppColors.error),
                title: Text('Delete for everyone', style: AppTextStyles.bodyMedium),
                onTap: () {
                  Navigator.pop(context);
                  _deleteMessageForEveryone(messageId);
                },
              ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Future<void> _deleteMessageForMe(String messageId) async {
    try {
      await _firestore
          .collection('chats')
          .doc(chatId)
          .collection('messages')
          .doc(messageId)
          .update({
        'deletedFor': FieldValue.arrayUnion([widget.currentUserId]),
      });
      _showSnackBar('Message deleted');
    } catch (e) {
      _showSnackBar('Failed to delete', isError: true);
      debugPrint('Error: $e');
    }
  }

  Future<void> _deleteMessageForEveryone(String messageId) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppColors.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Delete message?', style: AppTextStyles.heading4),
        content: Text(
          'This message will be deleted for everyone.',
          style: AppTextStyles.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('Cancel',
                style: AppTextStyles.bodyMedium.copyWith(color: AppColors.subtitle)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.error,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      try {
        await _firestore
            .collection('chats')
            .doc(chatId)
            .collection('messages')
            .doc(messageId)
            .delete();
        _showSnackBar('Message deleted for everyone');
      } catch (e) {
        _showSnackBar('Failed to delete', isError: true);
      }
    }
  }

  void _sendReport() {
    showDialog(
      context: context,
      builder: (context) => ReportDialog(
        onSend: (report) => _sendMessage(customText: report, messageType: 'report'),
      ),
    );
  }

  void _sendZoomLink() {
    showDialog(
      context: context,
      builder: (context) => ZoomLinkDialog(
        onSend: (zoom) => _sendMessage(customText: zoom, messageType: 'zoom_link'),
      ),
    );
  }

  void _viewStudentProfile() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppColors.border,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 24),
              CircleAvatar(
                radius: 40,
                backgroundColor: AppColors.primary,
                child: Text(
                  _getInitials(widget.otherUserName),
                  style: AppTextStyles.heading2.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(widget.otherUserName,
                  style: AppTextStyles.heading3.copyWith(
                    color: AppColors.text,
                    fontWeight: FontWeight.w600,
                  )),
              const SizedBox(height: 8),
              Text(_getOnlineStatus(),
                  style: AppTextStyles.bodySmall.copyWith(
                    color: AppColors.subtitle,
                  )),
              if (_studentData != null) ...[
                const SizedBox(height: 16),
                if (_studentData!['email'] != null)
                  _buildInfoRow(Icons.email, _studentData!['email']),
                if (_studentData!['class'] != null)
                  _buildInfoRow(Icons.school, 'Class: ${_studentData!['class']}'),
              ],
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 16, color: AppColors.subtitle),
          const SizedBox(width: 8),
          Text(text,
              style: AppTextStyles.bodySmall.copyWith(
                color: AppColors.subtitle,
              )),
        ],
      ),
    );
  }

  Future<void> _clearChat() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppColors.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Clear Chat?', style: AppTextStyles.heading4),
        content: Text(
          'Messages will be removed from your view only.',
          style: AppTextStyles.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('Cancel',
                style: AppTextStyles.bodyMedium.copyWith(color: AppColors.subtitle)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.warning,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: const Text('Clear'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      try {
        final messages = await _firestore
            .collection('chats')
            .doc(chatId)
            .collection('messages')
            .get();

        final batch = _firestore.batch();
        for (var doc in messages.docs) {
          batch.update(doc.reference, {
            'deletedFor': FieldValue.arrayUnion([widget.currentUserId]),
          });
        }
        await batch.commit();
        _showSnackBar('Chat cleared');
      } catch (e) {
        _showSnackBar('Failed to clear chat', isError: true);
      }
    }
  }

  String _getInitials(String name) {
    final parts = name.split(' ');
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    }
    return name.isNotEmpty ? name[0].toUpperCase() : 'S';
  }

  String _formatTime(DateTime timestamp) {
    final now = DateTime.now();
    final diff = now.difference(timestamp);

    if (diff.inMinutes < 1) return 'now';
    if (diff.inHours < 1) return '${diff.inMinutes}m';
    if (diff.inDays < 1) return DateFormat('HH:mm').format(timestamp);
    return DateFormat('HH:mm').format(timestamp);
  }
}

// Report Dialog
class ReportDialog extends StatefulWidget {
  final Function(String) onSend;
  const ReportDialog({super.key, required this.onSend});

  @override
  State<ReportDialog> createState() => _ReportDialogState();
}

class _ReportDialogState extends State<ReportDialog> {
  final _unitController = TextEditingController();
  final _homeworkController = TextEditingController();
  final _sessionsLeftController = TextEditingController();
  final _notesController = TextEditingController();

  @override
  void dispose() {
    _unitController.dispose();
    _homeworkController.dispose();
    _sessionsLeftController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: AppColors.card,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.success.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(Icons.assignment, color: AppColors.success, size: 24),
          ),
          const SizedBox(width: 12),
          Text('Session Report', style: AppTextStyles.heading4),
        ],
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildTextField(_unitController, 'Unit Completed', 'e.g., Unit 3', Icons.book),
            const SizedBox(height: 16),
            _buildTextField(_homeworkController, 'Homework', 'e.g., Pages 45-50', Icons.assignment_turned_in),
            const SizedBox(height: 16),
            _buildTextField(_sessionsLeftController, 'Sessions Left', 'e.g., 4', Icons.schedule, TextInputType.number),
            const SizedBox(height: 16),
            _buildTextField(_notesController, 'Notes (Optional)', 'Additional notes...', Icons.note, TextInputType.text, 3),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text('Cancel', style: AppTextStyles.bodyMedium.copyWith(color: AppColors.subtitle)),
        ),
        ElevatedButton(
          onPressed: () {
            if (_unitController.text.isEmpty || _homeworkController.text.isEmpty || _sessionsLeftController.text.isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: const Text('Fill all required fields'), backgroundColor: AppColors.error),
              );
              return;
            }

            String report = '''📋 Session Report:

✅ ${_unitController.text} - Complete
✅ Practice exercises done
📚 Homework: ${_homeworkController.text}
⏳ Sessions remaining: ${_sessionsLeftController.text}''';

            if (_notesController.text.trim().isNotEmpty) {
              report += '\n\n📝 Notes: ${_notesController.text}';
            }

            report += '\n\nKeep up the excellent work!';
            widget.onSend(report);
            Navigator.pop(context);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.success,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
          child: const Text('Send Report'),
        ),
      ],
    );
  }

  Widget _buildTextField(TextEditingController controller, String label, String hint, IconData icon, [TextInputType? keyboardType, int maxLines = 1]) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: AppTextStyles.labelText.copyWith(fontSize: 13, fontWeight: FontWeight.w500)),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          keyboardType: keyboardType,
          maxLines: maxLines,
          style: AppTextStyles.bodyMedium,
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: AppTextStyles.inputHint,
            prefixIcon: Icon(icon, size: 20, color: AppColors.subtitle),
            filled: true,
            fillColor: AppColors.surface,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: BorderSide(color: AppColors.border),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: BorderSide(color: AppColors.primary, width: 2),
            ),
          ),
        ),
      ],
    );
  }
}

// Zoom Link Dialog
class ZoomLinkDialog extends StatefulWidget {
  final Function(String) onSend;
  const ZoomLinkDialog({super.key, required this.onSend});

  @override
  State<ZoomLinkDialog> createState() => _ZoomLinkDialogState();
}

class _ZoomLinkDialogState extends State<ZoomLinkDialog> {
  final _linkController = TextEditingController();
  final _meetingIdController = TextEditingController();
  final _passwordController = TextEditingController();

  @override
  void dispose() {
    _linkController.dispose();
    _meetingIdController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: AppColors.card,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.info.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(Icons.videocam, color: AppColors.info, size: 24),
          ),
          const SizedBox(width: 12),
          Text('Send Zoom Link', style: AppTextStyles.heading4),
        ],
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildTextField(_linkController, 'Zoom Link', 'https://zoom.us/j/...', Icons.link),
            const SizedBox(height: 16),
            _buildTextField(_meetingIdController, 'Meeting ID', '123 456 789', Icons.confirmation_number),
            const SizedBox(height: 16),
            _buildTextField(_passwordController, 'Password (Optional)', 'Meeting password', Icons.lock),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text('Cancel', style: AppTextStyles.bodyMedium.copyWith(color: AppColors.subtitle)),
        ),
        ElevatedButton(
          onPressed: () {
            if (_linkController.text.isEmpty || _meetingIdController.text.isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: const Text('Fill required fields'), backgroundColor: AppColors.error),
              );
              return;
            }

            String message = '''🔔 Your session is starting!

🔗 Zoom Link: ${_linkController.text}
🆔 Meeting ID: ${_meetingIdController.text}''';

            if (_passwordController.text.isNotEmpty) {
              message += '\n🔒 Password: ${_passwordController.text}';
            }

            message += '\n\nJoin the session now!';
            widget.onSend(message);
            Navigator.pop(context);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.info,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
          child: const Text('Send Link'),
        ),
      ],
    );
  }

  Widget _buildTextField(TextEditingController controller, String label, String hint, IconData icon) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: AppTextStyles.labelText.copyWith(fontSize: 13, fontWeight: FontWeight.w500)),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          style: AppTextStyles.bodyMedium,
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: AppTextStyles.inputHint,
            prefixIcon: Icon(icon, size: 20, color: AppColors.subtitle),
            filled: true,
            fillColor: AppColors.surface,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: BorderSide(color: AppColors.border),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: BorderSide(color: AppColors.primary, width: 2),
            ),
          ),
        ),
      ],
    );
  }
}
























