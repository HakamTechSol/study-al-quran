import 'package:flutter/material.dart';
import 'package:studyalquran/mobile/views/student/notifications.dart';
import 'package:studyalquran/utils/app_text_styles.dart';
import 'package:studyalquran/utils/color_constants.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

// Import your chat screen
import 'package:studyalquran/mobile/views/chat/studentChatscreen.dart';

// 📅 Session Model - UPDATED FOR TRIAL WITH APPROVAL STATUS
class Session {
  final String id;
  final String name;
  final String teacherImage;
  final DateTime? dateTime;
  final String duration;
  final String zoomLink;
  final SessionStatus status;
  final String subject;
  final String teacherId;
  final String studentId;
  final String? packageName;
  final bool isTrial;
  final String sessionType;
  final String? trialAssignmentId; // 🔥 NEW: For trial assignments
  final String trialStatus; // 🔥 NEW: pending, completed, approved, rejected

  Session({
    required this.id,
    required this.name,
    required this.teacherImage,
    this.dateTime,
    required this.duration,
    required this.zoomLink,
    required this.status,
    required this.subject,
    required this.teacherId,
    required this.studentId,
    this.packageName,
    this.isTrial = false,
    this.sessionType = 'regular',
    this.trialAssignmentId, // 🔥 NEW
    this.trialStatus = 'pending', // 🔥 NEW
  });

  factory Session.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;

    // Date string ko DateTime mein convert karo - ONLY FOR REGULAR CLASSES
    DateTime? dateTime;
    if (!(data['isTrial'] ?? false)) {
      try {
        if (data['date'] != null && data['time'] != null) {
          String dateStr = data['date'];
          String timeStr = data['time'];
          if (timeStr.toUpperCase().contains('AM') ||
              timeStr.toUpperCase().contains('PM')) {
            dateTime = DateFormat(
              'yyyy-MM-dd h:mm a',
            ).parse('$dateStr $timeStr');
          } else {
            dateTime = DateFormat(
              'yyyy-MM-dd HH:mm',
            ).parse('$dateStr $timeStr');
          }
        }
      } catch (e) {
        print('Date parsing error: $e');
      }
    }

    // Status determine karo
    SessionStatus status = _determineStatus(dateTime, data['status']);
    return Session(
      id: doc.id,
      name: data['name'] ?? 'Unknown Teacher',
      teacherImage: _getTeacherInitial(data['name'] ?? 'T'),
      dateTime: dateTime,
      duration: data['duration'] ?? '60 min',
      zoomLink: data['zoomLink'] ?? '',
      status: status,
      subject: data['subject'] ?? 'Quran',
      teacherId: data['teacherId'] ?? '',
      studentId: data['studentId'] ?? '',
      packageName: data['packageName'],
      isTrial: data['isTrial'] ?? false,
      sessionType: data['isTrial'] == true ? 'trial' : 'regular',
      trialStatus: data['trialStatus'] ?? 'pending',
      trialAssignmentId: doc.id, // 🔥 ADD THIS LINE
    );
  }
  static SessionStatus _determineStatus(DateTime? dateTime, String? status) {
    if (status == 'completed') return SessionStatus.completed;
    if (status == 'cancelled') return SessionStatus.missed;

    // 🔥 FOR TRIAL CLASSES: Always show as "Schedule Pending"
    if (dateTime == null) return SessionStatus.upcoming;

    DateTime now = DateTime.now();
    if (dateTime.isBefore(now)) return SessionStatus.missed;
    if (dateTime.isAfter(now)) return SessionStatus.upcoming;

    return SessionStatus.upcoming;
  }

  static String _getTeacherInitial(String name) {
    if (name.isEmpty) return 'T';
    return name[0].toUpperCase();
  }
}

// 🎯 Session Status Enum
enum SessionStatus { upcoming, ongoing, completed, missed }

class StudentScheduleScreen extends StatefulWidget {
  const StudentScheduleScreen({super.key});

  @override
  State<StudentScheduleScreen> createState() => _StudentScheduleScreenState();
}

class _StudentScheduleScreenState extends State<StudentScheduleScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // 🔥 UPDATED: Trial classes with approval status
  Stream<List<Session>> getCombinedSessionsStream() {
    String? studentId = _auth.currentUser?.uid;

    if (studentId == null) {
      return Stream.value([]);
    }

    return _firestore
        .collection('schedules')
        .where('studentId', isEqualTo: studentId)
        .orderBy('date')
        .orderBy('time')
        .snapshots()
        .asyncMap((snapshot) async {
          List<Session> allSessions = [];

          // 🔥 1. REGULAR SCHEDULES (With time)
          for (var doc in snapshot.docs) {
            Map<String, dynamic> data = doc.data();

            // Skip if it's a trial class in schedules
            if (data['isTrial'] == true) continue;

            // Get teacher name from teachers collection
            String teacherName = 'Unknown Teacher';
            String teacherZoomLink = '';

            if (data['teacherId'] != null && data['teacherId'].isNotEmpty) {
              try {
                var teacherDoc = await _firestore
                    .collection('teachers')
                    .doc(data['teacherId'])
                    .get();
                if (teacherDoc.exists) {
                  teacherName = teacherDoc.data()?['name'] ?? 'Unknown Teacher';
                  teacherZoomLink = teacherDoc.data()?['zoomLink'] ?? '';
                }
              } catch (e) {
                print('Error fetching teacher: $e');
              }
            }

            // Get package name if packageId exists
            String? packageName = data['packageName'];
            if (data['packageId'] != null &&
                data['packageId'].isNotEmpty &&
                packageName == null) {
              try {
                var packageDoc = await _firestore
                    .collection('packageAssignments')
                    .doc(data['packageId'])
                    .get();
                if (packageDoc.exists) {
                  packageName = packageDoc.data()?['packageName'];
                }
              } catch (e) {
                print('Error fetching package: $e');
              }
            }

            // Date string ko DateTime mein convert karo
            DateTime? dateTime;
            try {
              if (data['date'] != null && data['time'] != null) {
                String dateStr = data['date'];
                String timeStr = data['time'];

                if (timeStr.toUpperCase().contains('AM') ||
                    timeStr.toUpperCase().contains('PM')) {
                  dateTime = DateFormat(
                    'yyyy-MM-dd h:mm a',
                  ).parse('$dateStr $timeStr');
                } else {
                  dateTime = DateFormat(
                    'yyyy-MM-dd HH:mm',
                  ).parse('$dateStr $timeStr');
                }
              }
            } catch (e) {
              print('Date parsing error: $e');
            }

            // Status determine karo
            SessionStatus status = _determineStatus(dateTime, data['status']);

            // Zoom link
            String finalZoomLink = teacherZoomLink.isNotEmpty
                ? teacherZoomLink
                : (data['zoomLink'] ?? 'https://zoom.us/j/meeting');

            allSessions.add(
              Session(
                id: doc.id,
                name: teacherName,
                teacherImage: _getTeacherInitial(teacherName),
                dateTime: dateTime,
                duration: data['duration'] ?? '60 min',
                zoomLink: finalZoomLink,
                status: status,
                subject: data['subject'] ?? 'Quran',
                teacherId: data['teacherId'] ?? '',
                studentId: data['studentId'] ?? '',
                packageName: packageName,
                isTrial: false,
                sessionType: 'regular',
              ),
            );
          }

          // 🔥 2. TRIAL ASSIGNMENTS (Without time - With approval status)
          try {
            var trialSnapshot = await _firestore
                .collection('trialAssignments')
                .where('studentId', isEqualTo: studentId)
                .where(
                  'status',
                  whereIn: [
                    'pending',
                    'scheduled',
                    'completed',
                    'approved',
                    'rejected',
                  ],
                )
                .get();

            for (var trialDoc in trialSnapshot.docs) {
              Map<String, dynamic> trialData = trialDoc.data();

              // Get teacher details
              String teacherName = 'Unknown Teacher';
              String teacherZoomLink = '';
              String teacherId = trialData['teacherId'] ?? '';

              if (teacherId.isNotEmpty) {
                try {
                  var teacherDoc = await _firestore
                      .collection('teachers')
                      .doc(teacherId)
                      .get();
                  if (teacherDoc.exists) {
                    teacherName =
                        teacherDoc.data()?['name'] ?? 'Unknown Teacher';
                    teacherZoomLink = teacherDoc.data()?['zoomLink'] ?? '';
                  }
                } catch (e) {
                  print('Error fetching teacher for trial: $e');
                }
              }

              // 🔥 TRIAL CLASSES: No specific date/time
              allSessions.add(
                Session(
                  id: 'trial_${trialDoc.id}',
                  name: teacherName,
                  teacherImage: _getTeacherInitial(teacherName),
                  dateTime: null,
                  duration: 'To be scheduled',
                  zoomLink: teacherZoomLink.isNotEmpty
                      ? teacherZoomLink
                      : 'https://zoom.us/j/meeting',
                  status: SessionStatus.upcoming,
                  subject:
                      'Trial Class - ${trialData['packageName'] ?? 'Quran'}',
                  teacherId: teacherId,
                  studentId: trialData['studentId'] ?? '',
                  packageName: trialData['packageName'] ?? 'Trial Package',
                  isTrial: true,
                  sessionType: 'trial',
                  trialAssignmentId: trialDoc.id, // 🔥 CORRECT ID
                  trialStatus: trialData['status'] ?? 'pending',
                ),
              );
            }
          } catch (e) {
            print('Error fetching trial assignments: $e');
          }

          // Sort: Regular classes with time first, then trial classes
          allSessions.sort((a, b) {
            if (a.dateTime != null && b.dateTime != null) {
              return a.dateTime!.compareTo(b.dateTime!);
            } else if (a.dateTime != null) {
              return -1;
            } else if (b.dateTime != null) {
              return 1;
            } else {
              return a.name.compareTo(b.name);
            }
          });

          return allSessions;
        });
  }

  Future<void> _updateTrialApproval(Session session, String newStatus) async {
    try {
      String studentId = _auth.currentUser?.uid ?? '';

      if (studentId.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('User not logged in'),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }

      // Show loading indicator
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => Center(child: CircularProgressIndicator()),
      );

      // 🔥 GET STUDENT DATA FIRST
      DocumentSnapshot studentDoc = await _firestore
          .collection('students')
          .doc(studentId)
          .get();

      Map<String, dynamic> studentData =
          studentDoc.data() as Map<String, dynamic>;
      String studentName = studentData['name'] ?? 'Unknown Student';

      // 1️⃣ Update trialAssignments collection
      if (session.trialAssignmentId != null) {
        await _firestore
            .collection('trialAssignments')
            .doc(session.trialAssignmentId)
            .update({
              'status': newStatus,
              'studentApproval': newStatus,
              'approvedAt': FieldValue.serverTimestamp(),
              'updatedAt': FieldValue.serverTimestamp(),
            });

        print('✅ trialAssignments updated: ${session.trialAssignmentId}');
      }

      // 2️⃣ Update students collection
      await _firestore.collection('students').doc(studentId).update({
        'trialStatus': newStatus,
        'studentApprovalStatus': newStatus,
        'updatedAt': FieldValue.serverTimestamp(),
      });

      print('✅ students collection updated: $studentId');

      // 3️⃣ 🔥 CREATE ENTRY IN packageChangeRequests FOR ADMIN
      String feedbackMessage = newStatus == 'approved'
          ? 'Student was satisfied with the trial class. Ready to proceed with regular classes.'
          : 'Student was not satisfied with the teaching style. Requesting new teacher assignment.';

      await _firestore.collection('packageChangeRequests').add({
        'type': 'teacher_approval',
        'studentId': studentId,
        'studentName': studentName,
        'teacherName': session.name,
        'teacherId': session.teacherId,
        'packageName': session.packageName ?? 'Trial Package',
        'status': newStatus, // 'approved' or 'rejected'
        'message': feedbackMessage,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
        'trialAssignmentId': session.trialAssignmentId,
      });

      print('✅ packageChangeRequests created for admin');

      // Close loading dialog
      if (mounted) Navigator.pop(context);

      // Show success message
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                Icon(
                  newStatus == 'approved'
                      ? Icons.check_circle
                      : Icons.info_outline,
                  color: Colors.white,
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Text(
                    newStatus == 'approved'
                        ? '🎉 Teacher approved successfully! Admin will contact you soon.'
                        : '✅ Feedback submitted. Admin will assign another teacher.',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
            backgroundColor: newStatus == 'approved'
                ? Colors.green
                : Colors.orange,
            behavior: SnackBarBehavior.floating,
            duration: Duration(seconds: 4),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        );
      }

      // Refresh the screen
      setState(() {});
    } catch (e) {
      print('❌ Error updating trial approval: $e');

      // Close loading dialog if open
      if (mounted && Navigator.canPop(context)) {
        Navigator.pop(context);
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                Icon(Icons.error_outline, color: Colors.white),
                SizedBox(width: 12),
                Expanded(child: Text('Error: ${e.toString()}')),
              ],
            ),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
            duration: Duration(seconds: 5),
          ),
        );
      }
    }
  }

  // 🔥 SHOW APPROVAL DIALOG
  void _showApprovalDialog(Session session) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(Icons.thumb_up, color: Colors.green),
            SizedBox(width: 8),
            Text('Approve Teacher'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'How was your trial class with ${session.name}?',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 12),
            Text(
              'Your feedback will help us improve the teaching experience.',
              style: TextStyle(color: Colors.grey, fontSize: 14),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
          // REJECT BUTTON
          OutlinedButton(
            onPressed: () {
              Navigator.pop(context);
              _showRejectConfirmation(session);
            },
            style: OutlinedButton.styleFrom(
              side: BorderSide(color: Colors.red),
            ),
            child: Text('Not Satisfied', style: TextStyle(color: Colors.red)),
          ),
          // APPROVE BUTTON
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showApproveConfirmation(session);
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            child: Text(
              'Approve Teacher',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  void _showApproveConfirmation(Session session) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(Icons.check_circle, color: Colors.green),
            SizedBox(width: 8),
            Text('Confirm Approval'),
          ],
        ),
        content: Text(
          'Are you sure you want to approve ${session.name} as your teacher?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _updateTrialApproval(session, 'approved');
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            child: Text('Yes, Approve'),
          ),
        ],
      ),
    );
  }

  void _showRejectConfirmation(Session session) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(Icons.cancel, color: Colors.red),
            SizedBox(width: 8),
            Text('Provide Feedback'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Please share why you are not satisfied:'),
            SizedBox(height: 12),
            TextFormField(
              maxLines: 3,
              decoration: InputDecoration(
                hintText:
                    'e.g., Teaching style, communication, timing issues...',
                border: OutlineInputBorder(),
              ),
              onChanged: (value) {
                // Store feedback if needed
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _updateTrialApproval(session, 'rejected');
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
            child: Text('Submit Feedback'),
          ),
        ],
      ),
    );
  }

  SessionStatus _determineStatus(DateTime? dateTime, String? status) {
    if (status == 'completed') return SessionStatus.completed;
    if (status == 'cancelled') return SessionStatus.missed;

    if (dateTime == null) return SessionStatus.upcoming;

    DateTime now = DateTime.now();
    if (dateTime.isBefore(now)) return SessionStatus.missed;
    if (dateTime.isAfter(now)) return SessionStatus.upcoming;

    return SessionStatus.upcoming;
  }

  String _getTeacherInitial(String name) {
    if (name.isEmpty) return 'T';
    return name[0].toUpperCase();
  }

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('My Schedule', style: AppTextStyles.appBarTitle),
        backgroundColor: AppColors.primary,
        elevation: 0,
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.calendar_month_outlined),
            onPressed: () {
              _showCalendarView();
            },
          ),
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {
              _showNotificationSettings();
            },
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppColors.white,
          indicatorWeight: 3,
          labelStyle: AppTextStyles.tabLabel.copyWith(
            color: AppColors.white,
            fontSize: 13,
          ),
          unselectedLabelStyle: AppTextStyles.tabLabel.copyWith(
            color: AppColors.white.withOpacity(0.6),
            fontSize: 13,
          ),
          tabs: const [
            Tab(text: 'All'),
            Tab(text: 'Upcoming'),
            Tab(text: 'Completed'),
            Tab(text: 'Missed'),
          ],
        ),
      ),
      body: StreamBuilder<List<Session>>(
        stream: getCombinedSessionsStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return _buildLoadingState();
          }

          if (snapshot.hasError) {
            return _buildErrorState(snapshot.error.toString());
          }

          final sessions = snapshot.data ?? [];

          return TabBarView(
            controller: _tabController,
            children: [
              _buildSessionList(sessions),
              _buildSessionList(
                _filterSessions(sessions, SessionStatus.upcoming),
              ),
              _buildSessionList(
                _filterSessions(sessions, SessionStatus.completed),
              ),
              _buildSessionList(
                _filterSessions(sessions, SessionStatus.missed),
              ),
            ],
          );
        },
      ),
    );
  }

  // ========================================
  // 🔹 UPDATED SESSION CARD - FIXED FOR REGULAR CLASSES
  // ========================================
  Widget _buildSessionCard(Session session) {
    Color statusColor = _getStatusColor(session.status);
    IconData statusIcon = _getStatusIcon(session.status);
    bool isUpcoming = session.status == SessionStatus.upcoming;
    bool isMissed = session.status == SessionStatus.missed;
    bool hasPackage =
        session.packageName != null && session.packageName!.isNotEmpty;
    bool isTrial = session.isTrial;
    bool hasTime = session.dateTime != null;

    // 🔥 TRIAL STATUS CHECK
    bool showApprovalButtons = isTrial && session.trialStatus == 'completed';
    bool isApproved = isTrial && session.trialStatus == 'approved';
    bool isRejected = isTrial && session.trialStatus == 'rejected';

    return GestureDetector(
      onTap: () {
        if (!showApprovalButtons && !isApproved && !isRejected) {
          _openTeacherChat(session);
        }
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isTrial
                ? (isApproved
                      ? Colors.green
                      : (isRejected ? Colors.red : AppColors.warning))
                : (isMissed ? AppColors.redPrimary : AppColors.border),
            width: isTrial ? 2 : (isMissed ? 2 : 1),
          ),
          boxShadow: [
            BoxShadow(
              color: (isTrial ? AppColors.warning : statusColor).withOpacity(
                0.1,
              ),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: IntrinsicHeight(
          child: Row(
            children: [
              // 🔹 LEFT STATUS INDICATOR
              Container(
                width: 6,
                decoration: BoxDecoration(
                  color: isTrial
                      ? (isApproved
                            ? Colors.green
                            : (isRejected ? Colors.red : AppColors.warning))
                      : statusColor,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(16),
                    bottomLeft: Radius.circular(16),
                  ),
                ),
              ),

              // 🔹 MAIN CONTENT
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          // Teacher Avatar
                          CircleAvatar(
                            radius: 24,
                            backgroundColor:
                                (isTrial
                                        ? (isApproved
                                              ? Colors.green
                                              : (isRejected
                                                    ? Colors.red
                                                    : AppColors.warning))
                                        : statusColor)
                                    .withOpacity(0.2),
                            child: Text(
                              session.teacherImage,
                              style: AppTextStyles.heading3.copyWith(
                                color: isTrial
                                    ? (isApproved
                                          ? Colors.green
                                          : (isRejected
                                                ? Colors.red
                                                : AppColors.warning))
                                    : statusColor,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),

                          // Teacher Name & Status
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        session.name,
                                        style: AppTextStyles.cardTitle.copyWith(
                                          color: AppColors.text,
                                        ),
                                      ),
                                    ),
                                    // 🔥 TRIAL BADGE WITH STATUS - ONLY FOR TRIAL
                                    if (isTrial) ...[
                                      const SizedBox(width: 8),
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 8,
                                          vertical: 2,
                                        ),
                                        decoration: BoxDecoration(
                                          color: _getTrialStatusColor(
                                            session.trialStatus,
                                          ).withOpacity(0.1),
                                          borderRadius: BorderRadius.circular(
                                            4,
                                          ),
                                          border: Border.all(
                                            color: _getTrialStatusColor(
                                              session.trialStatus,
                                            ),
                                          ),
                                        ),
                                        child: Text(
                                          _getTrialStatusText(
                                            session.trialStatus,
                                          ),
                                          style: AppTextStyles.captionText
                                              .copyWith(
                                                color: _getTrialStatusColor(
                                                  session.trialStatus,
                                                ),
                                                fontSize: 10,
                                                fontWeight: FontWeight.bold,
                                              ),
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                                const SizedBox(height: 4),
                                // 🔥 FIXED: SHOW DIFFERENT TEXT FOR REGULAR VS TRIAL
                                if (isTrial) ...[
                                  Row(
                                    children: [
                                      Icon(
                                        _getTrialStatusIcon(session.trialStatus),
                                        size: 14,
                                        color: _getTrialStatusColor(
                                          session.trialStatus,
                                        ),
                                      ),
                                      const SizedBox(width: 4),
                                      Text(
                                        _getTrialStatusDisplayText(
                                          session.trialStatus,
                                        ),
                                        style: AppTextStyles.captionText.copyWith(
                                          color: _getTrialStatusColor(
                                            session.trialStatus,
                                          ),
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ],
                                  ),
                                ] else ...[
                                  // REGULAR CLASS STATUS
                                  Row(
                                    children: [
                                      Icon(
                                        _getStatusIcon(session.status),
                                        size: 14,
                                        color: statusColor,
                                      ),
                                      const SizedBox(width: 4),
                                      Text(
                                        _getStatusText(session.status),
                                        style: AppTextStyles.captionText.copyWith(
                                          color: statusColor,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),

                      // Subject
                      Text(
                        session.subject,
                        style: AppTextStyles.bodyMedium.copyWith(
                          color: isTrial 
                              ? _getTrialStatusColor(session.trialStatus)
                              : statusColor,
                          fontWeight: FontWeight.w600,
                        ),
                      ),

                      // 🔥 PACKAGE NAME
                      if (hasPackage) ...[
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: isTrial
                                ? _getTrialStatusColor(session.trialStatus).withOpacity(0.1)
                                : statusColor.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(
                              color: isTrial
                                  ? _getTrialStatusColor(session.trialStatus).withOpacity(0.3)
                                  : statusColor.withOpacity(0.3),
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.card_giftcard,
                                size: 12,
                                color: isTrial
                                    ? _getTrialStatusColor(session.trialStatus)
                                    : statusColor,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                session.packageName!,
                                style: AppTextStyles.captionText.copyWith(
                                  color: isTrial
                                      ? _getTrialStatusColor(session.trialStatus)
                                      : statusColor,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 10,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],

                      // 🔥 APPROVAL BUTTONS - SHOW ONLY WHEN TRIAL COMPLETED
                      if (showApprovalButtons) ...[
                        const SizedBox(height: 16),
                        Text(
                          '🎉 Trial class completed! Please share your feedback:',
                          style: AppTextStyles.bodySmall.copyWith(
                            color: Colors.green,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            // REJECT BUTTON
                            Expanded(
                              child: OutlinedButton.icon(
                                onPressed: () {
                                  _showApprovalDialog(session);
                                },
                                icon: Icon(
                                  Icons.thumb_down,
                                  size: 18,
                                  color: Colors.red,
                                ),
                                label: Text(
                                  'Not Satisfied',
                                  style: AppTextStyles.buttonSecondary.copyWith(
                                    fontSize: 14,
                                    color: Colors.red,
                                  ),
                                ),
                                style: OutlinedButton.styleFrom(
                                  side: BorderSide(color: Colors.red),
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 10,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 10),
                            // APPROVE BUTTON
                            Expanded(
                              child: ElevatedButton.icon(
                                onPressed: () {
                                  _showApprovalDialog(session);
                                },
                                icon: Icon(
                                  Icons.thumb_up,
                                  size: 18,
                                  color: Colors.white,
                                ),
                                label: Text(
                                  'Approve Teacher',
                                  style: AppTextStyles.buttonPrimary.copyWith(
                                    fontSize: 14,
                                  ),
                                ),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.green,
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 10,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],

                      // 🔥 APPROVED/RESULT MESSAGE
                      if (isApproved) ...[
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.green.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.check_circle,
                                color: Colors.green,
                                size: 18,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  '🎉 You approved this teacher! Admin will contact you for regular classes.',
                                  style: AppTextStyles.captionText.copyWith(
                                    color: Colors.green,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],

                      if (isRejected) ...[
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.orange.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.info_outline,
                                color: Colors.orange,
                                size: 18,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  'Thank you for your feedback. Admin will assign another teacher.',
                                  style: AppTextStyles.captionText.copyWith(
                                    color: Colors.orange,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],

                      // 🔥 REGULAR CHAT MESSAGE - ONLY FOR PENDING/SCHEDULED TRIALS
                      if (isTrial &&
                          !showApprovalButtons &&
                          !isApproved &&
                          !isRejected) ...[
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: AppColors.warning.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.chat_outlined,
                                color: AppColors.warning,
                                size: 18,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  'Tap to chat with teacher and schedule trial class timing',
                                  style: AppTextStyles.captionText.copyWith(
                                    color: AppColors.warning,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],

                      // 🔥 TIME & DURATION - ONLY SHOW FOR REGULAR CLASSES WITH TIME
                      if (hasTime) ...[
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Icon(
                              Icons.access_time,
                              size: 16,
                              color: AppColors.subtitle,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              _formatTime(session.dateTime!),
                              style: AppTextStyles.bodySmall.copyWith(
                                color: AppColors.text,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            const SizedBox(width: 16),
                            Icon(
                              Icons.timer_outlined,
                              size: 16,
                              color: AppColors.subtitle,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              session.duration,
                              style: AppTextStyles.bodySmall.copyWith(
                                color: AppColors.subtitle,
                              ),
                            ),
                          ],
                        ),
                      ],

                      // 🔥 ACTION BUTTONS - ONLY FOR REGULAR CLASSES WITH TIME
                      if (isUpcoming && hasTime && !isTrial) ...[
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            Expanded(
                              child: ElevatedButton.icon(
                                onPressed: () {
                                  _joinZoomMeeting(session.zoomLink);
                                },
                                icon: const Icon(Icons.videocam, size: 18),
                                label: Text(
                                  'Join Zoom',
                                  style: AppTextStyles.buttonPrimary.copyWith(
                                    fontSize: 14,
                                  ),
                                ),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: AppColors.primary,
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 10,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 10),
                            // OutlinedButton.icon(
                            //   onPressed: () {
                            //     _rescheduleSession(session);
                            //   },
                            //   icon: Icon(
                            //     Icons.calendar_today,
                            //     size: 18,
                            //     color: AppColors.primary,
                            //   ),
                            //   label: Text(
                            //     'Reschedule',
                            //     style: AppTextStyles.buttonSecondary.copyWith(
                            //       fontSize: 14,
                            //       color: AppColors.primary,
                            //     ),
                            //   ),
                            //   style: OutlinedButton.styleFrom(
                            //     side: BorderSide(color: AppColors.primary),
                            //     padding: const EdgeInsets.symmetric(
                            //       vertical: 10,
                            //     ),
                            //     shape: RoundedRectangleBorder(
                            //       borderRadius: BorderRadius.circular(10),
                            //     ),
                            //   ),
                            // ),
                          ],
                        ),
                      ],

                      // Missed Session Actions - ONLY FOR REGULAR CLASSES
                      if (isMissed && !isTrial) ...[
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: AppColors.redPrimary.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.warning_amber_rounded,
                                color: AppColors.redPrimary,
                                size: 18,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  'You missed this session',
                                  style: AppTextStyles.captionText.copyWith(
                                    color: AppColors.redPrimary,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                              TextButton(
                                onPressed: () {
                                  _bookMakeupSession(session);
                                },
                                child: Text(
                                  'Book Makeup',
                                  style: AppTextStyles.captionText.copyWith(
                                    color: AppColors.redPrimary,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // 🔥 TRIAL STATUS HELPERS
  Color _getTrialStatusColor(String status) {
    switch (status) {
      case 'scheduled':
        return Colors.blue;
      case 'pending':
        return Colors.orange;
      case 'completed':
        return Colors.purple;
      case 'approved':
        return Colors.green;
      case 'rejected':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  IconData _getTrialStatusIcon(String status) {
    switch (status) {
      case 'scheduled':
        return Icons.schedule;
      case 'pending':
        return Icons.pending;
      case 'completed':
        return Icons.flag;
      case 'approved':
        return Icons.thumb_up;
      case 'rejected':
        return Icons.thumb_down;
      default:
        return Icons.help;
    }
  }

  String _getTrialStatusText(String status) {
    switch (status) {
      case 'scheduled':
        return 'SCHEDULED';
      case 'pending':
        return 'PENDING';
      case 'completed':
        return 'COMPLETED';
      case 'approved':
        return 'APPROVED';
      case 'rejected':
        return 'REJECTED';
      default:
        return 'TRIAL';
    }
  }

  String _getTrialStatusDisplayText(String status) {
    switch (status) {
      case 'scheduled':
        return 'Trial Scheduled';
      case 'pending':
        return 'Schedule Pending';
      case 'completed':
        return 'Awaiting Your Feedback';
      case 'approved':
        return 'Teacher Approved';
      case 'rejected':
        return 'Feedback Submitted';
      default:
        return 'Trial Class';
    }
  }

  // 🔥 NEW FUNCTION: OPEN TEACHER CHAT
  void _openTeacherChat(Session session) {
    String currentUserId = _auth.currentUser?.uid ?? '';

    if (currentUserId.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('User not logged in', style: AppTextStyles.bodySmall),
          backgroundColor: AppColors.error,
        ),
      );
      return;
    }

    // Navigate to chat screen
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => StudentChatScreen(
          otherUserId: session.teacherId,
          otherUserName: session.name,
          currentUserId: currentUserId,
          currentUserRole: 'student',
        ),
      ),
    );
  }

  // ... (Rest of the helper methods remain same as previous code)
  // _buildLoadingState, _buildErrorState, _buildSessionList, etc.

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(color: AppColors.primary),
          SizedBox(height: 16),
          Text(
            'Loading your schedule...',
            style: AppTextStyles.bodyMedium.copyWith(color: AppColors.subtitle),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorState(String error) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.error_outline, size: 64, color: AppColors.error),
          SizedBox(height: 16),
          Text(
            'Error loading schedule',
            style: AppTextStyles.heading3.copyWith(color: AppColors.error),
          ),
          SizedBox(height: 8),
          Text(
            error,
            style: AppTextStyles.bodySmall.copyWith(color: AppColors.subtitle),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              setState(() {});
            },
            child: Text('Retry'),
          ),
        ],
      ),
    );
  }

  Widget _buildSessionList(List<Session> sessionList) {
    if (sessionList.isEmpty) {
      return _buildEmptyState();
    }

    // Group sessions by date - ONLY FOR SESSIONS WITH DATE
    Map<String, List<Session>> groupedSessions = {};
    List<Session> noDateSessions = [];

    for (var session in sessionList) {
      if (session.dateTime != null) {
        String dateKey = _formatDateHeader(session.dateTime!);
        if (!groupedSessions.containsKey(dateKey)) {
          groupedSessions[dateKey] = [];
        }
        groupedSessions[dateKey]!.add(session);
      } else {
        noDateSessions.add(session);
      }
    }

    return ListView(
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
      children: [
        // 🔥 TRIAL CLASSES WITHOUT DATE (Schedule Pending)
        if (noDateSessions.isNotEmpty) ...[
          _buildDateHeader('Trial Classes'),
          const SizedBox(height: 12),
          ...noDateSessions.map((session) => _buildSessionCard(session)),
          const SizedBox(height: 20),
        ],

        // REGULAR CLASSES WITH DATES
        ...groupedSessions.entries.map((entry) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildDateHeader(entry.key),
              const SizedBox(height: 12),
              ...entry.value.map((session) => _buildSessionCard(session)),
              const SizedBox(height: 20),
            ],
          );
        }),
      ],
    );
  }

  Widget _buildDateHeader(String date) {
    return Padding(
      padding: const EdgeInsets.only(left: 4),
      child: Text(
        date,
        style: AppTextStyles.heading4.copyWith(
          color: AppColors.text,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.event_busy,
            size: 80,
            color: AppColors.grey.withOpacity(0.5),
          ),
          const SizedBox(height: 20),
          Text(
            'No Sessions Found',
            style: AppTextStyles.heading3.copyWith(color: AppColors.subtitle),
          ),
          const SizedBox(height: 10),
          Text(
            'Book your first Quran session',
            style: AppTextStyles.bodySmall.copyWith(color: AppColors.subtitle),
          ),
        ],
      ),
    );
  }

  List<Session> _filterSessions(List<Session> sessions, SessionStatus status) {
    return sessions.where((s) => s.status == status).toList();
  }

  Color _getStatusColor(SessionStatus status) {
    switch (status) {
      case SessionStatus.upcoming:
        return AppColors.primary;
      case SessionStatus.ongoing:
        return AppColors.opposite;
      case SessionStatus.completed:
        return Colors.green;
      case SessionStatus.missed:
        return AppColors.redPrimary;
    }
  }

  IconData _getStatusIcon(SessionStatus status) {
    switch (status) {
      case SessionStatus.upcoming:
        return Icons.schedule;
      case SessionStatus.ongoing:
        return Icons.play_circle_filled;
      case SessionStatus.completed:
        return Icons.check_circle;
      case SessionStatus.missed:
        return Icons.cancel;
    }
  }

  String _getStatusText(SessionStatus status) {
    switch (status) {
      case SessionStatus.upcoming:
        return 'Upcoming';
      case SessionStatus.ongoing:
        return 'Ongoing';
      case SessionStatus.completed:
        return 'Completed';
      case SessionStatus.missed:
        return 'Missed';
    }
  }

  String _formatDateHeader(DateTime date) {
    DateTime now = DateTime.now();
    DateTime today = DateTime(now.year, now.month, now.day);
    DateTime tomorrow = today.add(const Duration(days: 1));
    DateTime sessionDate = DateTime(date.year, date.month, date.day);

    if (sessionDate == today) {
      return 'Today';
    } else if (sessionDate == tomorrow) {
      return 'Tomorrow';
    } else {
      return DateFormat('MMM dd, yyyy').format(date);
    }
  }

  String _formatTime(DateTime dateTime) {
    return DateFormat('h:mm a').format(dateTime);
  }

  void _joinZoomMeeting(String zoomLink) async {
    if (zoomLink.isEmpty || zoomLink == 'https://zoom.us/j/meeting') {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(Icons.error_outline, color: AppColors.white),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Zoom link not available. Please contact your teacher.',
                  style: AppTextStyles.bodySmall.copyWith(
                    color: AppColors.white,
                  ),
                ),
              ),
            ],
          ),
          backgroundColor: AppColors.error,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      );
      return;
    }

    try {
      final Uri url = Uri.parse(zoomLink);
      if (await canLaunchUrl(url)) {
        await launchUrl(url, mode: LaunchMode.externalApplication);
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(
                children: [
                  Icon(Icons.videocam, color: AppColors.white),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Opening Zoom meeting...',
                      style: AppTextStyles.bodySmall.copyWith(
                        color: AppColors.white,
                      ),
                    ),
                  ),
                ],
              ),
              backgroundColor: AppColors.success,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              duration: Duration(seconds: 2),
            ),
          );
        }
      } else {
        throw Exception('Could not launch Zoom link');
      }
    } catch (e) {
      print('Error opening Zoom: $e');
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                Icon(Icons.error_outline, color: AppColors.white),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Failed to open Zoom link. Please try again.',
                    style: AppTextStyles.bodySmall.copyWith(
                      color: AppColors.white,
                    ),
                  ),
                ),
              ],
            ),
            backgroundColor: AppColors.error,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        );
      }
    }
  }

  // void _rescheduleSession(Session session) {
  //   ScaffoldMessenger.of(context).showSnackBar(
  //     SnackBar(
  //       content: Text(
  //         'Reschedule session with ${session.name}',
  //         style: AppTextStyles.bodySmall.copyWith(color: AppColors.white),
  //       ),
  //       backgroundColor: AppColors.opposite,
  //       behavior: SnackBarBehavior.floating,
  //       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
  //     ),
  //   );
  // }

  void _bookMakeupSession(Session session) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Booking makeup session...',
          style: AppTextStyles.bodySmall.copyWith(color: AppColors.white),
        ),
        backgroundColor: AppColors.primary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  void _showCalendarView() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Calendar view coming soon!',
          style: AppTextStyles.bodySmall.copyWith(color: AppColors.white),
        ),
        backgroundColor: AppColors.opposite,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  void _showNotificationSettings() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const StudentNotificationsScreen(),
      ),
    );
  }
}